const fs=require('fs');
const path=require('path');
const assert=require('assert');

const root=path.resolve(__dirname,'..');
const menu=require(path.join(root,'src','services','menu'));
const tools=require(path.join(root,'src','services','tools'));

const items=[['ai','AI','AI tools'],['media','Media','Media tools'],['back','Back']];
const parsed=JSON.parse(menu.listParams('MR DKxx Menu',items));
assert.strictEqual(parsed.title,'MR DKxx Menu');
assert.deepStrictEqual(parsed.sections[0].rows.map(r=>r.id),['ai','media','back']);
assert.ok(parsed.sections[0].rows.every(r=>!Object.prototype.hasOwnProperty.call(r,'rowId')),'Native-flow rows must use id, not rowId');
const quick=JSON.parse(menu.quickParams('English','en'));
assert.deepStrictEqual(quick,{display_text:'English',id:'en'});

const bot=fs.readFileSync(path.join(root,'src','bot.js'),'utf8');
assert.ok(bot.includes("name:'single_select'"),'single_select native-flow button missing');
assert.ok(bot.includes('const additionalNodes=isGroup(jid)?[bizNode]:[botNode,bizNode];'),'Group native-flow delivery missing');
assert.ok(!bot.includes("if(isGroup(jid)){\n  fallbackMenus.set(stateKeyArg||jid)"),'Group menus must not be forced into text-only mode');
assert.ok(bot.includes('interactiveResponseMessage'),'native-flow response parser missing');
assert.ok(bot.includes('listResponseMessage'),'legacy list response parser missing');
assert.ok(bot.includes('templateButtonReplyMessage'),'legacy template response parser missing');
assert.ok(bot.includes('ephemeralMessage?.message'),'wrapped-message parser missing');
assert.ok(bot.includes('function mediaKind'),'media upload handler missing');
assert.ok(bot.includes("s?.mode==='ocr'"),'OCR session missing');
assert.ok(bot.includes("s?.mode==='stt'"),'STT session missing');
assert.ok(bot.includes("s?.mode==='vision'"),'Vision session missing');
assert.ok(bot.includes("s?.mode==='mediaTool'"),'Media tool session missing');
assert.ok(bot.includes("choice==='websearch'"),'Web search menu handler missing');
assert.ok(bot.includes("choice==='backup'"),'Database backup handler missing');

const requiredFiles=[
 'src/bot.js','src/index.js','src/db.js','src/group.js','src/i18n.js','src/dashboard.js','src/utils.js',
 'src/services/ai.js','src/services/media.js','src/services/menu.js','src/services/providers.js','src/services/queue.js',
 'src/services/sticker.js','src/services/tools.js','package.json'
];
for(const rel of requiredFiles)assert.ok(fs.existsSync(path.join(root,rel)),`Missing ${rel}`);

const pkg=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));
assert.ok(pkg.dependencies['@whiskeysockets/baileys']);
assert.ok(pkg.dependencies['@google/genai']);

const ai=fs.readFileSync(path.join(root,'src','services','ai.js'),'utf8');
assert.ok(ai.includes('gemini-3.6-flash'),'Current Gemini model list missing');
assert.ok(ai.includes('Ollama'),'Local AI failover missing');
assert.ok(ai.includes('Groq'),'Groq failover missing');
assert.ok(ai.includes('OpenRouter'),'OpenRouter failover missing');
assert.ok(ai.includes('askWeb'),'Web-search helper missing');
assert.ok(ai.includes('googleSearch'),'Gemini grounding missing');
assert.ok(bot.includes("choice==='local'"),'Local AI menu handler missing');
assert.ok(bot.includes('inFlightInputs'),'AI duplicate in-flight guard missing');
assert.ok(bot.includes('recentAiResponses'),'AI duplicate response guard missing');
assert.ok(bot.includes('recentInputs'),'duplicate input guard missing');
assert.ok(bot.includes('aiChains'),'per-chat AI ordering queue missing');
assert.ok(bot.includes("sendPresenceUpdate('composing'"),'typing presence optimization missing');
assert.ok(bot.includes('geminiModels'),'Gemini model menu integration missing');
assert.ok(ai.includes('trying next Gemini model'),'silent Gemini model failover missing');
assert.ok(ai.includes('options.geminiModel'),'selected Gemini model routing missing');
assert.ok(bot.includes('/aistatus'),'AI status command missing');

assert.ok(bot.includes('parseDkPrefix'),'DK prefix parser missing');
assert.ok(bot.includes('botPaused'),'bot pause state missing');
assert.ok(bot.includes("normalized==='stop'"),'stop command missing');
assert.ok(bot.includes("normalized==='start'"),'resume command missing');
assert.ok(bot.includes("if(botPaused) continue"),'paused mode must ignore normal messages');
assert.ok(bot.includes("if(dkPayload!==null)"),'DK-only AI gate missing');
assert.ok(bot.includes('Unmatched ordinary messages are intentionally ignored'),'Normal unmatched messages must be ignored');
assert.ok(!/\blower\s*[!=]=/.test(bot),'Undefined lower variable regression must not exist');
assert.ok(!bot.includes("await runAi(sock,j,p,'gemini','gemini','')"),'Direct Gemini chat must not bypass DK prefix gate');
assert.ok(bot.includes('function imageModelNames()'),'Image model selection helper missing');
assert.ok(bot.includes('image_auto'),'Image Auto menu missing');
assert.ok(bot.includes('imageChoices'),'Image provider menu integration missing');

const providers=fs.readFileSync(path.join(root,'src','services','providers.js'),'utf8');
for(const needle of ['gemini-3.1-flash-image','gemini-3.1-flash-lite-image','gemini-3-pro-image','gemini-2.5-flash-image','togetherImage','stabilityImage','falImage','huggingFaceImage','vision','POLLINATIONS_ENABLED','imageChoices','imageModels'])assert.ok(providers.includes(needle),`${needle} missing`);

const media=fs.readFileSync(path.join(root,'src','services','media.js'),'utf8');
for(const needle of ['transcode','thumbnail','gif','audioExtract'])assert.ok(media.includes(needle),`${needle} media helper missing`);

for(const [name,fn,args,expected] of [
 ['calc',tools.calc,['2+3*4'],14],['uuid',tools.uuid,[],null],['base64',tools.base64Encode,['MR DKxx'],'TVIgREt4eA=='],['json',tools.jsonFormat,['{"a":1}'],'{\n  "a": 1\n}'],['unit',tools.unitConvert,[1,'km','m'],1000]
]){const v=fn(...args);if(expected!==null)assert.strictEqual(v,expected);else assert.ok(String(v).length>10,`${name} failed`)}

const db=fs.readFileSync(path.join(root,'src','db.js'),'utf8');
assert.ok(db.includes('function backup'),'Database backup helper missing');

console.log('MR DKxx V4.5 self-test: PASS');
console.log('Existing menu/session protections plus AI, image, OCR/STT and media-tool wiring verified.');

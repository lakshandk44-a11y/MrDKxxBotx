require("dotenv").config();
const {startBot}=require("./bot");
const {startDashboard}=require("./dashboard");
const {logger}=require("./utils");
(async()=>{await startBot();startDashboard()})().catch(e=>{logger.error(e);process.exit(1)});

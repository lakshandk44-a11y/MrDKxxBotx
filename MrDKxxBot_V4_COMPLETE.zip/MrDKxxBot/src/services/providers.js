const fs=require('fs'),path=require('path');
const {GoogleGenAI}=require('@google/genai');
const {tmpDir}=require('../utils');
function env(n){return (process.env[n]||'').trim()}
async function image(prompt){
 const geminiKey=env('GEMINI_API_KEY');
 if(geminiKey){
  const models=(env('GEMINI_IMAGE_MODELS')||'gemini-3.1-flash-image,gemini-3-pro-image,gemini-2.5-flash-image').split(',').map(x=>x.trim()).filter(Boolean);
  const ai=new GoogleGenAI({apiKey:geminiKey});let last;
  for(const model of models){try{
   const response=await ai.models.generateContent({model,contents:prompt,config:{responseModalities:['IMAGE'],responseFormat:{image:{aspectRatio:env('IMAGE_ASPECT_RATIO')||'1:1',imageSize:env('IMAGE_SIZE')||'1K'}}}});
   for(const part of response.candidates?.[0]?.content?.parts||[]){if(part.inlineData?.data){const out=path.join(tmpDir,`mrdkxx-gemini-image-${Date.now()}.png`);fs.writeFileSync(out,Buffer.from(part.inlineData.data,'base64'));return out}}
   throw new Error('Gemini image response contained no image');
  }catch(e){last=e}}
  if(last) throw last;
 }
 const url=env('IMAGE_PROVIDER_URL');const key=env('IMAGE_PROVIDER_API_KEY')||env('POLLINATIONS_API_KEY');
 if(!url&&!key)throw new Error('Image generation requires GEMINI_API_KEY or an IMAGE_PROVIDER_URL/API key.');
 const endpoint=url||'https://gen.pollinations.ai/image/'+encodeURIComponent(prompt);
 const sep=endpoint.includes('?')?'&':'?';const final=key&&!url?`${endpoint}${sep}model=${encodeURIComponent(env('POLLINATIONS_IMAGE_MODEL')||'flux')}`:endpoint;
 const headers=key?{Authorization:`Bearer ${key}`}:{};
 const r=await fetch(final,{headers});if(!r.ok)throw new Error(`Image provider HTTP ${r.status}`);const b=Buffer.from(await r.arrayBuffer());const out=path.join(tmpDir,`mrdkxx-image-${Date.now()}.png`);fs.writeFileSync(out,b);return out;
}
async function tts(text){const url=env('TTS_PROVIDER_URL');if(!url)throw new Error('TTS_PROVIDER_URL is not configured');const headers={'Content-Type':'application/json'};const key=env('TTS_PROVIDER_API_KEY');if(key)headers.Authorization=`Bearer ${key}`;const r=await fetch(url,{method:'POST',headers,body:JSON.stringify({text,voice:env('TTS_VOICE')||'default'})});if(!r.ok)throw new Error(`TTS provider HTTP ${r.status}`);const ct=r.headers.get('content-type')||'';if(ct.startsWith('audio/')){const out=path.join(tmpDir,`mrdkxx-tts-${Date.now()}.mp3`);fs.writeFileSync(out,Buffer.from(await r.arrayBuffer()));return out}const j=await r.json();const b=j.audio_base64||j.b64_json||j.data?.[0]?.b64_json;if(!b)throw new Error('TTS provider returned no audio');const out=path.join(tmpDir,`mrdkxx-tts-${Date.now()}.mp3`);fs.writeFileSync(out,Buffer.from(b,'base64'));return out}
async function ocr(file){const url=env('OCR_PROVIDER_URL');if(!url)throw new Error('OCR_PROVIDER_URL is not configured');const headers={};const key=env('OCR_PROVIDER_API_KEY');if(key)headers.Authorization=`Bearer ${key}`;const form=new FormData();form.append('file',new Blob([fs.readFileSync(file)]),path.basename(file));const r=await fetch(url,{method:'POST',headers,body:form});if(!r.ok)throw new Error(`OCR provider HTTP ${r.status}`);const j=await r.json();return j.text||j.result||j.data?.text||JSON.stringify(j)}
async function stt(file){const url=env('STT_PROVIDER_URL');if(!url)throw new Error('STT_PROVIDER_URL is not configured');const headers={};const key=env('STT_PROVIDER_API_KEY');if(key)headers.Authorization=`Bearer ${key}`;const form=new FormData();form.append('file',new Blob([fs.readFileSync(file)]),path.basename(file));const r=await fetch(url,{method:'POST',headers,body:form});if(!r.ok)throw new Error(`STT provider HTTP ${r.status}`);const j=await r.json();return j.text||j.transcript||j.data?.text||JSON.stringify(j)}
module.exports={image,tts,ocr,stt};

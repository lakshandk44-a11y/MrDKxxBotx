const {GoogleGenAI}=require('@google/genai');
const {history,historyAdd}=require('../db');
const {logger}=require('../utils');

function models(){
 const configured=(process.env.GEMINI_MODELS||'gemini-3.6-flash,gemini-3.5-flash-lite,gemini-2.5-flash').split(',').map(x=>x.trim()).filter(Boolean);
 return [...new Set(configured)];
}
async function pollinations(prompt){
 const key=process.env.POLLINATIONS_API_KEY?.trim();
 if(!key) return null;
 const url=(process.env.POLLINATIONS_TEXT_URL||'https://gen.pollinations.ai/v1/chat/completions').trim();
 const model=process.env.POLLINATIONS_TEXT_MODEL||'openai';
 const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${key}`},body:JSON.stringify({model,messages:[{role:'user',content:prompt}]})});
 if(!r.ok) throw new Error(`Pollinations HTTP ${r.status}`);
 const j=await r.json();
 return j.choices?.[0]?.message?.content||j.output||j.text||'';
}
async function askGemini(prompt,jid,onSwitch){
 const key=process.env.GEMINI_API_KEY?.trim();
 const h=history(jid).map(x=>({role:x.role==='assistant'?'model':'user',parts:[{text:x.text}]}));
 let last=null;
 if(key){
  const client=new GoogleGenAI({apiKey:key});
  for(const model of models()){
   try{
    const chat=client.chats.create({model,history:h});
    const config=process.env.GEMINI_GROUNDING==='true'?{tools:[{googleSearch:{}}]}:undefined;
    const r=await chat.sendMessage(config?{message:prompt,config}:{message:prompt});
    const text=r.text?.trim();
    if(!text) throw new Error('Empty AI response');
    historyAdd(jid,'user',prompt);historyAdd(jid,'assistant',text);
    return {provider:'Gemini',model,text};
   }catch(e){last=e;logger.warn({model,err:e.message},'Gemini model failed');if(onSwitch)await onSwitch(model);}
  }
 }
 try{
  const text=await pollinations(prompt);
  if(text?.trim()){historyAdd(jid,'user',prompt);historyAdd(jid,'assistant',text.trim());return {provider:'Pollinations',model:process.env.POLLINATIONS_TEXT_MODEL||'openai',text:text.trim()};}
 }catch(e){last=e;logger.warn({err:e.message},'Pollinations fallback failed')}
 if(!key) throw new Error('GEMINI_API_KEY is not configured. Add it to .env, or configure POLLINATIONS_API_KEY for the optional fallback.');
 throw last||new Error('All AI providers failed');
}
module.exports={askGemini,models};

const {spawn}=require('child_process');
const fs=require('fs'),path=require('path');
const {downloadDir,isUrl,logger}=require('../utils');
function run(bin,args,timeout=300000){return new Promise((resolve,reject)=>{const p=spawn(bin,args,{windowsHide:true});let out='',err='';const timer=setTimeout(()=>{try{p.kill()}catch{};reject(new Error('Process timeout'))},timeout);p.stdout.on('data',d=>out+=d);p.stderr.on('data',d=>err+=d);p.on('error',e=>{clearTimeout(timer);reject(e)});p.on('close',c=>{clearTimeout(timer);if(c===0)resolve({out,err});else reject(new Error((err||out).slice(-2000)||`process exited with ${c}`))})})}
function yt(){return process.env.YT_DLP_PATH||'yt-dlp'}
async function info(url){if(!isUrl(url))throw new Error('Invalid URL');const {out}=await run(yt(),['--no-playlist','--dump-single-json','--no-warnings',url],90000);const j=JSON.parse(out);return {title:j.title||'Media',duration:j.duration||0,uploader:j.uploader||'',thumbnail:j.thumbnail||'',url:j.webpage_url||url}}
async function download(url,kind='video',quality='best'){
 if(!isUrl(url))throw new Error('Invalid URL');
 const maxMb=Number(process.env.MAX_DOWNLOAD_MB||100);const prefix=path.join(downloadDir,`mrdkxx-${Date.now()}-${Math.random().toString(16).slice(2)}`);const template=`${prefix}.%(ext)s`;
 const args=['--no-playlist','--no-warnings','--max-filesize',`${maxMb}M`,'-o',template,'--restrict-filenames'];
 if(kind==='audio')args.push('-x','--audio-format','mp3','--audio-quality','0');
 else {const q=quality==='small'?'best[height<=480]/best':quality==='medium'?'best[height<=720]/best':'bestvideo*+bestaudio/best';args.push('-f',q,'--merge-output-format','mp4')}
 args.push(url);await run(yt(),args);
 const files=fs.readdirSync(downloadDir).filter(f=>f.startsWith(path.basename(prefix)+'.')&&!f.endsWith('.part')&&!f.endsWith('.ytdl'));
 if(!files.length)throw new Error('No output file was produced.');
 const file=path.join(downloadDir,files[0]);const mb=fs.statSync(file).size/1024/1024;if(mb>maxMb){cleanup(file);throw new Error(`File is larger than ${maxMb} MB`)}return file;
}
function cleanup(file){try{if(file&&fs.existsSync(file))fs.unlinkSync(file)}catch(e){logger.warn(e.message,'cleanup failed')}}
function cleanupPrefix(prefix){for(const f of fs.readdirSync(downloadDir)){if(f.startsWith(prefix)){try{fs.unlinkSync(path.join(downloadDir,f))}catch{}}}}
module.exports={run,info,download,cleanup,cleanupPrefix};

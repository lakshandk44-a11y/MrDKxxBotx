function normalizeText(s){return String(s??'').replace(/\\n/g,'\n').replace(/\\r/g,'\r').replace(/\\t/g,'\t')}
function rows(items){return items.map(([id,title,description=''])=>({rowId:String(id),title:String(title).slice(0,60),description:String(description).slice(0,72)}))}
function listParams(title,items){return JSON.stringify({title:String(title).slice(0,24),sections:[{title:'MR DKxx',rows:rows(items)}]})}
function quickParams(display_text,id){return JSON.stringify({display_text:String(display_text).slice(0,20),id:String(id)})}
function nativeFlow(body,footer,buttons){return {viewOnceMessage:{message:{interactiveMessage:{header:{title:'MR DKxx'},body:{text:normalizeText(body)},footer:{text:normalizeText(footer||'Mr DKxx')},nativeFlowMessage:{buttons,messageParamsJson:''}}}}}}
module.exports={normalizeText,rows,listParams,quickParams,nativeFlow};

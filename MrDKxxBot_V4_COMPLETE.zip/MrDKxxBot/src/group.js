function isGroup(jid){return jid?.endsWith("@g.us")}
function isOwner(jid){
  const ids=(process.env.OWNER_JIDS||"").split(",").map(x=>x.trim()).filter(Boolean);
  return ids.includes(jid)
}
async function metadata(sock,jid){return sock.groupMetadata(jid)}
async function isAdmin(sock,jid,userJid){
  const m=await metadata(sock,jid);
  return !!m.participants.find(p=>p.id===userJid && (p.admin==="admin"||p.admin==="superadmin"));
}
module.exports={isGroup,isOwner,isAdmin};

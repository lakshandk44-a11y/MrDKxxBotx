const fs = require("fs");
const path = require("path");

const dataDir = path.resolve(process.env.DATA_DIR || "data");
const downloadDir = path.resolve("downloads");
const tmpDir = path.resolve("tmp");
const logDir = path.resolve("logs");
for (const d of [dataDir, downloadDir, tmpDir, logDir]) fs.mkdirSync(d, {recursive:true});

function now(){ return new Date().toISOString(); }
const logger = {
  info:(...a)=>console.log(`[${now()}] INFO`,...a),
  warn:(...a)=>console.warn(`[${now()}] WARN`,...a),
  error:(...a)=>console.error(`[${now()}] ERROR`,...a)
};
function safeText(v,max=5000){return String(v??"").replace(/[\u0000-\u001F\u007F]/g,"").slice(0,max);}
function sleep(ms){return new Promise(r=>setTimeout(r,ms));}
function isUrl(v){try{const u=new URL(v);return ["http:","https:"].includes(u.protocol)}catch{return false}}
module.exports={dataDir,downloadDir,tmpDir,logDir,logger,safeText,sleep,isUrl};

# MR DKxx WhatsApp Bot V4

A Windows VPS WhatsApp assistant built with Node.js, Baileys, SQLite, yt-dlp and FFmpeg.

## Quick start

1. Use Node.js 22 LTS on Windows.
2. Install Python 3.12, FFmpeg and yt-dlp.
3. Extract this project.
4. Copy `.env.example` to `.env`.
5. Add `GEMINI_API_KEY` if you want Gemini features.
6. Set `OWNER_JIDS` after using `/id` from the WhatsApp account.
7. Run `npm install`.
8. Run `npm start`.
9. Scan the QR once from WhatsApp > Linked devices.

## Main features

- English/Sinhala interactive menus
- MR DKxx logo/branding
- Gemini AI chat with model failover
- Optional Gemini Google Search grounding
- AI summarize/translate/analyze/rewrite/captions/hashtags
- Gemini image generation with provider fallback
- Video/audio downloads through yt-dlp
- 480p/720p/best video and MP3 options
- Media info
- Sticker conversion using FFmpeg
- QR generator and calculator
- Group rules, admin checks, tag-all and stats
- SQLite history and usage tracking
- Health/status/ping/ID commands
- Queueing, download limits, cleanup and reconnect handling
- Optional TTS/STT/OCR adapters

## Gemini models

The default text failover list targets current Gemini 3.x stable models. Gemini 2.0 Flash is not used because Google shut down the Gemini 2.0 Flash family on June 1, 2026.

## Notes

Provider-dependent features require their relevant API keys/URLs. The bot does not bypass platform restrictions. Download only content you are authorized to download and respect copyright/platform terms.

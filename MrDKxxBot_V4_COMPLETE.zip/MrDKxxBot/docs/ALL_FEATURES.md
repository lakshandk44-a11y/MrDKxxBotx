# MR DKxx v3 feature map

## Interface
- Branded MR DKxx logo message
- Clickable native-flow menu
- List fallback for incompatible clients
- Sinhala/English user language
- Home/back navigation
- Short commands for emergency/manual access

## AI
- Gemini 3.6 Flash
- Gemini 3.5 Flash-Lite
- Gemini 2.5 Flash fallback
- Optional Pollinations text fallback
- AI chat mode
- Conversation history
- Summarize
- Sinhala ↔ English translation
- Text analysis
- Image prompt generation
- Gemini native image generation
- Optional image provider fallback

## Media
- Public/authorized URL detection
- Media info
- Video best quality
- Video 480p
- Video 720p
- MP3 extraction
- Size limit
- Concurrent-job queue
- Temporary file cleanup
- ffmpeg/yt-dlp health checks

## Tools
- QR code generation
- Safe arithmetic calculator
- URL/media information
- Optional TTS/STT/OCR adapters
- System status/health

## Groups
- Group detection
- Admin list
- Member count
- Rules storage
- Warning storage
- Tag-all (admin only)
- Moderation panel (admin only, automatic destructive actions disabled by default)

## Operations
- SQLite state
- AI history
- Usage counters
- Automatic reconnect
- Local dashboard
- PowerShell install/run
- PM2 configuration

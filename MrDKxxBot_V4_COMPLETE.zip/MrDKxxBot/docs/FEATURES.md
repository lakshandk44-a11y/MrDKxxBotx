# Features

MR DKxx v3 is designed around clickable WhatsApp menus so users type as little as possible.

### Main menu
🤖 AI · 🎬 Media · 🖼️ Image · 🛠️ Tools · 👥 Group · 📥 Downloads · ⚙️ Settings · ℹ️ Help

### AI
Gemini chat, direct `gemini` command, model failover, optional Pollinations fallback, history, summarization, translation, analysis and image-prompt generation.

### Media/downloads
yt-dlp video/audio downloads, quality choices, MP3 extraction, media info, size limits, queueing and cleanup.

### Image
Gemini image generation with model fallback, plus optional image provider/Pollinations fallback.

### Group
Rules storage, admin list, member count, warnings storage, tag-all and admin-only moderation panel.

### Tools
QR, safe calculator, URL/media info, optional TTS/STT/OCR, health and status.

### Safety defaults
Automatic destructive moderation actions are not enabled by default. Download tools are intended for public/authorized content only.

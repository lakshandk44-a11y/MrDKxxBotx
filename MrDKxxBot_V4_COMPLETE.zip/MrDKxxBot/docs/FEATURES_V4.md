# Mr DKxx V4 feature set

## WhatsApp UX
- MR DKxx branded PNG header/logo
- Native WhatsApp list/quick-reply menus with a compatibility fallback
- English and Sinhala menus
- Language switching stored per user
- Back/Home navigation
- `/menu`, `/help`, `/features`, `/status`, `/health`, `/ping`, `/id`, `/clear`

## AI
- Gemini chat mode from the menu
- `gemini <message>` and `/gemini <message>` shortcuts
- Model failover across configured Gemini models
- Optional Google Search grounding (`GEMINI_GROUNDING=true`)
- AI summarization, translation, analysis, rewriting
- Caption and hashtag generation
- AI image generation with Gemini image models and optional external provider fallback
- Optional Pollinations text fallback
- Per-user short conversation history in SQLite
- Clear AI history

## Media
- yt-dlp based video/audio downloading from public/authorized URLs supported by yt-dlp
- Best, 480p and 720p video choices
- MP3 extraction
- Media metadata/info
- Download queue and size limit
- Automatic temporary-file cleanup
- Image and short-video to WhatsApp sticker conversion with FFmpeg

## Tools
- QR image generator
- Safe arithmetic calculator
- URL/media information
- Optional TTS/STT/OCR provider adapters
- System health check for Node, yt-dlp, FFmpeg and Gemini configuration

## Groups
- Group-only tools
- Admin checks
- Rules storage
- Admin/member stats
- Tag-all (admin only)
- Warning storage
- Moderation panel placeholder; destructive actions are not enabled by default

## Reliability
- SQLite WAL database
- Auth/session persistence
- Automatic reconnect unless logged out
- Native-menu fallback
- Per-message error handling
- Process timeouts for media tools
- Node 20-22 compatibility target

### Important
API-dependent features still require their provider/API key. A feature is not advertised as available when its required provider is not configured.

Only download media you are authorized to download and follow the relevant platform terms and copyright law.

const {GoogleGenAI}=require('@google/genai');
const {history,historyAdd}=require('../db');
const {logger,sleep}=require('../utils');

const DEFAULT_GEMINI_MODELS=[
 'gemini-3.6-flash',
 'gemini-3.5-flash',
 'gemini-3.5-flash-lite',
 'gemini-3.1-flash-lite',
 'gemini-2.5-flash',
];

function listFromEnv(name,fallback){
 const raw=String(process.env[name]||'').trim();
 const value=raw?raw.split(',').map(x=>x.trim()).filter(Boolean):fallback;
 return [...new Set(value)];
}
function models(){return listFromEnv('GEMINI_MODELS',DEFAULT_GEMINI_MODELS)}
function env(n){return String(process.env[n]||'').trim()}

function errorCode(e){
 const msg=String(e?.message||e||'');
 const m=msg.match(/\b(401|403|404|408|409|429|500|502|503|504)\b/);
 return m?Number(m[1]):null;
}
function isAuthError(e){const c=errorCode(e);return c===401||c===403||/api key|permission|unauthorized|forbidden/i.test(String(e?.message||''))}
function isRetryable(e){const c=errorCode(e);return c===408||c===429||c>=500||/timeout|timed out|fetch failed|socket|ECONNRESET|ENOTFOUND/i.test(String(e?.message||''))}

async function fetchWithTimeout(url,options={},timeoutMs=Number(process.env.AI_TIMEOUT_MS||90000)){
 const controller=new AbortController();
 const timer=setTimeout(()=>controller.abort(),Math.max(5000,timeoutMs));
 try{return await fetch(url,{...options,signal:controller.signal})}
 catch(e){if(e?.name==='AbortError')throw new Error(`AI request timed out after ${Math.round(timeoutMs/1000)}s`);throw e}
 finally{clearTimeout(timer)}
}

async function pollinations(prompt,jid){
 const key=env('POLLINATIONS_API_KEY');
 if(!key)return null;
 const url=env('POLLINATIONS_TEXT_URL')||'https://gen.pollinations.ai/v1/chat/completions';
 const model=env('POLLINATIONS_TEXT_MODEL')||'openai';
 const h=history(jid).map(x=>({role:x.role==='assistant'?'assistant':'user',content:x.text}));
 const r=await fetchWithTimeout(url,{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${key}`},body:JSON.stringify({model,messages:[...h,{role:'user',content:prompt}],stream:false})});
 if(!r.ok){const body=await r.text().catch(()=> '');throw new Error(`Pollinations HTTP ${r.status}${body?`: ${body.slice(0,300)}`:''}`)}
 const j=await r.json();
 return j.choices?.[0]?.message?.content||j.output?.[0]?.content||j.output||j.text||'';
}

async function openAICompatible(prompt,jid,base,modelName,label){
 const url=`${base.replace(/\/$/,'')}/v1/chat/completions`;
 const h=history(jid).map(x=>({role:x.role==='assistant'?'assistant':'user',content:x.text}));
 const r=await fetchWithTimeout(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({model:modelName,messages:[{role:'system',content:env('AI_SYSTEM_PROMPT')||'You are MR DKxx, a helpful multilingual WhatsApp assistant. Answer naturally and concisely. Match the user language when practical.'},...h,{role:'user',content:prompt}],stream:false,temperature:Number(process.env.LOCAL_AI_TEMPERATURE||0.7)})},Number(process.env.LOCAL_AI_TIMEOUT_MS||180000));
 if(!r.ok){const body=await r.text().catch(()=> '');throw new Error(`${label} HTTP ${r.status}${body?`: ${body.slice(0,240)}`:''}`)}
 const j=await r.json();
 const text=j.choices?.[0]?.message?.content||j.response||j.output||'';
 if(!String(text).trim())throw new Error(`${label} returned an empty response`);
 return {text:String(text).trim(),model:j.model||modelName||'local'};
}

async function lmStudio(prompt,jid){
 const base=env('LM_STUDIO_URL')||'http://127.0.0.1:1234';
 let model=env('LM_STUDIO_MODEL');
 if(!model){
  const r=await fetchWithTimeout(`${base.replace(/\/$/,'')}/v1/models`,{},7000);
  if(!r.ok)throw new Error(`LM Studio HTTP ${r.status}`);
  const j=await r.json(); model=j.data?.[0]?.id||'';
 }
 if(!model)throw new Error('LM Studio is running but no model is loaded.');
 return openAICompatible(prompt,jid,base,model,'LM Studio');
}

async function ollamaTags(base){
 const r=await fetchWithTimeout(`${base.replace(/\/$/,'')}/api/tags`,{},7000);
 if(!r.ok)throw new Error(`Ollama HTTP ${r.status}`);
 return await r.json();
}

async function ollama(prompt,jid){
 const base=env('LOCAL_AI_URL')||'http://127.0.0.1:11434';
 let model=env('LOCAL_AI_MODEL');
 if(!model){
  const tags=await ollamaTags(base);
  model=tags.models?.[0]?.name||'';
 }
 if(!model)throw new Error('Ollama is running but no local model is installed.');
 const messages=[
  {role:'system',content:env('AI_SYSTEM_PROMPT')||'You are MR DKxx, a helpful multilingual WhatsApp assistant. Answer naturally and concisely. Match the user language (including Sinhala) when practical.'},
  ...history(jid).map(x=>({role:x.role==='assistant'?'assistant':'user',content:x.text})),
  {role:'user',content:prompt},
 ];
 const r=await fetchWithTimeout(`${base.replace(/\/$/,'')}/api/chat`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({model,messages,stream:false,options:{temperature:Number(process.env.LOCAL_AI_TEMPERATURE||0.7)}})},Number(process.env.LOCAL_AI_TIMEOUT_MS||180000));
 if(!r.ok){const body=await r.text().catch(()=> '');throw new Error(`Ollama HTTP ${r.status}${body?`: ${body.slice(0,300)}`:''}`)}
 const j=await r.json();
 return {text:j.message?.content||j.response||'',model};
}

async function gemini(prompt,jid){
 const key=env('GEMINI_API_KEY');
 if(!key)throw new Error('GEMINI_API_KEY is not configured.');
 const client=new GoogleGenAI({apiKey:key});
 const h=history(jid).map(x=>({role:x.role==='assistant'?'model':'user',parts:[{text:x.text}]}));
 let last=null;
 let authFailure=false;
 for(const model of models()){
  try{
   const config={systemInstruction:env('AI_SYSTEM_PROMPT')||'You are MR DKxx, a helpful multilingual WhatsApp assistant. Answer naturally, accurately and concisely. Match the user language when practical. Do not mention internal provider failover unless asked.'};
   if(env('GEMINI_GROUNDING').toLowerCase()==='true')config.tools=[{googleSearch:{}}];
   const response=await client.models.generateContent({
    model,
    contents:[...h,{role:'user',parts:[{text:prompt}]}],
    config,
   });
   const text=response.text?.trim();
   if(!text)throw new Error('Empty Gemini response');
   return {provider:'Gemini',model,text,grounded:!!config.tools};
  }catch(e){
   last=e;
   logger.warn({model,code:errorCode(e),err:e.message},'Gemini model failed; trying next provider/model');
   if(isAuthError(e)){authFailure=true;break}
   if(!isRetryable(e))continue;
   await sleep(150);
  }
 }
 if(authFailure)throw last||new Error('Gemini authentication/permission failed.');
 throw last||new Error('All configured Gemini models failed.');
}

async function askAI(prompt,jid,options={}){
 const preferred=String(options.provider||'auto').toLowerCase();
 const order=preferred==='gemini'?['gemini','ollama','lmstudio','pollinations']:
  preferred==='local'||preferred==='ollama'?['ollama','lmstudio','gemini','pollinations']:
  preferred==='pollinations'?['pollinations','gemini','ollama','lmstudio']:
  listFromEnv('AI_PROVIDER_ORDER',['gemini','ollama','lmstudio','pollinations']).map(x=>x.toLowerCase());
 let last=null;
 for(const provider of [...new Set(order)]){
  try{
   let result;
   if(provider==='gemini')result=await gemini(prompt,jid);
   else if(provider==='pollinations'){const text=await pollinations(prompt,jid);if(!text?.trim())throw new Error('Pollinations returned an empty response');result={provider:'Pollinations',model:env('POLLINATIONS_TEXT_MODEL')||'openai',text:text.trim(),grounded:false};}
   else if(provider==='ollama'){const r=await ollama(prompt,jid);result={provider:'Ollama',model:r.model,text:r.text.trim(),grounded:false};}
   else if(provider==='lmstudio'){const r=await lmStudio(prompt,jid);result={provider:'LM Studio',model:r.model,text:r.text.trim(),grounded:false};}
   else continue;
   if(!result?.text?.trim())throw new Error(`${provider} returned an empty response`);
   const text=result.text.trim();
   historyAdd(jid,'user',prompt);historyAdd(jid,'assistant',text);
   return {...result,usedFallback:provider!=='gemini'};
  }catch(e){
   last=e;
   logger.warn({provider,code:errorCode(e),err:e.message},'AI provider failed; continuing failover');
  }
 }
 const parts=[];
 if(!env('GEMINI_API_KEY'))parts.push('Gemini key missing');
 if(!env('POLLINATIONS_API_KEY'))parts.push('Pollinations key missing');
 parts.push('Local AI (Ollama/LM Studio) unavailable');
 const detail=last?.message?` Last error: ${last.message.slice(0,220)}`:'';
 throw new Error(`AI service unavailable. ${parts.join(' • ')}.${detail}`);
}

async function askGemini(prompt,jid,onSwitch){
 // Backward-compatible name used by older bot code. Failover is now silent so
 // users do not receive a wall of "model unavailable" messages.
 const r=await askAI(prompt,jid,{provider:'auto'});
 return r;
}

async function providerStatus(){
 const status=[];
 status.push(`Gemini: ${env('GEMINI_API_KEY')?'configured':'not configured'} (${models().join(', ')})`);
 status.push(`Pollinations: ${env('POLLINATIONS_API_KEY')?'configured':'not configured'}`);
 const base=env('LOCAL_AI_URL')||'http://127.0.0.1:11434';
 try{const tags=await ollamaTags(base);status.push(`Ollama: online${tags.models?.length?` • ${tags.models.map(x=>x.name).join(', ')}`:' • no models'}`)}catch{status.push('Ollama: offline/not installed')}
 const lm=env('LM_STUDIO_URL')||'http://127.0.0.1:1234';
 try{const r=await fetchWithTimeout(`${lm.replace(/\/$/,'')}/v1/models`,{},5000);if(!r.ok)throw new Error('offline');const j=await r.json();status.push(`LM Studio: online${j.data?.length?` • ${j.data.map(x=>x.id).join(', ')}`:' • no model loaded'}`)}catch{status.push('LM Studio: offline/not installed')}
 return status;
}

module.exports={askAI,askGemini,models,providerStatus};

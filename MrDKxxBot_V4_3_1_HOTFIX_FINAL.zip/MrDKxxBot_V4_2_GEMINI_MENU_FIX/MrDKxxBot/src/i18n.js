const {lang,setLang}=require('./db');
const en={
 welcome:'Smart WhatsApp Assistant', choose:'Choose a service:',
 language:'🌐 Language',si:'🇱🇰 සිංහල',en:'🇬🇧 English',back:'◀️ Back',home:'🏠 Home',
 ownerMenu:'👑 Owner Tools',stats:'📈 Statistics',clear:'🧹 Clear AI History',privacy:'🔒 Privacy',sendSticker:'✨ Send an image or short video now to convert it to a sticker.',ai:'✨ AI',media:'🎬 Media',music:'🎵 Music',image:'🖼️ Image',tools:'🛠️ Tools',group:'👥 Group',downloads:'📥 Downloads',settings:'⚙️ Settings',help:'ℹ️ Help',
 gemini:'✨ Gemini',geminiChoose:'Choose a Gemini model to chat with. Each model silently fails over to the next configured Gemini model.',chat:'💬 Smart AI Chat',local:'🆓 Local AI (Ollama)',aistatus:'🩺 AI Provider Status',summarize:'📝 Summarize',translate:'🌐 Translate',imageai:'🎨 Generate Image Prompt',analyze:'📄 Analyze Text',caption:'✍️ Captions',hashtags:'#️⃣ Hashtags',rewrite:'🪄 Rewrite',
 video:'🎬 Video Download',audio:'🎵 MP3 Download',info:'🔎 Media Info',sticker:'✨ Sticker',
 imageGen:'🎨 Create Image',imageModels:'🎨 Image Models',qr:'🔳 QR Code',calc:'🧮 Calculator',myid:'🆔 My WhatsApp ID',url:'🔗 URL Info',tts:'🔊 Text to Speech',status:'📊 Status',health:'🩺 System Check',
 rules:'📜 Rules',admins:'🛡️ Admins',groupStats:'📊 Group Stats',warnings:'⚠️ Warnings',tagall:'📣 Tag All',moderation:'🛡️ Moderation',
 imageChoose:'Choose Image Auto or a Gemini image model. If one fails, the bot silently tries the next model and then the configured image fallback.',chooseLang:'Select your language / භාෂාව තෝරන්න',saved:'✅ Language changed.',aiOn:'✨ Smart AI mode selected. Send AI messages starting with DK. Example: DK hello. Send back to exit.',aiOnGemini:'✨ Gemini selected. Send AI messages starting with DK. If a model fails, Gemini silently tries the next model and then the backup provider.',aiOnLocal:'🆓 Local AI selected. Send AI messages starting with DK. This uses Ollama on the VPS.',sendPrompt:'✍️ Send your text now. Send back to return.',sendUrl:'🔗 Send a public/authorized URL.',onlyGroup:'👥 This feature works in groups.',admin:'🛡️ Admin permission required.',owner:'👑 Owner permission required.',
 cleared:'🧹 AI history cleared.',error:'⚠️ Something went wrong. Please try again.',switching:'🔄 Switching AI provider/model...',helpText:'Use the buttons and lists. Download only content you are authorized to download and respect copyright/platform rules.',
 statusText:'🟢 MR DKxx online\n✨ AI failover: enabled\n🗃️ SQLite: online',
 fileTooLarge:'⚠️ File is larger than the configured limit.',expired:'⚠️ This action expired. Please start again.'
};
const si={...en,
 welcome:'Smart WhatsApp Assistant',choose:'ඔබට අවශ්‍ය සේවාව තෝරන්න:',
 language:'🌐 භාෂාව',back:'◀️ ආපසු',home:'🏠 මුල් පිටුව',ownerMenu:'👑 Owner Tools',stats:'📈 Statistics',clear:'🧹 Clear AI History',privacy:'🔒 Privacy',sendSticker:'✨ Send an image or short video now to convert it to a sticker.',ai:'✨ AI',media:'🎬 මාධ්‍ය',music:'🎵 සංගීත',image:'🖼️ පින්තූර',tools:'🛠️ මෙවලම්',group:'👥 සමූහය',downloads:'📥 බාගත කිරීම්',settings:'⚙️ සැකසුම්',help:'ℹ️ උදව්',
 gemini:'✨ Gemini',geminiChoose:'Gemini model එකක් තෝරන්න. එකක් fail වුණොත් ඊළඟ Gemini model එකට නිහඬව මාරු වෙනවා.',chat:'💬 Smart AI Chat',local:'🆓 Local AI (Ollama)',aistatus:'🩺 AI Provider Status',summarize:'📝 සාරාංශය',translate:'🌐 පරිවර්තනය',imageai:'🎨 Image Prompt',analyze:'📄 Text විශ්ලේෂණය',caption:'✍️ Caption හදන්න',hashtags:'#️⃣ Hashtags හදන්න',rewrite:'🪄 නැවත ලියන්න',
 video:'🎬 වීඩියෝ Download',audio:'🎵 MP3 Download',info:'🔎 Media විස්තර',sticker:'✨ Sticker',
 imageGen:'🎨 පින්තූරයක් හදන්න',imageModels:'🎨 Image Models',qr:'🔳 QR කේතය',calc:'🧮 කැල්කියුලේටරය',myid:'🆔 මගේ WhatsApp ID',url:'🔗 URL විස්තර',tts:'🔊 Text to Speech',status:'📊 තත්ත්වය',health:'🩺 System Check',
 rules:'📜 නීති',admins:'🛡️ ඇඩ්මින්',groupStats:'📊 Group Stats',warnings:'⚠️ Warnings',tagall:'📣 සියලු දෙනා Tag',moderation:'🛡️ Moderation',
 imageChoose:'🎨 Image Auto හෝ Gemini image model එකක් තෝරන්න. එකක් fail වුණොත් ඊළඟ model/provider එකට නිහඬව මාරු වෙනවා.',chooseLang:'🌐 භාෂාව තෝරන්න / Select your language',saved:'✅ භාෂාව වෙනස් කළා.',cleared:'🧹 AI history එක මකා දැමුවා.',aiOn:'✨ Smart AI selected. AI messages must start with DK. උදා: DK hello. ඉවත් වෙන්න back යවන්න.',sendPrompt:'✍️ දැන් text එක එවන්න. ආපසු යන්න back යවන්න.',sendUrl:'🔗 Public/අවසර ඇති URL එකක් එවන්න.',onlyGroup:'👥 මේ feature එක group එකකදී පමණයි.',admin:'🛡️ Admin අවසරය අවශ්‍යයි.',owner:'👑 Owner අවසරය අවශ්‍යයි.',
 error:'⚠️ දෝෂයක් ඇතිවුණා. නැවත උත්සාහ කරන්න.',aiOnGemini:'✨ Gemini තෝරාගත්තා. AI message එක DK වලින් පටන් ගන්න. Model එකක් fail වුණොත් ඊළඟ Gemini model/provider එකට නිහඬව මාරු වෙනවා.',aiOnLocal:'🆓 Local AI තෝරාගත්තා. AI message එක DK වලින් පටන් ගන්න. VPS එකේ Ollama භාවිතා කරනවා.',switching:'🔄 වෙනත් AI model/provider එකකට මාරු වෙමින්...',helpText:'Buttons/lists භාවිතයෙන් navigate කරන්න. Download කරන්නේ ඔබට අවසර ඇති content පමණක් වන අතර copyright/platform rules ගරු කරන්න.',
 statusText:'🟢 MR DKxx online\n✨ AI failover: enabled\n🗃️ SQLite: online',fileTooLarge:'⚠️ File එක සීමාවට වඩා විශාලයි.',expired:'⚠️ මේ action එක කල් ඉකුත් වී ඇත. නැවත ආරම්භ කරන්න.'
};
function t(jid,key){return (lang(jid)==='si'?si:en)[key]??key}
function change(jid,value){setLang(jid,value)}
module.exports={t,change};

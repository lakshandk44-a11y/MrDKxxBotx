const {spawn}=require('child_process');
const fs=require('fs'),path=require('path');
const {downloadDir,tmpDir,isUrl,logger}=require('../utils');
// If the binary itself is missing (ENOENT) or not executable (EACCES), spawn's
// "error" event fires with that raw Node error, e.g. "spawn yt-dlp ENOENT". That
// message alone doesn't tell an end user (or the owner reading logs) what to do
// about it, so every caller downstream (download(), info(), the /health check)
// was surfacing a cryptic Node internal error instead of an actionable one. We
// rewrite ENOENT/EACCES here, once, so the whole app benefits automatically.
function friendlyBinError(bin,e){
 if(e&&e.code==='ENOENT')return new Error(`'${bin}' is not installed or not on PATH. Install it and restart the bot (see docs/SETUP.md).`);
 if(e&&e.code==='EACCES')return new Error(`'${bin}' was found but is not executable (permission denied). Check the file permissions.`);
 return e;
}
function run(bin,args,timeout=300000){return new Promise((resolve,reject)=>{const p=spawn(bin,args,{windowsHide:true});let out='',err='',settled=false;const finish=(fn,v)=>{if(settled)return;settled=true;clearTimeout(timer);fn(v)};const timer=setTimeout(()=>{try{p.kill()}catch{};finish(reject,new Error('Process timeout'))},timeout);p.stdout.on('data',d=>out+=d);p.stderr.on('data',d=>err+=d);p.on('error',e=>finish(reject,friendlyBinError(bin,e)));p.on('close',c=>c===0?finish(resolve,{out,err}):finish(reject,new Error((err||out).slice(-2200)||`process exited with ${c}`)))})}
function yt(){return process.env.YT_DLP_PATH||'yt-dlp'}
function ffmpeg(){return process.env.FFMPEG_PATH||'ffmpeg'}
// Cheap up-front check so the bot can refuse fast with a clear message instead of
// showing "Downloading..." for a while and then failing with a raw ENOENT. Cached
// briefly per-process since this is checked on every download attempt.
let binCache={at:0,ytdlp:null,ffmpeg:null};
async function checkBinaries(force=false){
 const now=Date.now();
 if(!force&&binCache.ytdlp!==null&&now-binCache.at<60000)return {ytdlp:binCache.ytdlp,ffmpeg:binCache.ffmpeg};
 const [ytOk,ffOk]=await Promise.all([
  run(yt(),['--version'],15000).then(()=>true).catch(()=>false),
  run(ffmpeg(),['-version'],15000).then(()=>true).catch(()=>false)
 ]);
 binCache={at:now,ytdlp:ytOk,ffmpeg:ffOk};
 return {ytdlp:ytOk,ffmpeg:ffOk};
}
// YouTube can reject the default "web" client with "Sign in to confirm you're not a
// bot". Listing several alternative player clients (comma-separated) lets yt-dlp try
// each internally per request — no cookies/login needed. This is free and works for
// most public videos; only some age-restricted/members-only videos still need cookies.
function extractorArgs(){
 const clients=process.env.YT_DLP_PLAYER_CLIENTS||'android,ios,tv_embedded,web_safari,mweb';
 return ['--extractor-args',`youtube:player_client=${clients}`];
}
// Optional: if the operator later gets access to a PC/Kiwi Browser and exports
// cookies.txt, dropping the path into YT_DLP_COOKIES_FILE (or COOKIES_FROM_BROWSER)
// still works alongside the player-client fallback above for the toughest videos.
// If nothing is explicitly set, we also auto-detect a cookies.txt bundled in data/
// so it "just works" once the operator drops a file there.
function cookieArgs(){
 const p=process.env.YT_DLP_COOKIES_FILE||process.env.COOKIES_FILE;
 if(p&&fs.existsSync(p))return ['--cookies',p];
 const browser=process.env.YT_DLP_COOKIES_FROM_BROWSER;
 if(browser)return ['--cookies-from-browser',browser];
 const bundled=path.join(require('../utils').dataDir,'cookies.txt');
 if(fs.existsSync(bundled))return ['--cookies',bundled];
 return [];
}
async function info(url){if(!isUrl(url))throw new Error('Invalid URL');const {out}=await run(yt(),['--no-playlist','--dump-single-json','--no-warnings',...extractorArgs(),...cookieArgs(),url],90000);let j;try{j=JSON.parse(out)}catch{throw new Error('yt-dlp returned invalid media information.')}return {title:j.title||'Media',duration:j.duration||0,uploader:j.uploader||'',thumbnail:j.thumbnail||'',url:j.webpage_url||url,ext:j.ext||'',width:j.width||0,height:j.height||0,filesize:j.filesize||j.filesize_approx||0}}
// yt-dlp search (no API key): "ytsearchN:query" returns the top N results without
// downloading anything, using --flat-playlist so it's fast (metadata only).
async function searchYoutube(query,limit=5){
 const q=String(query||'').trim();if(!q)throw new Error('Please provide a search term.');
 const n=Math.max(1,Math.min(10,Number(limit)||5));
 const {out}=await run(yt(),['--no-warnings','--flat-playlist','--dump-json',...extractorArgs(),...cookieArgs(),`ytsearch${n}:${q}`],60000);
 const items=String(out||'').split('\n').filter(Boolean).map(line=>{try{return JSON.parse(line)}catch{return null}}).filter(Boolean)
  .map(j=>({title:j.title||'Untitled',url:j.url||j.webpage_url||(j.id?`https://www.youtube.com/watch?v=${j.id}`:''),uploader:j.uploader||j.channel||'',duration:j.duration||0}))
  .filter(x=>x.url);
 if(!items.length)throw new Error('No results found for that search.');
 return items.slice(0,n);
}
// Several distinct player-client strategies are tried in sequence (not just one
// combined --extractor-args call) because YouTube's bot-check can reject the whole
// request before yt-dlp gets a chance to internally fall back between clients. After
// the first failure that looks like a bot-check/signature issue, we also try a single
// "yt-dlp -U" self-update — outdated yt-dlp builds are the single most common cause of
// these failures, since YouTube changes frequently and older builds lack the fix.
// Widened the strategy list: "web" and "web,mweb" are added because cookies are
// only honored by browser-style clients (web/mweb) — android/ios/tv_embedded largely
// ignore the cookie jar and rely on client spoofing alone, which YouTube has been
// closing off. Putting a cookie-aware client early gives the bundled cookies.txt an
// actual chance to matter instead of only helping the info()/search() calls.
const CLIENT_STRATEGIES=(process.env.YT_DLP_PLAYER_CLIENTS?[process.env.YT_DLP_PLAYER_CLIENTS]:['web,tv_embedded,android,ios,mweb','tv_embedded','web,mweb','android','ios','web_creator']);
async function selfUpdate(){try{await run(yt(),['-U'],90000)}catch{}}
async function attemptDownload(url,kind,quality,clients){
 const maxMb=Math.max(1,Number(process.env.MAX_DOWNLOAD_MB||100));
 const prefix=path.join(downloadDir,`mrdkxx-${Date.now()}-${Math.random().toString(16).slice(2)}`);const template=`${prefix}.%(ext)s`;
 const args=['--no-playlist','--no-warnings','--max-filesize',`${maxMb}M`,'-o',template,'--restrict-filenames','--retries','2','--fragment-retries','2','--no-part','--extractor-args',`youtube:player_client=${clients}`,...cookieArgs()];
 if(kind==='audio')args.push('-x','--audio-format','mp3','--audio-quality','0');
 else {const q=quality==='small'?'best[height<=480]/best':quality==='medium'?'best[height<=720]/best':'bestvideo*+bestaudio/best';args.push('-f',q,'--merge-output-format','mp4')}
 args.push(url);
 try{
  await run(yt(),args);
  const files=fs.readdirSync(downloadDir).filter(f=>f.startsWith(path.basename(prefix)+'.')&&!f.endsWith('.part')&&!f.endsWith('.ytdl'));
  if(!files.length)throw new Error('No output file was produced.');
  const file=path.join(downloadDir,files[0]);
  const mb=fs.statSync(file).size/1024/1024;
  if(mb>maxMb){cleanupPrefix(path.basename(prefix));throw new Error(`File is larger than ${maxMb} MB`)}
  return file;
 }catch(e){cleanupPrefix(path.basename(prefix));throw e}
}
// Generic "download anything" fallback: yt-dlp only understands ~1800 known sites.
// For everything else (direct file links — PDFs, ZIPs, images, raw MP4s, APKs, etc.,
// or a site yt-dlp has no extractor for), this streams the URL's raw bytes to disk
// with no API key and no site-specific logic needed. This is what makes "any URL ->
// download whatever it is" actually true instead of only covering yt-dlp's sites.
async function genericDownload(url){
 const maxMb=Math.max(1,Number(process.env.MAX_DOWNLOAD_MB||100));
 const maxBytes=maxMb*1024*1024;
 const r=await fetch(url,{redirect:'follow',headers:{'user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) MR-DKxx/4.5'}});
 if(!r.ok||!r.body)throw new Error(`Direct download failed: HTTP ${r.status}`);
 const len=Number(r.headers.get('content-length')||0);
 if(len&&len>maxBytes)throw new Error(`File is larger than ${maxMb} MB`);
 const ct=(r.headers.get('content-type')||'').split(';')[0].trim().toLowerCase();
 // If the server answered with an HTML page (not a direct file), this is almost
 // always a video/social site whose page yt-dlp failed to extract from (bot-check,
 // login wall, private content, etc.) — NOT a raw downloadable file. Saving that
 // HTML as a fake ".bin"/media file previously produced unplayable garbage that
 // silently looked like a successful download. Fail loudly instead so the real
 // yt-dlp error (which explains what actually went wrong) reaches the user.
 if(ct.startsWith('text/html')||ct.startsWith('application/xhtml+xml'))throw new Error('That link points to a webpage, not a direct downloadable media file.');
 const urlExt=(()=>{try{const p=new URL(url).pathname;const e=path.extname(p).replace('.','').toLowerCase();return /^[a-z0-9]{1,5}$/.test(e)?e:''}catch{return ''}})();
 const ctExtMap={'video/mp4':'mp4','video/webm':'webm','video/quicktime':'mov','audio/mpeg':'mp3','audio/mp4':'m4a','audio/ogg':'ogg','audio/wav':'wav','image/jpeg':'jpg','image/png':'png','image/webp':'webp','image/gif':'gif','application/pdf':'pdf','application/zip':'zip','application/x-zip-compressed':'zip','text/plain':'txt','application/json':'json','application/vnd.android.package-archive':'apk','application/octet-stream':''};
 const ext=urlExt||ctExtMap[ct]||'bin';
 const file=path.join(downloadDir,`mrdkxx-direct-${Date.now()}-${Math.random().toString(16).slice(2)}.${ext}`);
 const ws=fs.createWriteStream(file);
 let written=0,exceeded=false;
 try{
  for await(const chunk of r.body){
   written+=chunk.length;
   if(written>maxBytes){exceeded=true;break}
   if(!ws.write(chunk))await new Promise(res=>ws.once('drain',res));
  }
 }finally{await new Promise(res=>ws.end(res))}
 if(exceeded){try{fs.unlinkSync(file)}catch{};throw new Error(`File is larger than ${maxMb} MB`)}
 if(!written){try{fs.unlinkSync(file)}catch{};throw new Error('The link returned no data.')}
 return {file,contentType:ct,ext};
}
// ---------------------------------------------------------------------------
// COBALT ENGINE (new download method, independent of yt-dlp)
// ---------------------------------------------------------------------------
// yt-dlp running directly on a VPS is exactly the pattern YouTube/Instagram/
// TikTok's anti-bot systems are built to catch (datacenter IP + no real
// browser session), so it can keep failing there no matter how many player
// clients or cookies are tried. Cobalt (https://cobalt.tools, open-source,
// AGPL-3.0) is a *different* engine: many independent people run their own
// "instances" of it, each with its own IP/cookies, and cobalt.directory
// (https://cobalt.directory) publishes a live, auto-updated list of which
// instances currently work for which site. We query that directory at
// request time (never hardcoded — instances go up/down constantly) and ask
// a handful of currently-working instances to resolve the direct media URL,
// then stream that URL to disk ourselves. No signup, no API key.
let cobaltInstancesCache={at:0,data:null,reachable:null};
// A handful of instances run by cobalt's own creators (imput.net) as a fallback
// for when cobalt.directory itself can't be reached from this VPS (some hosts
// firewall unfamiliar domains, or the directory is briefly down). These are
// tried in addition to whatever the directory returns, never instead of it.
const KNOWN_FALLBACK_INSTANCES=['https://nachos.imput.net','https://sunny.imput.net','https://blossom.imput.net','https://kityune.imput.net'];
async function getCobaltInstances(){
 const now=Date.now();
 if(cobaltInstancesCache.data&&now-cobaltInstancesCache.at<20*60*1000)return cobaltInstancesCache;
 try{
  const r=await fetch('https://cobalt.directory/api/working?type=api',{headers:{'user-agent':'MrDKxxBot/4.10 (+https://github.com)'}});
  if(!r.ok)throw new Error(`directory HTTP ${r.status}`);
  const j=await r.json();
  cobaltInstancesCache={at:now,data:j.data||{},reachable:true};
  return cobaltInstancesCache;
 }catch(e){
  logger.warn(e.message,'cobalt.directory lookup failed');
  // Remember that the LAST fetch attempt actually failed (network/DNS/firewall
  // issue reaching cobalt.directory) vs. it succeeding but returning nothing
  // for a given service — these need different error messages downstream.
  return {at:now,data:cobaltInstancesCache.data||{},reachable:false};
 }
}
function detectCobaltService(url){
 try{
  const h=new URL(url).hostname.replace(/^www\./,'').toLowerCase();
  const map=[[/youtube\.com|youtu\.be/,'youtube'],[/tiktok\.com/,'tiktok'],[/instagram\.com/,'instagram'],[/facebook\.com|fb\.watch/,'facebook'],[/twitter\.com|x\.com/,'twitter'],[/reddit\.com/,'reddit'],[/soundcloud\.com/,'soundcloud'],[/vimeo\.com/,'vimeo'],[/pinterest\.com|pin\.it/,'pinterest'],[/tumblr\.com/,'tumblr'],[/twitch\.tv/,'twitch-clips'],[/streamable\.com/,'streamable'],[/dailymotion\.com/,'dailymotion'],[/bilibili\.com/,'bilibili'],[/vk\.com/,'vk'],[/snapchat\.com/,'snapchat'],[/vk\.com/,'vk']];
  for(const [re,name] of map)if(re.test(h))return name;
  return null;
 }catch{return null}
}
async function cobaltResolveOnce(instance,url,kind,quality){
 const body={url,downloadMode:kind==='audio'?'audio':'auto'};
 if(kind==='audio')body.audioFormat='mp3';else body.videoQuality=quality==='small'?'480':quality==='medium'?'720':'1080';
 const ctrl=typeof AbortController!=='undefined'?new AbortController():null;
 const timer=ctrl?setTimeout(()=>ctrl.abort(),20000):null;
 try{
  const r=await fetch(instance.replace(/\/$/,'')+'/',{method:'POST',headers:{'content-type':'application/json','accept':'application/json','user-agent':'MrDKxxBot/4.10'},body:JSON.stringify(body),signal:ctrl?.signal});
  const j=await r.json().catch(()=>null);
  if(!j)throw new Error(`HTTP ${r.status}, invalid/non-JSON response`);
  if(j.status==='error')throw new Error(String(j.error?.code||j.text||'Instance returned an error'));
  if((j.status==='tunnel'||j.status==='redirect')&&j.url)return j.url;
  if(j.status==='picker'&&Array.isArray(j.picker)&&j.picker.length&&j.picker[0].url)return j.picker[0].url;
  throw new Error(`Unexpected response status: ${j.status||'unknown'}`);
 }finally{if(timer)clearTimeout(timer)}
}
async function cobaltDownload(url,kind='video',quality='best'){
 const {data,reachable}=await getCobaltInstances();
 const service=detectCobaltService(url);
 let candidates=(service&&Array.isArray(data[service]))?data[service].slice():[];
 if(!candidates.length&&data['Frontend'])candidates=data['Frontend'].slice();
 // Always add the known official instances too (deduped) — cheap insurance
 // against the directory's list being stale/empty for this exact service.
 for(const f of KNOWN_FALLBACK_INSTANCES)if(!candidates.includes(f))candidates.push(f);
 candidates=candidates.slice(0,10);
 if(!candidates.length){
  throw new Error(reachable===false?'Could not reach cobalt.directory from this server (network/firewall issue) — see the health check.':'No cobalt instances are currently listed as working for this link — try again shortly.');
 }
 let lastErr=null,tried=0;
 for(const instance of candidates){
  tried++;
  try{
   const mediaUrl=await cobaltResolveOnce(instance,url,kind,quality);
   const g=await genericDownload(mediaUrl);
   return g.file;
  }catch(e){lastErr=new Error(`${instance}: ${e.message}`)}
 }
 throw lastErr?new Error(`All ${tried} tried cobalt instance(s) failed. Last: ${lastErr.message}`):new Error('All available cobalt instances failed for this link.');
}
// Diagnostic helper for the /health command and the owner: confirms the VPS can
// actually reach cobalt.directory at all (some hosts firewall outbound traffic
// to unfamiliar domains) and reports how many working instances it currently
// knows about, independent of trying to download anything.
async function checkCobaltReachable(){
 try{
  const {data,reachable}=await getCobaltInstances();
  if(reachable===false)return {ok:false,detail:'Could not reach cobalt.directory (network/firewall issue on this server).'};
  const services=Object.keys(data||{});
  if(!services.length)return {ok:false,detail:'Reached cobalt.directory but it returned no instance data.'};
  const total=new Set(services.flatMap(s=>data[s]||[])).size;
  return {ok:true,detail:`${total} known instance(s) across ${services.length} service(s).`};
 }catch(e){return {ok:false,detail:e.message}}
}
// ---------------------------------------------------------------------------
// INVIDIOUS ENGINE — open-source YouTube front-end, no API key, VPS-friendly
// ---------------------------------------------------------------------------
// Invidious instances act as proxies that fetch YouTube content with their own
// IPs/sessions, bypassing the datacenter-IP bot-check that blocks yt-dlp.
// The instance list is fetched fresh from api.invidious.io every 30 min.
const INVIDIOUS_FALLBACK=['https://invidious.nerdvpn.de','https://invidious.privacyredirect.com','https://yt.drgnz.club','https://iv.datura.network','https://invidious.fdn.fr'];
let invidiousCache={at:0,list:null};
function extractYouTubeId(url){
 try{
  const u=new URL(url);
  if(u.hostname.replace(/^www\./,'').match(/youtube\.com/)){return u.searchParams.get('v')||u.pathname.split('/').filter(Boolean).find(s=>/^[A-Za-z0-9_-]{11}$/.test(s))||null}
  if(u.hostname.replace(/^www\./,'').match(/youtu\.be/)){return u.pathname.split('/').filter(Boolean)[0]||null}
 }catch{}
 return null;
}
async function getInvidiousInstances(){
 const now=Date.now();
 if(invidiousCache.list&&now-invidiousCache.at<30*60*1000)return invidiousCache.list;
 try{
  const r=await fetch('https://api.invidious.io/instances.json?sort_by=health&pretty=1',{headers:{'user-agent':'MrDKxxBot/4.12'},signal:AbortSignal.timeout?AbortSignal.timeout(10000):undefined});
  if(!r.ok)throw new Error('HTTP '+r.status);
  const j=await r.json();
  const list=Array.isArray(j)?j.filter(([,info])=>info?.type==='https'&&info?.stats).map(([,info])=>info.uri.replace(/\/$/,'')).filter(Boolean).slice(0,12):[];
  if(list.length){invidiousCache={at:now,list:list};return list;}
 }catch(e){logger.warn(e.message,'invidious instance fetch failed');}
 return INVIDIOUS_FALLBACK;
}
async function invidiousDownload(url,kind='video',quality='best'){
 const videoId=extractYouTubeId(url);
 if(!videoId)throw new Error('Not a recognisable YouTube URL');
 const instances=await getInvidiousInstances();
 let lastErr=null;
 for(const base of instances.slice(0,8)){
  try{
   const ctrl=typeof AbortController!=='undefined'?new AbortController():null;
   const timer=ctrl?setTimeout(()=>ctrl.abort(),15000):null;
   let apiUrl;
   try{
    const r=await fetch(`${base}/api/v1/videos/${videoId}?fields=adaptiveFormats,formatStreams`,{headers:{'user-agent':'MrDKxxBot/4.12','accept':'application/json'},signal:ctrl?.signal});
    if(!r.ok)throw new Error(`HTTP ${r.status}`);
    const j=await r.json();
    if(j.error)throw new Error(j.error);
    if(kind==='audio'){
     // pick best audio-only stream
     const streams=(j.adaptiveFormats||[]).filter(f=>f.type&&f.type.startsWith('audio/')&&f.url);
     streams.sort((a,b)=>(Number(b.bitrate||0))-(Number(a.bitrate||0)));
     if(!streams.length)throw new Error('No audio streams found');
     apiUrl=streams[0].url;
    }else{
     const maxH=quality==='small'?480:quality==='medium'?720:1080;
     // prefer combined format (formatStreams), fall back to adaptive
     const combined=(j.formatStreams||[]).filter(f=>f.url&&f.resolution);
     combined.sort((a,b)=>{const ha=parseInt(a.resolution)||0,hb=parseInt(b.resolution)||0;return hb-ha});
     const best=combined.find(f=>parseInt(f.resolution||'0')<=maxH)||combined[0];
     if(best?.url){apiUrl=best.url}
     else{
      const adaptive=(j.adaptiveFormats||[]).filter(f=>f.type&&f.type.startsWith('video/')&&f.url);
      adaptive.sort((a,b)=>(Number(b.height||0))-(Number(a.height||0)));
      const v=adaptive.find(f=>Number(f.height||0)<=maxH)||adaptive[0];
      if(!v?.url)throw new Error('No video streams found');
      apiUrl=v.url;
     }
    }
   }finally{if(timer)clearTimeout(timer)}
   // Stream-download the resolved media URL
   const g=await genericDownload(apiUrl);
   // If audio was requested and we got a webm/opus, convert to mp3
   if(kind==='audio'&&g.ext!=='mp3'){
    try{const mp3=await transcode(g.file,{type:'audio',format:'mp3'});cleanup(g.file);return mp3}catch{return g.file}
   }
   return g.file;
  }catch(e){lastErr=new Error(`${base}: ${e.message}`);}
 }
 throw lastErr||new Error('All Invidious instances failed');
}
// ---------------------------------------------------------------------------
// PIPED ENGINE — another open-source YouTube front-end proxy, no API key
// ---------------------------------------------------------------------------
const PIPED_FALLBACK=['https://pipedapi.kavin.rocks','https://pipedapi.syncpundit.io','https://pipedapi.moomoo.me','https://piped-api.garudalinux.org','https://api.piped.yt'];
let pipedCache={at:0,list:null};
async function getPipedInstances(){
 const now=Date.now();
 if(pipedCache.list&&now-pipedCache.at<30*60*1000)return pipedCache.list;
 try{
  const r=await fetch('https://piped-instances.kavin.rocks/',{headers:{'user-agent':'MrDKxxBot/4.12'},signal:AbortSignal.timeout?AbortSignal.timeout(8000):undefined});
  if(!r.ok)throw new Error('HTTP '+r.status);
  const j=await r.json();
  const list=Array.isArray(j)?j.map(x=>String(x.api_url||'').replace(/\/$/,'')).filter(x=>x.startsWith('https://')).slice(0,10):[];
  if(list.length){pipedCache={at:now,list:list};return list;}
 }catch(e){logger.warn(e.message,'piped instance fetch failed');}
 return PIPED_FALLBACK;
}
async function pipedDownload(url,kind='video',quality='best'){
 const videoId=extractYouTubeId(url);
 if(!videoId)throw new Error('Not a recognisable YouTube URL');
 const instances=await getPipedInstances();
 let lastErr=null;
 for(const base of instances.slice(0,6)){
  try{
   const ctrl=typeof AbortController!=='undefined'?new AbortController():null;
   const timer=ctrl?setTimeout(()=>ctrl.abort(),15000):null;
   let mediaUrl;
   try{
    const r=await fetch(`${base}/streams/${videoId}`,{headers:{'user-agent':'MrDKxxBot/4.12','accept':'application/json'},signal:ctrl?.signal});
    if(!r.ok)throw new Error(`HTTP ${r.status}`);
    const j=await r.json();
    if(j.error)throw new Error(j.error);
    if(kind==='audio'){
     const streams=(j.audioStreams||[]).filter(s=>s.url);
     streams.sort((a,b)=>(Number(b.bitrate||0))-(Number(a.bitrate||0)));
     if(!streams.length)throw new Error('No audio streams from Piped');
     mediaUrl=streams[0].url;
    }else{
     const maxH=quality==='small'?480:quality==='medium'?720:1080;
     const streams=(j.videoStreams||[]).filter(s=>s.url&&s.videoOnly===false);
     streams.sort((a,b)=>{const ha=parseInt(a.quality||'0'),hb=parseInt(b.quality||'0');return hb-ha});
     const pick=streams.find(s=>parseInt(s.quality||'0')<=maxH)||streams[0];
     if(!pick?.url)throw new Error('No combined video streams from Piped');
     mediaUrl=pick.url;
    }
   }finally{if(timer)clearTimeout(timer)}
   const g=await genericDownload(mediaUrl);
   if(kind==='audio'&&g.ext!=='mp3'){
    try{const mp3=await transcode(g.file,{type:'audio',format:'mp3'});cleanup(g.file);return mp3}catch{return g.file}
   }
   return g.file;
  }catch(e){lastErr=new Error(`${base}: ${e.message}`);}
 }
 throw lastErr||new Error('All Piped instances failed');
}
// ---------------------------------------------------------------------------
// NOEMBED / OEMBED ENGINE — lightweight metadata + direct-link resolver
// ---------------------------------------------------------------------------
// For short videos/reels on sites that support oEmbed (Vimeo, Dailymotion,
// Streamable, etc.) this can surface a direct media URL without any binary.
async function noembedResolve(url){
 const r=await fetch(`https://noembed.com/embed?url=${encodeURIComponent(url)}`,{headers:{'user-agent':'MrDKxxBot/4.12'}});
 if(!r.ok)throw new Error(`noembed HTTP ${r.status}`);
 const j=await r.json();
 // noembed returns a url field if it could resolve to a direct media link
 if(j.url&&!String(j.url).includes('<'))return j.url;
 throw new Error('noembed did not return a direct media URL');
}
async function download(url,kind='video',quality='best'){
 if(!isUrl(url))throw new Error('Invalid URL');
 // ── ENGINE 1: Cobalt ──────────────────────────────────────────────────────
 // Best for TikTok, Instagram, Twitter/X, Reddit, Pinterest, SoundCloud, etc.
 // Routes around datacenter-IP bot-checks using community-run proxy instances.
 let cobaltErr=null;
 if(detectCobaltService(url)){
  try{return await cobaltDownload(url,kind,quality)}catch(e){cobaltErr=e;logger.warn(e.message,'cobalt engine failed, trying next engine')}
 }
 // ── ENGINE 2: Invidious ───────────────────────────────────────────────────
 // Best for YouTube: open-source front-end instances act as proxies with their
 // own cookies/IPs. Bypasses the same datacenter bot-check that blocks yt-dlp.
 const isYouTube=/youtube\.com|youtu\.be/i.test(url);
 let invidiousErr=null,pipedErr=null;
 if(isYouTube){
  try{return await invidiousDownload(url,kind,quality)}catch(e){invidiousErr=e;logger.warn(e.message,'invidious engine failed, trying piped')}
  // ── ENGINE 3: Piped ────────────────────────────────────────────────────
  // Second open-source YouTube proxy. Different instance pool than Invidious.
  try{return await pipedDownload(url,kind,quality)}catch(e){pipedErr=e;logger.warn(e.message,'piped engine failed, falling back to yt-dlp')}
 }
 let lastErr=null,updatedThisCall=false;
 for(let i=0;i<CLIENT_STRATEGIES.length;i++){
  try{return await attemptDownload(url,kind,quality,CLIENT_STRATEGIES[i])}
  catch(e){
   lastErr=e;
   const msg=String(e.message||'');
   const looksLikeBotCheck=/sign in|not a bot|precondition|player response|unable to extract|http error 403/i.test(msg);
   const unsupportedSite=/unsupported url|no extractor|unable to download webpage|is not a valid url/i.test(msg);
   // yt-dlp has no extractor for this link at all (a direct file, a site it doesn't
   // know, etc.) — stop the client-fallback loop immediately and hand off to the
   // generic raw-bytes downloader instead of wasting time retrying every client.
   if(unsupportedSite){
    try{const g=await genericDownload(url);return g.file}catch(e2){lastErr=e2;break}
   }
   // yt-dlp trails YouTube's anti-bot changes closely, so an outdated binary is the
   // single most common cause of this exact error. Try a self-update once per
   // download() call (not just once ever) the first time we see a bot-check-style
   // failure, then retry the SAME strategy again with the freshly updated binary.
   if(looksLikeBotCheck&&!updatedThisCall){
    updatedThisCall=true;
    await selfUpdate();
    try{return await attemptDownload(url,kind,quality,CLIENT_STRATEGIES[i])}catch(e2){lastErr=e2}
   }
   if(!looksLikeBotCheck&&!/format is not available|requested format/i.test(msg))break; // not a client-fallback-recoverable error, stop early
  }
 }
 if(lastErr){
  const msg=String(lastErr.message||'');
  if(/sign in|not a bot/i.test(msg)&&!/\[MR DKxx hint\]/.test(msg)){
   lastErr=new Error(`${msg}\n[MR DKxx hint] yt-dlp was auto-updated and retried but YouTube still blocked it. This almost always means the cookies.txt is stale or was exported on a different network/IP than this server. Re-export fresh cookies.txt while logged in to YouTube in a browser, then upload it again (or run the export from this same VPS's network if possible).`);
  }
 }
 // Last resort for anything still unresolved: try the raw-bytes path once more in
 // case the URL genuinely is a plain file yt-dlp merely reported a different error for.
 try{const g=await genericDownload(url);return g.file}catch{}
 // ── ENGINE 5: Cobalt final attempt (for unrecognized services skipped above) ─
 if(!cobaltErr){
  try{return await cobaltDownload(url,kind,quality)}catch(e){cobaltErr=e}
 }
 // ── ENGINE 6: noembed (Vimeo, Dailymotion, Streamable etc.) ──────────────
 if(!isYouTube&&!detectCobaltService(url)){
  try{const noembedUrl=await noembedResolve(url);const g=await genericDownload(noembedUrl);return g.file}catch(e){logger.warn(e.message,'noembed engine failed')}
 }
 // Surface ALL engines' actual failure reasons so the owner can diagnose.
 const parts=[];
 if(cobaltErr)parts.push(`Cobalt engine: ${cobaltErr.message}`);
 if(invidiousErr)parts.push(`Invidious engine: ${invidiousErr.message}`);
 if(pipedErr)parts.push(`Piped engine: ${pipedErr.message}`);
 if(lastErr)parts.push(`yt-dlp engine: ${lastErr.message}`);
 throw new Error(parts.join('\n\n')||'Download failed for an unknown reason.');
}
async function probe(file){if(!file||!fs.existsSync(file))throw new Error('Media file not found');const {out}=await run(ffmpeg(),['-hide_banner','-i',file],30000).catch(e=>({out:'',err:e.message}));const text=String(out||'');return {file:path.basename(file),size:fs.statSync(file).size,raw:text}}
async function transcode(input,{type='video',format='mp4',quality='medium'}={}){if(!fs.existsSync(input))throw new Error('Input media file not found');const out=path.join(tmpDir,`mrdkxx-${type}-${Date.now()}.${format}`);let args=['-y','-i',input];if(type==='video'){const vf=quality==='small'?'scale=-2:480':quality==='medium'?'scale=-2:720':'scale=1280:-2';args.push('-vf',vf,'-c:v','libx264','-preset','veryfast','-crf',quality==='small'?'30':quality==='medium'?'27':'24','-c:a','aac','-b:a','128k')}else if(type==='audio'){args.push('-vn','-c:a',format==='wav'?'pcm_s16le':'libmp3lame','-q:a','4')}else throw new Error('Unsupported transcode type');args.push(out);await run(ffmpeg(),args,180000);return out}
async function thumbnail(input){if(!fs.existsSync(input))throw new Error('Input media file not found');const out=path.join(tmpDir,`mrdkxx-thumb-${Date.now()}.jpg`);await run(ffmpeg(),['-y','-ss','00:00:01','-i',input,'-frames:v','1','-vf','scale=720:-2',out],60000);return out}
async function gif(input){if(!fs.existsSync(input))throw new Error('Input video not found');const out=path.join(tmpDir,`mrdkxx-${Date.now()}.gif`);await run(ffmpeg(),['-y','-t','6','-i',input,'-vf','fps=10,scale=480:-1:flags=lanczos',out],120000);return out}
async function audioExtract(input){return transcode(input,{type:'audio',format:'mp3'})}
function cleanup(file){try{if(file&&fs.existsSync(file))fs.unlinkSync(file)}catch(e){logger.warn(e.message,'cleanup failed')}}
function cleanupPrefix(prefix){for(const f of fs.readdirSync(downloadDir)){if(f.startsWith(prefix)){try{fs.unlinkSync(path.join(downloadDir,f))}catch{}}}}
module.exports={run,info,download,genericDownload,searchYoutube,probe,transcode,thumbnail,gif,audioExtract,cleanup,cleanupPrefix,checkBinaries,cobaltDownload,detectCobaltService,checkCobaltReachable,invidiousDownload,pipedDownload,extractYouTubeId};

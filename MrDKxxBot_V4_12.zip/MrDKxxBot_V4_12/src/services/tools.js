const QRCode=require('qrcode');
const crypto=require('crypto');
const path=require('path');
const {tmpDir}=require('../utils');

async function qr(text){const out=path.join(tmpDir,`qr-${Date.now()}.png`);await QRCode.toFile(out,String(text),{width:700,margin:2});return out}
function calc(expr){const s=String(expr||'').trim();if(!s||s.length>300||!/^[0-9+\-*/%().\s]+$/.test(s))throw new Error('Only arithmetic expressions are allowed');const v=Function(`"use strict";return (${s})`)();if(!Number.isFinite(Number(v)))throw new Error('Calculation returned a non-finite value');return v}
function isSafeUrl(v){try{const u=new URL(String(v));return ['http:','https:'].includes(u.protocol)}catch{return false}}
async function urlInfo(url){if(!isSafeUrl(url))throw new Error('Invalid URL');let r=null,last=null;for(const method of ['HEAD','GET'])try{r=await fetch(new URL(url),{method,redirect:'follow',headers:{'user-agent':'MR-DKxx/4.5'}});if(r.ok||method==='GET')break}catch(e){last=e}if(!r)throw last||new Error('URL request failed');let ct=r.headers.get('content-type')||'',title='';if(ct.includes('text/html')){let html='';try{html=await r.text()}catch{}title=(html.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1]||'').replace(/\s+/g,' ').trim().slice(0,180)}return {finalUrl:r.url||url,status:r.status,statusText:r.statusText||'',contentType:ct,contentLength:r.headers.get('content-length')||'',title:title||new URL(r.url||url).hostname}}
function uuid(){return crypto.randomUUID()}
function password(length=16){const n=Math.min(64,Math.max(6,Number(length)||16));const chars='ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%^&*_-+=';let out='';for(let i=0;i<n;i++)out+=chars[crypto.randomInt(chars.length)];return out}
function hash(text,algorithm='sha256'){const a=['md5','sha1','sha256','sha512'].includes(String(algorithm).toLowerCase())?String(algorithm).toLowerCase():'sha256';return crypto.createHash(a).update(String(text)).digest('hex')}
function base64Encode(text){return Buffer.from(String(text),'utf8').toString('base64')}
function base64Decode(text){const s=String(text).trim();if(!/^[A-Za-z0-9+/]*={0,2}$/.test(s)||s.length%4===1)throw new Error('Invalid Base64');return Buffer.from(s,'base64').toString('utf8')}
function randomNumber(min=1,max=100){let a=Math.ceil(Number(min)),b=Math.floor(Number(max));if(!Number.isFinite(a)||!Number.isFinite(b)||a>b)throw new Error('Invalid range');return crypto.randomInt(a,b+1)}
function jsonFormat(text){return JSON.stringify(JSON.parse(String(text)),null,2)}
function timestamp(value=''){const d=value?new Date(value):new Date();if(Number.isNaN(d.getTime()))throw new Error('Invalid date/time');return {iso:d.toISOString(),unix:Math.floor(d.getTime()/1000),local:d.toString()}}
function unitConvert(value,from,to){const v=Number(value);if(!Number.isFinite(v))throw new Error('Invalid number');const f=String(from).toLowerCase(),t=String(to).toLowerCase();const table={m:1,km:1000,cm:0.01,mm:0.001,mi:1609.344,ft:0.3048,yd:0.9144,in:0.0254,kg:1,g:0.001,lb:0.45359237,oz:0.028349523125,l:1,ml:0.001};if(!(f in table)||!(t in table))throw new Error('Supported units: m km cm mm mi ft yd in kg g lb oz l ml');return v*table[f]/table[t]}
// Free, no-API-key currency conversion via open.er-api.com (161 currencies, daily rates).
async function currencyConvert(amount,from,to){
 const amt=Number(amount);if(!Number.isFinite(amt))throw new Error('Invalid amount');
 const f=String(from||'').trim().toUpperCase(),tgt=String(to||'').trim().toUpperCase();
 if(!/^[A-Z]{3}$/.test(f)||!/^[A-Z]{3}$/.test(tgt))throw new Error('Use 3-letter currency codes, e.g. USD LKR');
 const r=await fetch(`https://open.er-api.com/v6/latest/${f}`,{headers:{'user-agent':'MR-DKxx/4.5'}});
 if(!r.ok)throw new Error('Currency service is unavailable right now.');
 const data=await r.json();
 if(data.result!=='success')throw new Error(data['error-type']||'Currency lookup failed');
 const rate=data.rates?.[tgt];
 if(!rate)throw new Error(`Unknown currency code: ${tgt}`);
 return {amount:amt,from:f,to:tgt,rate,result:amt*rate,updated:data.time_last_update_utc||''};
}
// Free, no-API-key weather via Open-Meteo (geocoding + forecast).
async function weather(city){
 const name=String(city||'').trim();if(!name)throw new Error('Please provide a city name');
 const g=await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(name)}&count=1`,{headers:{'user-agent':'MR-DKxx/4.5'}});
 if(!g.ok)throw new Error('Location service is unavailable right now.');
 const gj=await g.json();
 const place=gj.results?.[0];
 if(!place)throw new Error(`Could not find a location named "${name}"`);
 const f=await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${place.latitude}&longitude=${place.longitude}&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m&timezone=auto`,{headers:{'user-agent':'MR-DKxx/4.5'}});
 if(!f.ok)throw new Error('Weather service is unavailable right now.');
 const fj=await f.json();
 const c=fj.current||{};
 const codes={0:'☀️ Clear sky',1:'🌤️ Mostly clear',2:'⛅ Partly cloudy',3:'☁️ Overcast',45:'🌫️ Fog',48:'🌫️ Fog',51:'🌦️ Light drizzle',53:'🌦️ Drizzle',55:'🌦️ Heavy drizzle',61:'🌧️ Light rain',63:'🌧️ Rain',65:'🌧️ Heavy rain',71:'🌨️ Light snow',73:'🌨️ Snow',75:'🌨️ Heavy snow',80:'🌦️ Rain showers',81:'🌦️ Rain showers',82:'⛈️ Violent showers',95:'⛈️ Thunderstorm',96:'⛈️ Thunderstorm with hail',99:'⛈️ Thunderstorm with hail'};
 return {
  place:`${place.name}${place.country?', '+place.country:''}`,
  temp:c.temperature_2m,feelsLike:c.apparent_temperature,humidity:c.relative_humidity_2m,
  wind:c.wind_speed_10m,precipitation:c.precipitation,
  condition:codes[c.weather_code]||'🌡️ Weather data',
  timezone:fj.timezone||''
 };
}
// Free, no-API-key top headlines via Google News RSS.
async function newsHeadlines(topic=''){
 const q=String(topic||'').trim();
 const url=q?`https://news.google.com/rss/search?q=${encodeURIComponent(q)}&hl=en-US&gl=US&ceid=US:en`:'https://news.google.com/rss?hl=en-US&gl=US&ceid=US:en';
 const r=await fetch(url,{headers:{'user-agent':'MR-DKxx/4.5'}});
 if(!r.ok)throw new Error('News service is unavailable right now.');
 const xml=await r.text();
 const items=[...xml.matchAll(/<item>([\s\S]*?)<\/item>/g)].slice(0,8).map(m=>{
  const block=m[1];
  const title=(block.match(/<title>([\s\S]*?)<\/title>/)?.[1]||'').replace(/<!\[CDATA\[|\]\]>/g,'').trim();
  const link=(block.match(/<link>([\s\S]*?)<\/link>/)?.[1]||'').trim();
  const source=(block.match(/<source[^>]*>([\s\S]*?)<\/source>/)?.[1]||'').replace(/<!\[CDATA\[|\]\]>/g,'').trim();
  return {title,link,source};
 }).filter(x=>x.title);
 if(!items.length)throw new Error('No headlines found.');
 return items;
}
// Free, no-API-key prayer times via Aladhan API.
async function prayerTimes(city,country){
 const c=String(city||'').trim(),co=String(country||'').trim();
 if(!c)throw new Error('Please provide a city (and optionally a country).');
 const url=`https://api.aladhan.com/v1/timingsByCity?city=${encodeURIComponent(c)}&country=${encodeURIComponent(co||'')}&method=2`;
 const r=await fetch(url,{headers:{'user-agent':'MR-DKxx/4.5'}});
 if(!r.ok)throw new Error('Prayer times service is unavailable right now.');
 const j=await r.json();
 if(j.code!==200||!j.data)throw new Error('Could not find prayer times for that location.');
 const t=j.data.timings;
 return {date:j.data.date?.readable||'',fajr:t.Fajr,dhuhr:t.Dhuhr,asr:t.Asr,maghrib:t.Maghrib,isha:t.Isha,place:`${c}${co?', '+co:''}`};
}
function bmi(weightKg,heightCm){
 const w=Number(weightKg),h=Number(heightCm)/100;
 if(!Number.isFinite(w)||w<=0||!Number.isFinite(h)||h<=0)throw new Error('Use: weight(kg) height(cm) — example: 70 175');
 const value=w/(h*h);
 const category=value<18.5?'Underweight':value<25?'Normal weight':value<30?'Overweight':'Obese';
 return {value:Math.round(value*10)/10,category};
}
function ageCalc(dob){
 const d=new Date(String(dob).trim());
 if(isNaN(d.getTime()))throw new Error('Use a date like: 1998-05-20 or 20/05/1998');
 const now=new Date();
 if(d>now)throw new Error('That date is in the future.');
 let years=now.getFullYear()-d.getFullYear(),months=now.getMonth()-d.getMonth(),days=now.getDate()-d.getDate();
 if(days<0){months--;days+=new Date(now.getFullYear(),now.getMonth(),0).getDate()}
 if(months<0){years--;months+=12}
 const totalDays=Math.floor((now-d)/86400000);
 return {years,months,days,totalDays};
}
// Free, no-API-key IP/domain lookup via ipapi.co.
async function ipLookup(query){
 const q=String(query||'').trim();
 const url=q?`https://ipapi.co/${encodeURIComponent(q)}/json/`:'https://ipapi.co/json/';
 const r=await fetch(url,{headers:{'user-agent':'MR-DKxx/4.5'}});
 if(!r.ok)throw new Error('IP lookup service is unavailable right now.');
 const j=await r.json();
 if(j.error)throw new Error(j.reason||'Could not look up that address.');
 return {ip:j.ip,city:j.city,region:j.region,country:j.country_name,isp:j.org||j.asn||'',timezone:j.timezone,lat:j.latitude,lon:j.longitude};
}
// Free, no-API-key dad joke via icanhazdadjoke.com.
async function dadJoke(){
 const r=await fetch('https://icanhazdadjoke.com/',{headers:{Accept:'application/json','user-agent':'MR-DKxx/4.5'}});
 if(!r.ok)throw new Error('Joke service is unavailable right now.');
 const j=await r.json();
 if(!j.joke)throw new Error('No joke returned.');
 return j.joke;
}
// Free, no-API-key inspirational quote via ZenQuotes.
async function randomQuote(){
 const r=await fetch('https://zenquotes.io/api/random',{headers:{'user-agent':'MR-DKxx/4.5'}});
 if(!r.ok)throw new Error('Quote service is unavailable right now.');
 const j=await r.json();
 const q=Array.isArray(j)?j[0]:null;
 if(!q?.q)throw new Error('No quote returned.');
 return {text:q.q,author:q.a||'Unknown'};
}
const EIGHT_BALL_ANSWERS=['Yes, definitely.','It is certain.','Without a doubt.','Yes.','Most likely.','Outlook good.','Signs point to yes.','Reply hazy, try again.','Ask again later.','Better not tell you now.','Cannot predict now.',"Don't count on it.",'My reply is no.','My sources say no.','Outlook not so good.','Very doubtful.'];
function magic8ball(){return EIGHT_BALL_ANSWERS[crypto.randomInt(EIGHT_BALL_ANSWERS.length)]}
function rollDice(sides=6,count=1){
 const s=Math.min(1000,Math.max(2,Number(sides)||6));
 const n=Math.min(20,Math.max(1,Number(count)||1));
 const rolls=Array.from({length:n},()=>crypto.randomInt(1,s+1));
 return {sides:s,rolls,total:rolls.reduce((a,b)=>a+b,0)};
}
function coinFlip(){return crypto.randomInt(2)===0?'Heads':'Tails'}
// Free, no-API-key random dog photo via dog.ceo.
async function randomDogImage(){
 const r=await fetch('https://dog.ceo/api/breeds/image/random',{headers:{'user-agent':'MR-DKxx/4.5'}});
 if(!r.ok)throw new Error('Dog image service is unavailable right now.');
 const j=await r.json();
 if(j.status!=='success'||!j.message)throw new Error('No dog image returned.');
 return j.message;
}
// Free, no-API-key random cat photo via TheCatAPI's public search endpoint.
async function randomCatImage(){
 const r=await fetch('https://api.thecatapi.com/v1/images/search',{headers:{'user-agent':'MR-DKxx/4.5'}});
 if(!r.ok)throw new Error('Cat image service is unavailable right now.');
 const j=await r.json();
 const url=j?.[0]?.url;
 if(!url)throw new Error('No cat image returned.');
 return url;
}
// Free, no-API-key life advice via adviceslip.com.
async function advice(){
 const r=await fetch('https://api.adviceslip.com/advice',{headers:{'user-agent':'MR-DKxx/4.5'}});
 if(!r.ok)throw new Error('Advice service is unavailable right now.');
 const j=await r.json();
 const text=j?.slip?.advice;
 if(!text)throw new Error('No advice returned.');
 return text;
}
// Free, no-API-key trivia question via Open Trivia DB.
async function trivia(){
 const r=await fetch('https://opentdb.com/api.php?amount=1',{headers:{'user-agent':'MR-DKxx/4.5'}});
 if(!r.ok)throw new Error('Trivia service is unavailable right now.');
 const j=await r.json();
 const q=j?.results?.[0];
 if(!q)throw new Error('No trivia question returned.');
 const decode=(s)=>String(s||'').replace(/&#?\w+;/g,(e)=>{const map={'&amp;':'&','&quot;':'"','&#039;':"'",'&eacute;':'é','&uuml;':'ü','&ouml;':'ö','&auml;':'ä','&rsquo;':'’',' &ldquo;':'“','&rdquo;':'”'};return map[e]||e});
 const options=[...q.incorrect_answers.map(decode),decode(q.correct_answer)].sort(()=>Math.random()-0.5);
 return {category:decode(q.category),question:decode(q.question),options,answer:decode(q.correct_answer)};
}
// Free, no-API-key trivia fact about a number via numbersapi.com.
async function numberFact(n){
 const v=String(n||'').trim();
 const url=v&&/^-?\d+$/.test(v)?`https://numbersapi.com/${v}`:'https://numbersapi.com/random/trivia';
 const r=await fetch(url,{headers:{'user-agent':'MR-DKxx/4.5'}});
 if(!r.ok)throw new Error('Number fact service is unavailable right now.');
 return (await r.text()).trim();
}
// Free, no-API-key Chuck Norris joke via api.chucknorris.io.
async function chuckNorrisJoke(){
 const r=await fetch('https://api.chucknorris.io/jokes/random',{headers:{'user-agent':'MR-DKxx/4.5'}});
 if(!r.ok)throw new Error('Joke service is unavailable right now.');
 const j=await r.json();
 if(!j.value)throw new Error('No joke returned.');
 return j.value;
}
// Free, no-API-key URL shortener via is.gd.
async function shortenUrl(url){
 if(!isSafeUrl(url))throw new Error('Please send a valid http/https URL.');
 const r=await fetch(`https://is.gd/create.php?format=simple&url=${encodeURIComponent(url)}`,{headers:{'user-agent':'MR-DKxx/4.5'}});
 const text=(await r.text()).trim();
 if(!r.ok||!/^https?:\/\//.test(text))throw new Error(text||'URL shortening failed.');
 return text;
}
// Local, no-network word/character counter.
function wordCount(text){
 const s=String(text||'');
 const words=(s.trim().match(/\S+/g)||[]).length;
 const chars=s.length;
 const charsNoSpaces=s.replace(/\s/g,'').length;
 const sentences=(s.match(/[.!?]+(?:\s|$)/g)||[]).length||(s.trim()?1:0);
 return {words,chars,charsNoSpaces,sentences};
}
// Local, no-network text case converter. Returns all common variants.
function textCase(text){
 const s=String(text||'');
 const title=s.replace(/\w\S*/g,(w)=>w[0].toUpperCase()+w.slice(1).toLowerCase());
 const sentence=s.toLowerCase().replace(/(^\s*\w|[.!?]\s+\w)/g,(m)=>m.toUpperCase());
 return {upper:s.toUpperCase(),lower:s.toLowerCase(),title,sentence};
}
// Free, no-API-key Wikipedia search via MediaWiki API.
async function wikiSearch(query){
 const q=String(query||'').trim();if(!q)throw new Error('Please send a search term.');
 const url=`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(q.replace(/ /g,'_'))}`;
 const r=await fetch(url,{headers:{'user-agent':'MrDKxxBot/4.12','accept':'application/json'}});
 if(r.status===404){
  // Try search API if direct page lookup fails
  const sr=await fetch(`https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(q)}&format=json&utf8=1&srlimit=1`,{headers:{'user-agent':'MrDKxxBot/4.12'}});
  if(!sr.ok)throw new Error('Wikipedia service unavailable.');
  const sj=await sr.json();
  const top=sj.query?.search?.[0];
  if(!top)throw new Error(`No Wikipedia article found for "${q}".`);
  const r2=await fetch(`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(top.title.replace(/ /g,'_'))}`,{headers:{'user-agent':'MrDKxxBot/4.12','accept':'application/json'}});
  if(!r2.ok)throw new Error('Wikipedia article unavailable.');
  const j2=await r2.json();
  return {title:j2.title,extract:j2.extract?.slice(0,800)||'No summary.',url:j2.content_urls?.desktop?.page||''};
 }
 if(!r.ok)throw new Error('Wikipedia service unavailable.');
 const j=await r.json();
 if(j.type==='disambiguation')throw new Error(`"${j.title}" is a disambiguation page. Try a more specific search.`);
 return {title:j.title,extract:j.extract?.slice(0,800)||'No summary.',url:j.content_urls?.desktop?.page||''};
}
// Free, no-API-key English dictionary via dictionaryapi.dev (open source).
async function dictionary(word){
 const w=String(word||'').trim().split(/\s+/)[0];if(!w)throw new Error('Please send a word to look up.');
 const r=await fetch(`https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(w)}`,{headers:{'user-agent':'MrDKxxBot/4.12'}});
 if(r.status===404)throw new Error(`Word "${w}" not found in dictionary.`);
 if(!r.ok)throw new Error('Dictionary service unavailable.');
 const j=await r.json();
 const entry=Array.isArray(j)?j[0]:j;
 const meanings=(entry.meanings||[]).slice(0,3).map(m=>{
  const defs=m.definitions?.slice(0,2).map(d=>d.definition)||[];
  return {partOfSpeech:m.partOfSpeech,definitions:defs,synonyms:(m.synonyms||[]).slice(0,4)};
 });
 const phonetic=entry.phonetic||entry.phonetics?.find(p=>p.text)?.text||'';
 return {word:entry.word||w,phonetic,meanings};
}
// Free, no-API-key GitHub user/repo info via GitHub public API (60 req/hr).
async function githubInfo(query){
 const q=String(query||'').trim();if(!q)throw new Error('Send a GitHub username or user/repo.');
 const isRepo=q.includes('/');
 const url=isRepo?`https://api.github.com/repos/${q}`:`https://api.github.com/users/${q}`;
 const r=await fetch(url,{headers:{'user-agent':'MrDKxxBot/4.12','accept':'application/vnd.github+json'}});
 if(r.status===404)throw new Error(`"${q}" not found on GitHub.`);
 if(r.status===403)throw new Error('GitHub rate limit reached. Try again in a minute.');
 if(!r.ok)throw new Error('GitHub API unavailable.');
 const j=await r.json();
 if(isRepo){
  return {type:'repo',name:j.full_name,description:j.description||'',stars:j.stargazers_count,forks:j.forks_count,language:j.language||'-',topics:(j.topics||[]).slice(0,5),url:j.html_url,updated:j.updated_at?.slice(0,10)||''};
 }
 return {type:'user',login:j.login,name:j.name||'',bio:j.bio||'',repos:j.public_repos,followers:j.followers,following:j.following,url:j.html_url,joined:j.created_at?.slice(0,10)||''};
}
// Free, no-API-key country info via restcountries.com.
async function countryInfo(name){
 const n=String(name||'').trim();if(!n)throw new Error('Please send a country name.');
 const r=await fetch(`https://restcountries.com/v3.1/name/${encodeURIComponent(n)}?fields=name,capital,region,subregion,population,area,currencies,languages,flags,timezones,tld`,{headers:{'user-agent':'MrDKxxBot/4.12'}});
 if(r.status===404)throw new Error(`Country "${n}" not found.`);
 if(!r.ok)throw new Error('Country info service unavailable.');
 const j=await r.json();
 const c=Array.isArray(j)?j[0]:j;
 const currencies=Object.values(c.currencies||{}).map(x=>`${x.name} (${x.symbol||''})`).join(', ');
 const languages=Object.values(c.languages||{}).join(', ');
 return {name:c.name?.common||n,official:c.name?.official||'',capital:(c.capital||[])[0]||'-',region:c.region||'-',subregion:c.subregion||'-',population:c.population||0,area:c.area||0,currencies,languages,timezone:(c.timezones||[])[0]||'-',tld:(c.tld||[])[0]||'-',flag:c.flags?.emoji||''};
}
// Local, no-network Morse code encoder/decoder.
const MORSE_MAP={A:'.-',B:'-...',C:'-.-.',D:'-..',E:'.',F:'..-.',G:'--.',H:'....',I:'..',J:'.---',K:'-.-',L:'.-..',M:'--',N:'-.',O:'---',P:'.--.',Q:'--.-',R:'.-.',S:'...',T:'-',U:'..-',V:'...-',W:'.--',X:'-..-',Y:'-.--',Z:'--..',0:'-----',1:'.----',2:'..---',3:'...--',4:'....-',5:'.....',6:'-....',7:'--...',8:'---..',9:'----.','.':'.-.-.-',',':'--..--','?':'..--..','/':'-..-.','+':'.-.-.','-':'-....-','=':'-...-','@':'.--.-.'};
const REVERSE_MORSE=Object.fromEntries(Object.entries(MORSE_MAP).map(([k,v])=>[v,k]));
function morseCode(text){
 const s=String(text||'').trim();
 // auto-detect: if it looks like morse (only . - / spaces), decode; else encode
 if(/^[.\- /]+$/.test(s)){
  // decode morse
  const decoded=s.split(' / ').map(word=>word.split(' ').map(code=>REVERSE_MORSE[code]||'?').join('')).join(' ');
  return {mode:'decode',result:decoded};
 }
 // encode to morse
 const encoded=s.toUpperCase().split('').map(c=>{if(c===' ')return '/';return MORSE_MAP[c]||'?'}).join(' ');
 return {mode:'encode',result:encoded};
}
// Local, no-network Roman numeral encoder/decoder.
function romanNumerals(input){
 const s=String(input||'').trim();
 // decode if it looks like roman numerals
 if(/^[IVXLCDM]+$/i.test(s)){
  const vals={I:1,V:5,X:10,L:50,C:100,D:500,M:1000};
  const upper=s.toUpperCase();
  let result=0;
  for(let i=0;i<upper.length;i++){
   const curr=vals[upper[i]]||0,next=vals[upper[i+1]]||0;
   result+=curr<next?-curr:curr;
  }
  if(result<=0||result>3999)throw new Error('Invalid Roman numeral.');
  return {mode:'decode',input:upper,result};
 }
 // encode number to roman
 const n=parseInt(s,10);
 if(isNaN(n)||n<1||n>3999)throw new Error('Enter a number (1–3999) or valid Roman numerals (I–M).');
 const parts=[[1000,'M'],[900,'CM'],[500,'D'],[400,'CD'],[100,'C'],[90,'XC'],[50,'L'],[40,'XL'],[10,'X'],[9,'IX'],[5,'V'],[4,'IV'],[1,'I']];
 let rem=n,roman='';
 for(const [v,r] of parts){while(rem>=v){roman+=r;rem-=v}}
 return {mode:'encode',input:n,result:roman};
}
// Free, no-API-key fake person data generator (for dev/testing) — all local.
function fakePerson(){
 const firstM=['James','John','Robert','Michael','William','David','Richard','Joseph','Thomas','Charles','Amir','Carlos','Ravi','Sanjay','Mohamed','Liam','Noah','Oliver'];
 const firstF=['Mary','Patricia','Jennifer','Linda','Barbara','Elizabeth','Susan','Jessica','Sarah','Karen','Aisha','Sofia','Priya','Ayasha','Fatima','Emma','Olivia','Ava'];
 const last=['Smith','Johnson','Williams','Brown','Jones','Garcia','Miller','Davis','Wilson','Taylor','Anderson','Thomas','Jackson','White','Harris','Martin','Thompson','Lee'];
 const domains=['gmail.com','yahoo.com','outlook.com','proton.me','hotmail.com'];
 const cities=['New York','London','Paris','Tokyo','Sydney','Toronto','Dubai','Singapore','Mumbai','Colombo'];
 const isMale=Math.random()<0.5;
 const first=(isMale?firstM:firstF)[Math.floor(Math.random()*firstM.length)];
 const surname=last[Math.floor(Math.random()*last.length)];
 const birth=new Date(Date.now()-Math.random()*1.5e12-5e11);
 const email=`${first.toLowerCase()}.${surname.toLowerCase()}${Math.floor(Math.random()*999)+1}@${domains[Math.floor(Math.random()*domains.length)]}`;
 const phone=`+${Math.floor(Math.random()*9)+1}${Array.from({length:9},()=>Math.floor(Math.random()*10)).join('')}`;
 return {name:`${first} ${surname}`,gender:isMale?'Male':'Female',dob:birth.toISOString().slice(0,10),email,phone,city:cities[Math.floor(Math.random()*cities.length)]};
}
// Free, no-API-key colour info via thecolorapi.com (no key required).
async function colorInfo(hexOrName){
 const q=String(hexOrName||'').trim().replace(/^#/,'');
 const isHex=/^[0-9A-Fa-f]{3}$|^[0-9A-Fa-f]{6}$/.test(q);
 const param=isHex?`hex=${q}`:`name=${encodeURIComponent(q)}`;
 const r=await fetch(`https://www.thecolorapi.com/id?${param}&format=json`,{headers:{'user-agent':'MrDKxxBot/4.12'}});
 if(!r.ok)throw new Error('Color API unavailable.');
 const j=await r.json();
 return {name:j.name?.value||'Unknown',hex:j.hex?.value||'',rgb:`${j.rgb?.r},${j.rgb?.g},${j.rgb?.b}`,hsl:`${j.hsl?.h}°,${j.hsl?.s}%,${j.hsl?.l}%`,contrast:j.contrast?.value||''};
}
// Free, no-API-key "on this day in history" via Wikipedia API.
async function onThisDay(){
 const now=new Date();const m=now.getMonth()+1,d=now.getDate();
 const r=await fetch(`https://en.wikipedia.org/api/rest_v1/feed/onthisday/events/${m}/${d}`,{headers:{'user-agent':'MrDKxxBot/4.12','accept':'application/json'}});
 if(!r.ok)throw new Error('History service unavailable.');
 const j=await r.json();
 const events=(j.events||[]).slice(0,5).map(e=>({year:e.year,text:e.text?.slice(0,120)||''}));
 return {date:`${m}/${d}`,events};
}
// Local, no-network text encryption/decryption using AES-256-GCM.
const crypto2=require('crypto');
function encryptText(text,passphrase){
 const t=String(text||'').trim(),p=String(passphrase||'').trim();
 if(!t||!p)throw new Error('Usage: text | passphrase');
 const key=crypto2.scryptSync(p,'mrdkxx',32),iv=crypto2.randomBytes(12);
 const cipher=crypto2.createCipheriv('aes-256-gcm',key,iv);
 const enc=Buffer.concat([cipher.update(t,'utf8'),cipher.final()]);
 const tag=cipher.getAuthTag();
 return Buffer.concat([iv,tag,enc]).toString('base64');
}
function decryptText(encoded,passphrase){
 const p=String(passphrase||'').trim();if(!p)throw new Error('Usage: encrypted_text | passphrase');
 try{
  const buf=Buffer.from(String(encoded||'').trim(),'base64');
  const key=crypto2.scryptSync(p,'mrdkxx',32);
  const iv=buf.slice(0,12),tag=buf.slice(12,28),enc=buf.slice(28);
  const decipher=crypto2.createDecipheriv('aes-256-gcm',key,iv);
  decipher.setAuthTag(tag);
  return Buffer.concat([decipher.update(enc),decipher.final()]).toString('utf8');
 }catch{throw new Error('Decryption failed — wrong passphrase or corrupted data.')}
}
module.exports={qr,calc,isSafeUrl,urlInfo,uuid,password,hash,base64Encode,base64Decode,randomNumber,jsonFormat,timestamp,unitConvert,currencyConvert,weather,newsHeadlines,prayerTimes,bmi,ageCalc,ipLookup,dadJoke,randomQuote,magic8ball,rollDice,coinFlip,randomDogImage,randomCatImage,advice,trivia,numberFact,chuckNorrisJoke,shortenUrl,wordCount,textCase,wikiSearch,dictionary,githubInfo,countryInfo,morseCode,romanNumerals,fakePerson,colorInfo,onThisDay,encryptText,decryptText};

const fs=require('fs');
const path=require('path');
const root=path.resolve(__dirname,'..');
const bot=fs.readFileSync(path.join(root,'src','bot.js'),'utf8');
const menu=fs.readFileSync(path.join(root,'src','services','menu.js'),'utf8');
const jsFiles=[];
function walk(dir){for(const name of fs.readdirSync(dir)){const p=path.join(dir,name);const st=fs.statSync(p);if(st.isDirectory())walk(p);else if(name.endsWith('.js'))jsFiles.push(p)}}
walk(path.join(root,'src'));
const allJs=jsFiles.map(f=>fs.readFileSync(f,'utf8')).join('\n');
const checks=[
  [!(/\blower\s*[!=]=/.test(bot)),'No undefined lower-variable references'],
  [bot.includes('if(dkPayload!==null)'),'AI has an explicit DK prefix gate'],
  [bot.includes('Unmatched ordinary messages are intentionally ignored'),'Unmatched messages are ignored'],
  [!bot.includes("await runAi(sock,j,p,'gemini','gemini','')"),'Direct Gemini command cannot bypass DK gate'],
  [bot.includes('function imageModelNames()'),'Image model selection is explicit'],
  [bot.includes('imageProviderStatus'),'Image provider status is exposed'],
  [bot.includes("choice==='url'"),'Generic URL info tool is wired'],
  [bot.includes("if(botPaused) continue"),'Paused mode ignores incoming messages'],
  [bot.includes('async function sendUniversalGroupMenu') && bot.includes('function buildUniversalGroupMenu') && bot.includes('if(isGroup(jid)){') && bot.includes('return await sendUniversalGroupMenu(sock,jid,body,items'), 'Groups use a universal plain-text numbered menu'],
  [bot.includes('never send WhatsApp native buttons/lists/flows here') && !bot.includes('sendLegacyGroupMenu(sock,jid,body,items'), 'Group menus never send native/legacy interactive payloads'],
  [bot.includes('function sessionKey(j,m)') && bot.includes("return isGroup(j)?`${j}|${actor}`:j;"),'Group interactive sessions are isolated per sender'],
  [bot.includes('getFallbackChoice(sk,text)'),'Group numbered menu replies use per-sender state'],
  [bot.includes("stateKeyArg:sessionKey(j,m)"),'Menu state is scoped to the requesting sender'],
  [!allJs.match(/(?:\u00e2\u0153\u00a8|\u00e2\u0161\u00a1|\u00f0\u0178|\u00ef\u00b8|\u00e2\u20ac\u00a2)/),'No common emoji mojibake remains in source JavaScript'],
  [bot.includes('fallbackMenus.set(stateKey,mapped)') && bot.includes('Reply with a number'),'Group menu selections keep per-sender numeric state'],
  [!bot.includes('listType:1') && !bot.includes('buttonText:String(title).slice(0,20)'),'Group menu sender contains no legacy list/button payload'],
];
let failed=0;
for(const [ok,label] of checks){console.log(`${ok?'OK  ':'FAIL'} ${label}`);if(!ok)failed++}
if(failed)process.exit(1);
console.log(`\nRuntime-gate audit passed: ${checks.length} checks.`);

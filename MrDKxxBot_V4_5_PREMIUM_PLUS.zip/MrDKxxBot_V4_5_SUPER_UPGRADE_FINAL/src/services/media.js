const {spawn}=require('child_process');
const fs=require('fs'),path=require('path');
const {downloadDir,tmpDir,isUrl,logger}=require('../utils');
function run(bin,args,timeout=300000){return new Promise((resolve,reject)=>{const p=spawn(bin,args,{windowsHide:true});let out='',err='',settled=false;const finish=(fn,v)=>{if(settled)return;settled=true;clearTimeout(timer);fn(v)};const timer=setTimeout(()=>{try{p.kill()}catch{};finish(reject,new Error('Process timeout'))},timeout);p.stdout.on('data',d=>out+=d);p.stderr.on('data',d=>err+=d);p.on('error',e=>finish(reject,e));p.on('close',c=>c===0?finish(resolve,{out,err}):finish(reject,new Error((err||out).slice(-2200)||`process exited with ${c}`)))})}
function yt(){return process.env.YT_DLP_PATH||'yt-dlp'}
function ffmpeg(){return process.env.FFMPEG_PATH||'ffmpeg'}
// YouTube can reject the default "web" client with "Sign in to confirm you're not a
// bot". Listing several alternative player clients (comma-separated) lets yt-dlp try
// each internally per request — no cookies/login needed. This is free and works for
// most public videos; only some age-restricted/members-only videos still need cookies.
function extractorArgs(){
 const clients=process.env.YT_DLP_PLAYER_CLIENTS||'android,ios,tv_embedded,web_safari,mweb';
 return ['--extractor-args',`youtube:player_client=${clients}`];
}
// Optional: if the operator later gets access to a PC/Kiwi Browser and exports
// cookies.txt, dropping the path into YT_DLP_COOKIES_FILE (or COOKIES_FROM_BROWSER)
// still works alongside the player-client fallback above for the toughest videos.
function cookieArgs(){
 const p=process.env.YT_DLP_COOKIES_FILE||process.env.COOKIES_FILE;
 if(p&&fs.existsSync(p))return ['--cookies',p];
 const browser=process.env.YT_DLP_COOKIES_FROM_BROWSER;
 if(browser)return ['--cookies-from-browser',browser];
 return [];
}
async function info(url){if(!isUrl(url))throw new Error('Invalid URL');const {out}=await run(yt(),['--no-playlist','--dump-single-json','--no-warnings',...extractorArgs(),...cookieArgs(),url],90000);let j;try{j=JSON.parse(out)}catch{throw new Error('yt-dlp returned invalid media information.')}return {title:j.title||'Media',duration:j.duration||0,uploader:j.uploader||'',thumbnail:j.thumbnail||'',url:j.webpage_url||url,ext:j.ext||'',width:j.width||0,height:j.height||0,filesize:j.filesize||j.filesize_approx||0}}
async function download(url,kind='video',quality='best'){
 if(!isUrl(url))throw new Error('Invalid URL');
 const maxMb=Math.max(1,Number(process.env.MAX_DOWNLOAD_MB||100));
 const prefix=path.join(downloadDir,`mrdkxx-${Date.now()}-${Math.random().toString(16).slice(2)}`);const template=`${prefix}.%(ext)s`;
 const args=['--no-playlist','--no-warnings','--max-filesize',`${maxMb}M`,'-o',template,'--restrict-filenames','--retries','2','--fragment-retries','2','--no-part',...extractorArgs(),...cookieArgs()];
 if(kind==='audio')args.push('-x','--audio-format','mp3','--audio-quality','0');
 else {const q=quality==='small'?'best[height<=480]/best':quality==='medium'?'best[height<=720]/best':'bestvideo*+bestaudio/best';args.push('-f',q,'--merge-output-format','mp4')}
 args.push(url);
 try{await run(yt(),args);const files=fs.readdirSync(downloadDir).filter(f=>f.startsWith(path.basename(prefix)+'.')&&!f.endsWith('.part')&&!f.endsWith('.ytdl'));if(!files.length)throw new Error('No output file was produced.');const file=path.join(downloadDir,files[0]);const mb=fs.statSync(file).size/1024/1024;if(mb>maxMb){cleanupPrefix(path.basename(prefix));throw new Error(`File is larger than ${maxMb} MB`)}return file}catch(e){cleanupPrefix(path.basename(prefix));throw e}
}
async function probe(file){if(!file||!fs.existsSync(file))throw new Error('Media file not found');const {out}=await run(ffmpeg(),['-hide_banner','-i',file],30000).catch(e=>({out:'',err:e.message}));const text=String(out||'');return {file:path.basename(file),size:fs.statSync(file).size,raw:text}}
async function transcode(input,{type='video',format='mp4',quality='medium'}={}){if(!fs.existsSync(input))throw new Error('Input media file not found');const out=path.join(tmpDir,`mrdkxx-${type}-${Date.now()}.${format}`);let args=['-y','-i',input];if(type==='video'){const vf=quality==='small'?'scale=-2:480':quality==='medium'?'scale=-2:720':'scale=1280:-2';args.push('-vf',vf,'-c:v','libx264','-preset','veryfast','-crf',quality==='small'?'30':quality==='medium'?'27':'24','-c:a','aac','-b:a','128k')}else if(type==='audio'){args.push('-vn','-c:a',format==='wav'?'pcm_s16le':'libmp3lame','-q:a','4')}else throw new Error('Unsupported transcode type');args.push(out);await run(ffmpeg(),args,180000);return out}
async function thumbnail(input){if(!fs.existsSync(input))throw new Error('Input media file not found');const out=path.join(tmpDir,`mrdkxx-thumb-${Date.now()}.jpg`);await run(ffmpeg(),['-y','-ss','00:00:01','-i',input,'-frames:v','1','-vf','scale=720:-2',out],60000);return out}
async function gif(input){if(!fs.existsSync(input))throw new Error('Input video not found');const out=path.join(tmpDir,`mrdkxx-${Date.now()}.gif`);await run(ffmpeg(),['-y','-t','6','-i',input,'-vf','fps=10,scale=480:-1:flags=lanczos',out],120000);return out}
async function audioExtract(input){return transcode(input,{type:'audio',format:'mp3'})}
function cleanup(file){try{if(file&&fs.existsSync(file))fs.unlinkSync(file)}catch(e){logger.warn(e.message,'cleanup failed')}}
function cleanupPrefix(prefix){for(const f of fs.readdirSync(downloadDir)){if(f.startsWith(prefix)){try{fs.unlinkSync(path.join(downloadDir,f))}catch{}}}}
module.exports={run,info,download,probe,transcode,thumbnail,gif,audioExtract,cleanup,cleanupPrefix};

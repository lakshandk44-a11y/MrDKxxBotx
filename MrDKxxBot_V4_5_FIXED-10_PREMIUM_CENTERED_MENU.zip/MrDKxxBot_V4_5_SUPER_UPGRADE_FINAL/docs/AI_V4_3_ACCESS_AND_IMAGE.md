# MR DKxx 4.3 access gate + image failover

## Message access
- Normal messages are ignored when no bot session/command is active.
- `menu` opens the main menu. `dk` also opens the main menu.
- AI chat requires a DK prefix: `DK hello`, `dk hello`, `D K hello`, `d-k: hello`, etc.
- The DK prefix is case/spacing tolerant but does not match ordinary words such as `dark`.
- Selecting Gemini/Local AI keeps the selected provider/model, but every AI message still requires the DK prefix.
- Owner-only `stop` pauses the bot globally; normal messages and DK messages are ignored while paused. Owner-only `start`/`resume` re-enables it.

## Gemini image generation
Image Auto and four Gemini image models are available:
1. `gemini-3.1-flash-image`
2. `gemini-3.1-flash-lite-image`
3. `gemini-3-pro-image`
4. `gemini-2.5-flash-image`

The selected model is tried first, then the remaining Gemini image models are tried silently. If Gemini image generation fails, Pollinations is tried when `POLLINATIONS_API_KEY` is configured. A custom `IMAGE_PROVIDER_URL` can also be used as an external fallback.

Only the final all-provider failure is shown to the user; individual model failures are logged server-side and do not create WhatsApp error messages.

## Existing behavior preserved
- Gemini text model menu and silent Gemini failover.
- Ollama local AI.
- Pollinations text fallback.
- Media/download/group/tools/sticker/database/dashboard/PM2 compatibility.
- No `.env` replacement is required for this update.

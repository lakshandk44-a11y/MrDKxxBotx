# MR DKxx V4.4

- Kept the existing Gemini/local AI, WhatsApp session, PM2 flow and menu architecture.
- Added Together AI image generation with the documented FLUX Schnell Free model option.
- Added Stability AI image generation options.
- Added silent external image-provider failover and image-provider status.
- Disabled the stale Pollinations image fallback by default; it can be explicitly enabled with a configured endpoint.
- Fixed URL Info so ordinary web URLs are inspected directly instead of being forced through yt-dlp.
- Added UUID, password, hash, Base64, JSON formatting and random-number tools.
- Added group rule editing for admins.
- Improved warning and moderation panels without enabling destructive auto-actions.
- Added Windows SAPI as a local TTS fallback before Gemini TTS.
- Added extra checks/self-tests for the new tools and image-provider wiring.

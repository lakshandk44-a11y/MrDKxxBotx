# MR DKxx V4.4 — External AI Image Providers

This update keeps the existing Gemini image flow and adds external API options.

## Added
- Together AI: FLUX Schnell Free model option.
- Stability AI: Stable Image Core and SD 3.5 Large Turbo options.
- Image Auto can fail over across configured providers.
- Pollinations image fallback is now opt-in because the old deployed endpoint returned HTTP 404.
- Windows SAPI is used as a local TTS fallback before Gemini TTS.
- URL Info no longer depends on yt-dlp, so normal websites such as GitHub can be inspected.
- Added local UUID, password, hash, Base64, JSON formatter and random-number tools.

## `.env` additions
Add these to the existing `.env`; do not replace the file:

```env
TOGETHER_API_KEY=
TOGETHER_IMAGE_MODEL=black-forest-labs/FLUX.1-schnell-Free
TOGETHER_IMAGE_WIDTH=1024
TOGETHER_IMAGE_HEIGHT=1024
TOGETHER_IMAGE_STEPS=4
TOGETHER_IMAGE_URL=https://api.together.ai/v1/images/generations
STABILITY_API_KEY=
IMAGE_PROVIDER_ORDER=gemini,together,stability,pollinations,custom
POLLINATIONS_ENABLED=false
```

# MR DKxx V4.5 Super Upgrade

V4.5 preserves the V4/V4.4 WhatsApp session, Gemini flow, menus, downloads, groups, SQLite history, PM2 setup and existing safety gates.

## AI
- Gemini model failover remains intact.
- Optional Groq and OpenRouter text-model failover.
- Local Ollama and LM Studio failover.
- Gemini Google Search grounding for Web Search.
- Image understanding / vision with Gemini.
- Summarize, translate, analyze, grammar fix, coding assistant, captions, hashtags, rewrite and image-prompt generation.
- AI provider status reporting.

## Image AI
- Gemini image models.
- Together AI FLUX image generation.
- Stability AI Stable Image Core / SD 3.5 options.
- Optional fal.ai image generation.
- Optional Hugging Face Inference image generation.
- Ordered automatic failover across configured providers.
- Pollinations image fallback remains opt-in.

## Media
- Existing authorized/public URL downloader is preserved.
- Best / 480p / 720p video and MP3.
- Media info.
- Video compression.
- Audio conversion to MP3.
- Thumbnail extraction.
- Video to GIF conversion.
- Existing sticker conversion remains intact.
- Partial-file cleanup and queue limits remain enabled.

## Voice / OCR
- External OCR adapter plus local Tesseract fallback.
- External speech-to-text adapter plus local Whisper fallback.
- Existing TTS provider -> Windows SAPI -> Gemini fallback remains intact.

## Utilities
- QR code, calculator, URL info.
- UUID, password, hash, Base64, JSON formatter, random number.
- Unit conversion.
- Timestamp / Unix time.
- System health and provider status.
- Owner database backup.

## Reliability
- Native-flow menu plus numbered fallback.
- Duplicate message protection.
- AI in-flight and response deduplication.
- Per-chat AI ordering.
- Explicit DK prefix gate for ordinary AI messages.
- Stop/resume owner controls.
- Automatic reconnect with timer protection.
- SQLite WAL and history.
- Recursive JavaScript syntax checks and expanded self-test.

# MR DKxx 4.3.1 hotfix

- Fixed the `lower is not defined` runtime error in the message router.
- Normal unmatched messages are now ignored instead of opening the menu.
- Direct `gemini ...` / `local ...` shortcuts no longer bypass the explicit `DK` AI gate.
- Preserved `menu`, `dk`, `dk menu`, `back`, owner-only `stop`, and owner-only `start`/`resume`.
- Fixed image-model menu selection so a selected Gemini image model is actually preferred before failover.
- Added a dependency-free regression audit (`npm run audit`).
- No `.env` values, auth state, database state, or npm dependencies were changed by this hotfix.

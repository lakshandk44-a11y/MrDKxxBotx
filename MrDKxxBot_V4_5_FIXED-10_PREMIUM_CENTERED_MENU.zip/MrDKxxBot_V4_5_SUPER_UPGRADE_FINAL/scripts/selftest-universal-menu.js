const fs=require('fs');
const path=require('path');
const bot=fs.readFileSync(path.join(__dirname,'..','src','bot.js'),'utf8');
const start=bot.indexOf('async function sendInteractive(');
const end=bot.indexOf('\nasync function sendLogo',start);
if(start<0||end<0) throw new Error('sendInteractive not found');
const fn=bot.slice(start,end);
const checks=[
  ['sendMessage text transport',fn.includes("await sock.sendMessage(jid,{text})")],
  ['numbered fallback state',fn.includes('fallbackMenus.set(stateKey,mapped)')],
  ['no nativeFlowMessage',!fn.includes('nativeFlowMessage')],
  ['no relayMessage',!fn.includes('relayMessage')],
  ['no listMessage',!fn.includes('listMessage')],
  ['no buttonsMessage',!fn.includes('buttonsMessage')],
  ['no legacy interactive sender',!fn.includes('sendLegacyGroupMenu')]
];
let bad=0;
for(const [name,ok] of checks){console.log(`${ok?'PASS':'FAIL'}: ${name}`); if(!ok) bad++}
if(bad) process.exit(1);
console.log('UNIVERSAL MENU TRANSPORT: PASS');

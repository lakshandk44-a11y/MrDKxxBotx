const QRCode=require('qrcode');
const crypto=require('crypto');
const path=require('path');
const {tmpDir}=require('../utils');

async function qr(text){const out=path.join(tmpDir,`qr-${Date.now()}.png`);await QRCode.toFile(out,String(text),{width:700,margin:2});return out}
function calc(expr){const s=String(expr||'').trim();if(!s||s.length>300||!/^[0-9+\-*/%().\s]+$/.test(s))throw new Error('Only arithmetic expressions are allowed');const v=Function(`"use strict";return (${s})`)();if(!Number.isFinite(Number(v)))throw new Error('Calculation returned a non-finite value');return v}
function isSafeUrl(v){try{const u=new URL(String(v));return ['http:','https:'].includes(u.protocol)}catch{return false}}
async function urlInfo(url){if(!isSafeUrl(url))throw new Error('Invalid URL');let r=null,last=null;for(const method of ['HEAD','GET'])try{r=await fetch(new URL(url),{method,redirect:'follow',headers:{'user-agent':'MR-DKxx/4.5'}});if(r.ok||method==='GET')break}catch(e){last=e}if(!r)throw last||new Error('URL request failed');let ct=r.headers.get('content-type')||'',title='';if(ct.includes('text/html')){let html='';try{html=await r.text()}catch{}title=(html.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1]||'').replace(/\s+/g,' ').trim().slice(0,180)}return {finalUrl:r.url||url,status:r.status,statusText:r.statusText||'',contentType:ct,contentLength:r.headers.get('content-length')||'',title:title||new URL(r.url||url).hostname}}
function uuid(){return crypto.randomUUID()}
function password(length=16){const n=Math.min(64,Math.max(6,Number(length)||16));const chars='ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%^&*_-+=';let out='';for(let i=0;i<n;i++)out+=chars[crypto.randomInt(chars.length)];return out}
function hash(text,algorithm='sha256'){const a=['md5','sha1','sha256','sha512'].includes(String(algorithm).toLowerCase())?String(algorithm).toLowerCase():'sha256';return crypto.createHash(a).update(String(text)).digest('hex')}
function base64Encode(text){return Buffer.from(String(text),'utf8').toString('base64')}
function base64Decode(text){const s=String(text).trim();if(!/^[A-Za-z0-9+/]*={0,2}$/.test(s)||s.length%4===1)throw new Error('Invalid Base64');return Buffer.from(s,'base64').toString('utf8')}
function randomNumber(min=1,max=100){let a=Math.ceil(Number(min)),b=Math.floor(Number(max));if(!Number.isFinite(a)||!Number.isFinite(b)||a>b)throw new Error('Invalid range');return crypto.randomInt(a,b+1)}
function jsonFormat(text){return JSON.stringify(JSON.parse(String(text)),null,2)}
function timestamp(value=''){const d=value?new Date(value):new Date();if(Number.isNaN(d.getTime()))throw new Error('Invalid date/time');return {iso:d.toISOString(),unix:Math.floor(d.getTime()/1000),local:d.toString()}}
function unitConvert(value,from,to){const v=Number(value);if(!Number.isFinite(v))throw new Error('Invalid number');const f=String(from).toLowerCase(),t=String(to).toLowerCase();const table={m:1,km:1000,cm:0.01,mm:0.001,mi:1609.344,ft:0.3048,yd:0.9144,in:0.0254,kg:1,g:0.001,lb:0.45359237,oz:0.028349523125,l:1,ml:0.001};if(!(f in table)||!(t in table))throw new Error('Supported units: m km cm mm mi ft yd in kg g lb oz l ml');return v*table[f]/table[t]}
module.exports={qr,calc,isSafeUrl,urlInfo,uuid,password,hash,base64Encode,base64Decode,randomNumber,jsonFormat,timestamp,unitConvert};

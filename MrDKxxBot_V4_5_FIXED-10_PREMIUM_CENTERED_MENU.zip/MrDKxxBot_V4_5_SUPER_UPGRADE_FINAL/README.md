# MR DKxx WhatsApp Bot V4

A Windows VPS WhatsApp assistant built with Node.js 22, Baileys, SQLite, yt-dlp and FFmpeg.

## Quick start

1. Use Node.js 22 LTS on Windows.
2. Install Python, FFmpeg and yt-dlp.
3. Extract this project.
4. Copy `.env.example` to `.env`.
5. Add `GEMINI_API_KEY` if you want Gemini features.
6. Set `OWNER_JIDS` after using `/id` from the WhatsApp account.
7. Run `npm install`.
8. Run `npm run check`.
9. Run `npm run smoke` to verify installed modules, then `node scripts/selftest.js` for the menu/payload audit.
10. Run `npm start` and scan the QR once from WhatsApp > Linked devices.

## Main features

- Sinhala/English native-flow menus with a numbered fallback
- MR DKxx logo/branding
- Duplicate-message protection and single-instance lock
- Gemini AI with model failover
- Optional Google Search grounding
- AI summarize/translate/analyze/rewrite/captions/hashtags
- Gemini native image generation with image-model fallback
- Pollinations text/image fallback
- Gemini native TTS fallback or external TTS provider
- Video/audio downloads through yt-dlp
- 480p/720p/best video and MP3 options
- Media info
- Sticker conversion using FFmpeg
- QR generator and safe calculator
- Group rules, admin checks, tag-all and stats
- SQLite history and usage tracking
- Health/status/ping/ID commands
- Queueing, download limits, cleanup and reconnect handling
- Local dashboard
- Optional STT/OCR adapters

## Gemini models

The default text list uses currently documented Gemini 3.x/2.5 models. Gemini 2.0 models are not included because the Gemini 2.0 Flash family was shut down on June 1, 2026. See Google's current model documentation before pinning a model for long-term production use.

## Notes

Provider-dependent features require their relevant API key/URL. The bot does not bypass DRM, private-content authentication, paywalls or platform restrictions. Download only content you are authorized to download and respect copyright/platform terms.

## AI reliability (V4.1)

The AI layer now fails over silently instead of sending one WhatsApp error for every unavailable Gemini model.

Provider order is configurable with `AI_PROVIDER_ORDER` and defaults to:

1. Gemini (current stable model IDs)
2. Pollinations (only when `POLLINATIONS_API_KEY` is configured)
3. Local Ollama (no cloud API key; requires Ollama + a local model)

Useful commands:

- `/gemini your question` — Gemini-first one-shot request
- `/local your question` — local Ollama request
- `/aistatus` — show configured/available AI providers

For a free local fallback on Windows, run `setup-local-ai.ps1` once. It installs Ollama when possible and pulls `gemma3:4b`. The bot then uses the local Ollama endpoint automatically when cloud providers fail.


## Free local AI
Run `powershell -ExecutionPolicy Bypass -File .\setup-free-ai.ps1` on Windows to install Ollama and download a local model. The bot automatically falls back through Gemini → Ollama → LM Studio → Pollinations. Local providers require no cloud API key.


### Universal menu compatibility fix
All menu transports now use ordinary text messages with numbered selections. WhatsApp native-flow/list/button menu payloads are not sent by the menu sender, avoiding client-specific unsupported-message rendering.

# Windows VPS setup

## 1. Prerequisites

Use **Node.js 22 LTS**. Node 24 can force `better-sqlite3` to compile locally and may fail without Visual Studio C++ build tools.

Verify:

```powershell
node --version
npm --version
py --version
ffmpeg -version
yt-dlp --version
```

## 2. Install

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\install-and-run.ps1
```

The script creates `.env`, runtime directories, installs npm packages and runs the syntax check.

## 3. Configure `.env`

At minimum add:

```env
GEMINI_API_KEY=YOUR_KEY
```

Keep `OWNER_JIDS` empty until the WhatsApp account is paired. The bot can still be tested normally.

## 4. Start

```powershell
.\run.ps1
```

Scan the QR from WhatsApp → Linked devices.

## 5. First test

Send `menu` to the bot. The bot sends the MR DKxx logo followed by a clickable native-flow menu. If a WhatsApp client does not render native flow, the bot automatically attempts a standard list fallback.

Then test:

- Language → Sinhala
- AI → Gemini
- Media → Video/Audio
- Tools → Health
- Group → Group Stats (inside a group)

## 6. Pairing/session

Credentials are stored under `auth/mrdkxx`. Do not commit that directory to GitHub. To intentionally pair a different account, stop the bot and remove `auth/mrdkxx`.

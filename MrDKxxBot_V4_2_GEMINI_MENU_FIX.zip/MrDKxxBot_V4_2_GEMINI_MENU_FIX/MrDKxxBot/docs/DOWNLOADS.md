# Downloads

The downloader uses yt-dlp and ffmpeg for public/authorized URLs.

Supported choices:

- Video — Best available
- Video — 480p target
- Video — 720p target
- Audio — MP3
- Media info

Configuration:

```env
MAX_DOWNLOAD_MB=100
MAX_CONCURRENT_JOBS=2
YT_DLP_PATH=yt-dlp
FFMPEG_PATH=ffmpeg
```

The bot refuses files larger than the configured limit and cleans temporary output after sending.

Only download content you are legally authorized to download. The bot does not bypass DRM, paywalls, private content or authentication controls.

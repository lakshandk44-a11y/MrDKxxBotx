# MR DKxx V4 feature set

## WhatsApp UX
- MR DKxx branded logo
- Native-flow list/quick-reply menus with a plain-text numbered fallback
- Sinhala/English language switching
- Back/Home navigation
- Duplicate-message protection
- Single-instance PID lock to prevent two bot processes replying at once
- Automatic reconnect with reconnect timer protection

## AI
- Gemini 3.6 Flash / 3.5 Flash / 3.5 Flash-Lite / 3.1 Flash-Lite / 2.5 Flash failover
- Optional Google Search grounding
- AI chat mode and `/gemini` shortcut
- Summarize, translate, analyze, rewrite, captions and hashtags
- Gemini native image generation with multiple image-model fallbacks
- Optional Pollinations text/image fallback
- SQLite conversation history and `/clear`
- Gemini native TTS fallback when no external TTS provider is configured

## Media
- yt-dlp public/authorized URL downloads
- Best / 480p / 720p video choices
- MP3 extraction
- Media metadata/info
- Download queue and size limit
- Retry/fragment retry settings
- Cleanup of partial/download artifacts on failure
- Image and short-video sticker conversion with FFmpeg

## Tools
- QR generator
- Safe arithmetic calculator
- URL/media information
- TTS through external provider or Gemini
- Health/status/ping/ID commands

## Groups
- Group detection
- WhatsApp admin checks
- Configured owner/admin IDs
- Admin list and member count
- Rules and warning storage
- Admin-only tag-all
- Non-destructive moderation panel

## Operations
- SQLite WAL database
- Custom database/TMP/download/log directories
- Runtime health checks
- Dashboard on localhost
- PowerShell installer/run scripts
- PM2 configuration
- Full recursive JavaScript syntax checker
- Smoke-test command for installed dependencies

Provider-dependent features require their provider/API key. The bot does not bypass DRM, private-content authentication, paywalls or platform restrictions. Download only content you are authorized to download.

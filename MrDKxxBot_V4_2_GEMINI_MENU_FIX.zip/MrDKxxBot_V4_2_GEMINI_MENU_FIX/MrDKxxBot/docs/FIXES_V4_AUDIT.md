# MR DKxx V4 audit and fixes

## Critical fixes
- Fixed the native-flow menu crash caused by calling `nativeFlowMessage(...)` when the project exports `nativeFlow(...)`.
- Replaced the deprecated/fragile menu fallback with a numbered text fallback that maps replies back to the intended menu action.
- Added duplicate incoming-message protection.
- Added a reconnect timer guard so connection-close events do not start multiple reconnect loops.
- Added a PID lock so two local bot processes cannot operate the same WhatsApp session simultaneously.
- Extended the recursive syntax check to every JavaScript source file.

## Reliability fixes
- Database parent directories are created before opening SQLite.
- TMP_DIR is now used consistently by utilities and media-related services.
- yt-dlp download failures clean partial artifacts.
- Media-info JSON parse failures return a controlled error instead of an uncaught JSON exception.
- Download commands use limited retries and fragment retries.
- Group admin checks also honor configured ADMIN_JIDS/OWNER_JIDS.
- Process timeout handling avoids double-settlement of media child-process promises.

## Gemini/provider fixes
- Gemini text generation uses the current `models.generateContent` request shape rather than depending on chat-session behavior for failover.
- Current documented Gemini 3.x/2.5 model IDs are used by default.
- Current Gemini image model IDs are used for image generation fallback.
- Google Search grounding remains optional and uses the documented `googleSearch` tool.
- TTS now works through either an external TTS provider or Gemini 3.1 Flash TTS Preview when GEMINI_API_KEY is available.

## Verification
- All 14 JavaScript source files pass `node --check`.
- package.json parses successfully.
- `npm run check` is now a recursive check rather than a manually maintained list.
- `npm run smoke` is included for runtime module-load and utility checks on the target Windows installation.

## Not included by design
- No automatic group kicking/banning.
- No DRM/private-content bypass.
- No API keys or `.env` secrets.
- No bundled `node_modules` or WhatsApp auth state.

## Final menu/client compatibility fixes
- Native-flow `single_select` rows now use WhatsApp's required `id` field (the previous build incorrectly used `rowId`, which could render the menu button while making the list non-functional).
- Incoming menu responses are now parsed through ephemeral/view-once/document wrapper layers as well as native-flow, list, and template response formats.
- The branded logo is sent once per chat before the main menu instead of relying on an unused helper.
- Added `scripts/selftest.js` to validate native-flow payload shape and critical menu-response parsing assumptions without requiring a live WhatsApp connection.

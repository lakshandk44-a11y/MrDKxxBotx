# MR DKxx 4.1 AI Reliability Upgrade

- Removed per-model WhatsApp error spam during Gemini failover.
- Updated the default Gemini model list to the current stable model IDs.
- Added silent provider failover: Gemini -> Pollinations (when configured) -> local Ollama.
- Added local AI support through Ollama; no cloud API key is needed once Ollama + a model are installed on the VPS.
- Added AI Provider Status menu and `/aistatus` command.
- Added `/local <prompt>` for local AI and `/gemini <prompt>` for Gemini-first requests.
- Preserved the existing menu, media, downloads, group, tools, database and sticker features.
- Added explicit AI timeout controls and a concise final error instead of repeated model errors.

## 4.1.1 duplicate-message fix
- Prevents duplicate WhatsApp upserts from starting multiple AI requests for the same chat/message text.
- Prevents duplicate `Thinking...`, AI answer, and fallback-error messages for the same request.
- Keeps the existing provider failover chain unchanged.
- Gemini mode wording no longer claims Gemini is unavailable before a request is made.

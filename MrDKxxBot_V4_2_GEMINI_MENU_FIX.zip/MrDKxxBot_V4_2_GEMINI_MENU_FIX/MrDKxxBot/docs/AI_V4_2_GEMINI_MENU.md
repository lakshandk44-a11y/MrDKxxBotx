# MR DKxx 4.2 AI / Gemini UX Fix

- AI menu now opens a dedicated Gemini model menu.
- Gemini Auto and each configured `GEMINI_MODELS` entry can be selected directly.
- A selected Gemini model is tried first; if it fails, the remaining configured Gemini models are tried silently.
- If all Gemini models fail, the existing provider failover chain continues without exposing provider errors to the user.
- AI replies no longer send a separate `Thinking...` WhatsApp message; the bot uses the composing presence instead.
- AI requests are serialized per chat so replies stay in order.
- Duplicate incoming messages with the same text are suppressed for a short window, while normal repeated messages remain usable.
- The generic robot emoji was replaced in the AI-facing UI with cleaner `✨` / `🧠` indicators.
- Gemini-backed image generation now silently falls back to the configured image provider when Gemini image models fail.
- Existing media, downloads, group, tools, database, sticker, local Ollama and Pollinations functionality is preserved.

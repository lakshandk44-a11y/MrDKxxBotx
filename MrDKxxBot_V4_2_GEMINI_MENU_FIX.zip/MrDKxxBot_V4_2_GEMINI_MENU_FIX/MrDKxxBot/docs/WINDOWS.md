# Windows VPS

Recommended runtime: **Node.js 22 LTS**.

```powershell
cd C:\MrDKxxBotx\app\MrDKxxBot
Set-ExecutionPolicy -Scope Process Bypass
.\install-and-run.ps1
```

After installation:

```powershell
notepad .env
.\run.ps1
```

The bot creates its WhatsApp session in `auth\mrdkxx` and runtime data in `data`, `downloads`, `tmp` and `logs`.

For background operation, PM2 can be used:

```powershell
npm install -g pm2
pm2 start ecosystem.config.cjs
pm2 save
```

require('dotenv').config();
const fs=require('fs');
const path=require('path');
const required=['./src/utils','./src/db','./src/group','./src/i18n','./src/dashboard','./src/services/menu','./src/services/queue','./src/services/tools','./src/services/media','./src/services/sticker','./src/services/providers','./src/services/ai','./src/bot'];
for(const mod of required){require(path.resolve(mod));console.log(`LOAD OK ${mod}`)}
const {calc,isSafeUrl}=require('../src/services/tools');
if(calc('2+3*4')!==14)throw new Error('Calculator smoke test failed');
if(!isSafeUrl('https://example.com')||isSafeUrl('javascript:alert(1)'))throw new Error('URL safety smoke test failed');
const {models}=require('../src/services/ai');
if(!Array.isArray(models())||!models().length)throw new Error('Gemini model configuration is empty');
console.log('\nMR DKxx smoke tests passed.');

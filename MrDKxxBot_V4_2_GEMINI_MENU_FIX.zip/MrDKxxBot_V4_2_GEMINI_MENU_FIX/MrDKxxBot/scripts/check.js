const fs=require('fs');
const path=require('path');
const {spawnSync}=require('child_process');
const root=path.resolve(__dirname,'..','src');
function walk(dir){const out=[];for(const name of fs.readdirSync(dir)){const p=path.join(dir,name);const st=fs.statSync(p);if(st.isDirectory())out.push(...walk(p));else if(name.endsWith('.js'))out.push(p)}return out.sort()}
const files=walk(root);let failed=0;
for(const file of files){const r=spawnSync(process.execPath,['--check',file],{encoding:'utf8'});if(r.status!==0){failed++;console.error(`FAIL ${path.relative(process.cwd(),file)}\n${r.stderr||r.stdout}`)}else console.log(`OK   ${path.relative(process.cwd(),file)}`)}
if(failed)process.exit(1);console.log(`\nSyntax check passed: ${files.length} JavaScript files.`);

$ErrorActionPreference = "Stop"
Write-Host "MR DKxx - Free Local AI setup" -ForegroundColor Cyan

$ollama = Get-Command ollama -ErrorAction SilentlyContinue
if (-not $ollama) {
  Write-Host "Ollama is not installed. Downloading official Windows installer..." -ForegroundColor Yellow
  $installer = Join-Path $env:TEMP "OllamaSetup.exe"
  Invoke-WebRequest -Uri "https://ollama.com/download/OllamaSetup.exe" -OutFile $installer
  Start-Process -FilePath $installer -Wait
}

$ollama = Get-Command ollama -ErrorAction SilentlyContinue
if (-not $ollama) { throw "Ollama installation did not complete. Install Ollama from https://ollama.com and run this script again." }

Write-Host "Checking Ollama..." -ForegroundColor Cyan
try { Invoke-WebRequest -Uri "http://127.0.0.1:11434/api/tags" -UseBasicParsing -TimeoutSec 5 | Out-Null }
catch {
  Start-Process -FilePath "ollama" -ArgumentList "serve" -WindowStyle Hidden
  Start-Sleep -Seconds 3
}

$model = if ($env:LOCAL_AI_MODEL) { $env:LOCAL_AI_MODEL } else { "gemma3:4b" }
Write-Host "Downloading/checking local model: $model" -ForegroundColor Cyan
& ollama pull $model
if ($LASTEXITCODE -ne 0) { throw "ollama pull failed for $model" }

Write-Host "Free local AI is ready." -ForegroundColor Green
Write-Host "The bot can use Ollama without a Gemini/Pollinations API key." -ForegroundColor Green
Write-Host "Keep Ollama running, then start MR DKxx with: npm start" -ForegroundColor Green

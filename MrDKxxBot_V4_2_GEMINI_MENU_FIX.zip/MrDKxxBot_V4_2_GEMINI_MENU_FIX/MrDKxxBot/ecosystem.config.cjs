module.exports = {
  apps: [{
    name: "mr-dkxx-bot",
    script: "src/index.js",
    cwd: __dirname,
    autorestart: true,
    watch: false,
    max_memory_restart: "512M",
    env: { NODE_ENV: "production" }
  }]
};
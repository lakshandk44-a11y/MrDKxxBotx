$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Root
Write-Host "=== MR DKxx V4 Installer ===" -ForegroundColor Cyan
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw "Node.js is required." }
$node=(node --version).Trim();Write-Host "Node: $node"
$major=[int]($node.TrimStart('v').Split('.')[0])
if ($major -ne 22) { throw "This release is tested for Node.js 22 LTS. Detected $node. Install Node 22 LTS before npm install." }
if (-not (Test-Path ".env")) { Copy-Item ".env.example" ".env"; Write-Host ".env created - add your API keys." -ForegroundColor Yellow }
New-Item -ItemType Directory -Force auth\mrdkxx,data,downloads,tmp,logs | Out-Null
npm install
npm run check
if (Get-Command yt-dlp -ErrorAction SilentlyContinue) { Write-Host "yt-dlp: OK" -ForegroundColor Green } else { Write-Host "yt-dlp: MISSING - downloads will not work until installed." -ForegroundColor Yellow }
if (Get-Command ffmpeg -ErrorAction SilentlyContinue) { Write-Host "ffmpeg: OK" -ForegroundColor Green } else { Write-Host "ffmpeg: MISSING - media conversion may fail." -ForegroundColor Yellow }
Write-Host "Installation + syntax checks passed." -ForegroundColor Green
Write-Host "Edit .env, then run .\run.ps1" -ForegroundColor Cyan

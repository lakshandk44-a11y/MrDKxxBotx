$ErrorActionPreference = 'Stop'
Write-Host 'MR DKxx - Local AI setup' -ForegroundColor Cyan

$ollama = Get-Command ollama -ErrorAction SilentlyContinue
if (-not $ollama) {
  $winget = Get-Command winget -ErrorAction SilentlyContinue
  if ($winget) {
    Write-Host 'Installing Ollama with winget...' -ForegroundColor Yellow
    winget install --id Ollama.Ollama -e --accept-package-agreements --accept-source-agreements
  } else {
    throw 'Ollama is not installed and winget is unavailable. Install Ollama from the official Ollama website, then run this script again.'
  }
}

$ollama = Get-Command ollama -ErrorAction SilentlyContinue
if (-not $ollama) { throw 'Ollama was installed but is not yet available in PATH. Restart PowerShell and run this script again.' }

Write-Host 'Pulling Gemma 3 4B local model...' -ForegroundColor Yellow
ollama pull gemma3:4b

Write-Host ''
Write-Host 'Local AI is ready.' -ForegroundColor Green
Write-Host 'MR DKxx will use http://127.0.0.1:11434 and gemma3:4b when cloud AI providers are unavailable.'
Write-Host 'You can test it with: ollama run gemma3:4b'

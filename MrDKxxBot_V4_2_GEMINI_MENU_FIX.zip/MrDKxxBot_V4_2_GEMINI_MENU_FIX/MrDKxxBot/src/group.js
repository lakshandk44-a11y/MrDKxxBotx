function isGroup(jid){return typeof jid==='string' && jid.endsWith('@g.us')}
function configuredIds(name){return (process.env[name]||'').split(',').map(x=>x.trim()).filter(Boolean)}
function isOwner(jid){return configuredIds('OWNER_JIDS').includes(jid)}
function isConfiguredAdmin(jid){return configuredIds('ADMIN_JIDS').includes(jid)}
async function metadata(sock,jid){return sock.groupMetadata(jid)}
async function isAdmin(sock,jid,userJid){
  if(isOwner(userJid)||isConfiguredAdmin(userJid)) return true;
  const m=await metadata(sock,jid);
  const p=m.participants.find(x=>x.id===userJid || x.lid===userJid);
  return !!p && (p.admin==='admin'||p.admin==='superadmin')
}
module.exports={isGroup,isOwner,isConfiguredAdmin,isAdmin,metadata};

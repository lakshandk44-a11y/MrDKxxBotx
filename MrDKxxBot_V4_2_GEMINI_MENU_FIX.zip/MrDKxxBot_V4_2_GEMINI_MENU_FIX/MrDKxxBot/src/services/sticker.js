const fs=require('fs'),path=require('path');
const {spawn}=require('child_process');
const {tmpDir}=require('../utils');
function run(bin,args,timeout=120000){return new Promise((resolve,reject)=>{const p=spawn(bin,args,{windowsHide:true});let out='',err='';const timer=setTimeout(()=>{try{p.kill()}catch{};reject(new Error('Process timeout'))},timeout);p.stdout.on('data',d=>out+=d);p.stderr.on('data',d=>err+=d);p.on('error',e=>{clearTimeout(timer);reject(e)});p.on('close',c=>{clearTimeout(timer);c===0?resolve({out,err}):reject(new Error((err||out).slice(-1600)||`ffmpeg exited with ${c}`))})})}
async function imageToSticker(input){const out=path.join(tmpDir,`mrdkxx-sticker-${Date.now()}.webp`);await run(process.env.FFMPEG_PATH||'ffmpeg',['-y','-i',input,'-vf','scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=white@0','-vcodec','libwebp','-lossless','0','-q:v','70','-loop','0','-an',out]);return out}
async function videoToSticker(input){const out=path.join(tmpDir,`mrdkxx-sticker-${Date.now()}.webp`);await run(process.env.FFMPEG_PATH||'ffmpeg',['-y','-t','6','-i',input,'-vf','fps=12,scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=white@0','-vcodec','libwebp','-lossless','0','-q:v','70','-loop','0','-an',out]);return out}
function cleanup(f){try{if(f&&fs.existsSync(f))fs.unlinkSync(f)}catch{}}
module.exports={imageToSticker,videoToSticker,cleanup};

const QRCode=require('qrcode');
const {tmpDir}=require('../utils');
const path=require('path');
async function qr(text){const out=path.join(tmpDir,`qr-${Date.now()}.png`);await QRCode.toFile(out,text,{width:700,margin:2});return out}
function calc(expr){if(!/^[0-9+\-*/%().\s]+$/.test(expr))throw new Error('Only arithmetic expressions are allowed');return Function(`"use strict";return (${expr})`)()}
function isSafeUrl(v){try{const u=new URL(v);return ['http:','https:'].includes(u.protocol)}catch{return false}}
module.exports={qr,calc,isSafeUrl};

const baileys=require('@whiskeysockets/baileys');
const {default:makeWASocket,useMultiFileAuthState,DisconnectReason,generateWAMessageFromContent,proto}=baileys;
const qrcode=require('qrcode-terminal');
const P=require('pino');
const fs=require('fs'),path=require('path');
const {logger,safeText}=require('./utils');
const db=require('./db');
const {t,change}=require('./i18n');
const {askAI,providerStatus,geminiModels}=require('./services/ai');
const media=require('./services/media');
const {qr,calc,isSafeUrl}=require('./services/tools');
const {image,tts}=require('./services/providers');
const sticker=require('./services/sticker');
const {downloadContentFromMessage}=baileys;
const {stats,clearHistory}=db;
const {JobQueue}=require('./services/queue');
const {isGroup,isOwner,isAdmin}=require('./group');

const AUTH_DIR=path.resolve(process.env.AUTH_DIR||'auth/mrdkxx');
const LOGO=path.resolve('assets/mr-dkxx-logo.png');
const sessions=new Map();
const fallbackMenus=new Map();
const seenMessages=new Map();
const recentInputs=new Map();
const inFlightInputs=new Set();
const aiBusyByJid=new Map();
const aiChains=new Map();
const recentAiResponses=new Map();
const logoSent=new Set();
let reconnectTimer=null;
const queue=new JobQueue(Number(process.env.MAX_CONCURRENT_JOBS||2));
const startedAt=Date.now();

const {normalizeText,listParams,quickParams,nativeFlow}=require('./services/menu');
function row(id,title,description=''){return {title:String(title).slice(0,60),description:String(description).slice(0,72),rowId:id}}
function buildMixedNativeFlowBizNode(){
 const privacy=(Math.floor(Date.now()/1000)-77980457).toString();
 return {tag:'biz',attrs:{actual_actors:'2',host_storage:'2',privacy_mode_ts:privacy},content:[
  {tag:'interactive',attrs:{type:'native_flow',v:'1'},content:[{tag:'native_flow',attrs:{v:'9',name:'mixed'}}]},
  {tag:'quality_control',attrs:{source_type:'third_party'}}
 ]};
}
async function sendInteractive(sock,jid,body,items,{title='Select',footer='MR DKxx',quick=false}={}){
 try{
  const rawButtons=quick
   ? items.slice(0,3).map(x=>({name:'quick_reply',buttonParamsJson:quickParams(x[1],x[0])}))
   : [{name:'single_select',buttonParamsJson:listParams(title,items)}];
  const interactive=proto.Message.InteractiveMessage.create({
   header:proto.Message.InteractiveMessage.Header.create({title:'MR DKxx',hasMediaAttachment:false}),
   body:proto.Message.InteractiveMessage.Body.create({text:normalizeText(body)}),
   footer:proto.Message.InteractiveMessage.Footer.create({text:normalizeText(footer||'Mr DKxx')}),
   nativeFlowMessage:proto.Message.InteractiveMessage.NativeFlowMessage.create({
    buttons:rawButtons.map(b=>proto.Message.InteractiveMessage.NativeFlowMessage.NativeFlowButton.create(b)),
    messageParamsJson:'{}',
    messageVersion:1
   })
  });
  const msg=generateWAMessageFromContent(jid,{interactiveMessage:interactive},{userJid:sock.user?.id});
  const botNode={tag:'bot',attrs:{biz_bot:'1'}};
  const bizNode=buildMixedNativeFlowBizNode();
  const additionalNodes=isGroup(jid)?[bizNode]:[botNode,bizNode];
  await sock.relayMessage(jid,msg.message,{messageId:msg.key.id,additionalNodes});
  fallbackMenus.delete(jid);
  return true;
 }catch(e){
  logger.warn({err:e.message,stack:e.stack},'Interactive menu failed; using single-message numbered fallback');
  try{
   fallbackMenus.set(jid,items.map((x,i)=>({number:String(i+1),id:String(x[0])})));
   const lines=items.map((x,i)=>`${i+1}. ${x[1]}${x[2]?` — ${x[2]}`:''}`);
   await sock.sendMessage(jid,{text:`${normalizeText(body)}\n\n${lines.join('\n')}\n\nReply with the number of your choice.`});
   return true;
  }catch(e2){logger.error({err:e2.message},'Menu fallback failed');return false}
 }
}
async function sendLogo(sock,jid){
 try{
  if(!fs.existsSync(LOGO)) return false;
  await sock.sendMessage(jid,{image:fs.readFileSync(LOGO),caption:`✨ MR DKxx\n${t(jid,'welcome')}\n\n${t(jid,'choose')}`});
  return true;
 }catch(e){logger.warn({err:e.message},'Logo send failed');return false}
}
function homeItems(j){return [
 ['ai',t(j,'ai'),'Gemini, local AI and smart text tools'],['media',t(j,'media'),'Video, audio, media info and sticker tools'],['music',t(j,'music'),'MP3/audio downloads'],['image',t(j,'image'),'Generate images and image prompts'],['tools',t(j,'tools'),'QR, calculator, URL tools, health'],['group',t(j,'group'),'Group tools and admin utilities'],['downloads',t(j,'downloads'),'Download from public/authorized URLs'],['settings',t(j,'settings'),'Language and bot settings'],['help',t(j,'help'),'Help and supported features'],['owner',t(j,'ownerMenu'),'Owner/admin tools']
]}
function geminiItems(j){
 const list=geminiModels();
 return [
  ['gemini_auto','✨ Gemini Auto','Tries the configured Gemini models silently in order'],
  ...list.map((x)=>[x.id,`🧠 ${x.name}`,'Chat with this Gemini model; silent failover to the next one']),
  ['back',t(j,'back')]
 ];
}
function subItems(j,type){const M={
 ai:[['gemini',t(j,'gemini')],['chat',t(j,'chat')],['local',t(j,'local')],['aistatus',t(j,'aistatus')],['summarize',t(j,'summarize')],['translate',t(j,'translate')],['analyze',t(j,'analyze')],['caption',t(j,'caption')],['hashtags',t(j,'hashtags')],['rewrite',t(j,'rewrite')],['imageai',t(j,'imageai')],['back',t(j,'back')]],
 media:[['video',t(j,'video')],['audio',t(j,'audio')],['info',t(j,'info')],['sticker',t(j,'sticker')],['back',t(j,'back')]],
 music:[['audio',t(j,'audio')],['info',t(j,'info')],['back',t(j,'back')]],
 image:[['imageGen',t(j,'imageGen')],['imageai',t(j,'imageai')],['back',t(j,'back')]],
 tools:[['qr',t(j,'qr')],['calc',t(j,'calc')],['url',t(j,'url')],['tts',t(j,'tts')],['myid',t(j,'myid')],['health',t(j,'health')],['status',t(j,'status')],['back',t(j,'back')]],
 group:[['rules',t(j,'rules')],['admins',t(j,'admins')],['groupStats',t(j,'groupStats')],['warnings',t(j,'warnings')],['tagall',t(j,'tagall')],['moderation',t(j,'moderation')],['back',t(j,'back')]],
 settings:[['language',t(j,'language')],['clear',t(j,'clear')],['status',t(j,'status')],['back',t(j,'back')]],
 owner:[['stats',t(j,'stats')],['health',t(j,'health')],['back',t(j,'back')]]
};return M[type]||[]}
async function home(sock,j){
 if(!logoSent.has(j)){if(await sendLogo(sock,j))logoSent.add(j)}
 return sendInteractive(sock,j,`✨ MR DKxx\n\n${t(j,'choose')}`,homeItems(j),{title:'MR DKxx Menu',footer:'Mr DKxx • Main Menu'});
}
async function submenu(sock,j,type){return sendInteractive(sock,j,`✨ MR DKxx\n\n${t(j,type)}`,subItems(j,type),{title:`${type} menu`,footer:'Mr DKxx • Menu'})}
async function geminiMenu(sock,j){return sendInteractive(sock,j,`✨ Gemini\n\n${t(j,'geminiChoose')}`,geminiItems(j),{title:'Gemini Models',footer:'MR DKxx • Silent failover'})}
async function languageMenu(sock,j){return sendInteractive(sock,j,t(j,'chooseLang'),[['si',t(j,'si')],['en',t(j,'en')]],{title:'Language',quick:true})}
async function sendText(sock,j,text){return sock.sendMessage(j,{text:normalizeText(String(text))})}
async function prompt(sock,j,mode,kind){sessions.set(j,{mode,kind});return sendText(sock,j,t(j,'sendPrompt'))}
async function sendDownloadMenu(sock,j,url){sessions.set(j,{mode:'download',url});return sendInteractive(sock,j,`🔗 ${url}\n\nChoose download type:`,[['video_best','🎬 Video • Best'],['video_small','📱 Video • 480p'],['video_medium','📺 Video • 720p'],['audio_mp3','🎵 Audio • MP3'],['back',t(j,'back')]],{title:'Download',footer:'Mr DKxx • Downloader'})}
function unwrapMessage(message){
 let msg=message||{};
 // WhatsApp may wrap incoming messages in ephemeral/view-once containers.
 for(let i=0;i<6;i++){
  const next=msg.ephemeralMessage?.message||msg.viewOnceMessage?.message||msg.viewOnceMessageV2?.message||msg.documentWithCaptionMessage?.message||msg.editedMessage?.message;
  if(!next||next===msg)break;
  msg=next;
 }
 return msg;
}
function getIncomingText(m){
 const msg=unwrapMessage(m.message);
 return (msg.conversation||msg.extendedTextMessage?.text||msg.imageMessage?.caption||msg.videoMessage?.caption||msg.documentMessage?.caption||msg.interactiveMessage?.body?.text||msg.interactiveResponseMessage?.body?.text||'').trim();
}
function getChoice(m){
 const msg=unwrapMessage(m.message);
 const a=msg.buttonsResponseMessage?.selectedButtonId||msg.listResponseMessage?.singleSelectReply?.selectedRowId||msg.templateButtonReplyMessage?.selectedId;
 if(a)return String(a);
 const p=msg.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson;
 if(p){
  try{
   const j=typeof p==='string'?JSON.parse(p):p;
   return j?.id||j?.selected_id||j?.row_id||j?.selectedRowId||j?.selected_id?.id||j?.params?.id||null;
  }catch{}
 }
 return null;
}
function getFallbackChoice(jid,text){const n=String(text||'').trim();if(!/^\d{1,2}$/.test(n))return null;return fallbackMenus.get(jid)?.find(x=>x.number===n)?.id||null}
function duration(sec){sec=Number(sec||0);if(!sec)return '-';const h=Math.floor(sec/3600),m=Math.floor(sec%3600/60),s=Math.floor(sec%60);return h?`${h}h ${m}m ${s}s`:`${m}m ${s}s`}
async function requireGroupAdmin(sock,j,m){if(!isGroup(j)){await sendText(sock,j,t(j,'onlyGroup'));return false}const sender=m.key.participant||m.key.remoteJid;if(!await isAdmin(sock,j,sender)){await sendText(sock,j,t(j,'admin'));return false}return true}
async function executeDownload(sock,j,s,choice){const kind=choice==='audio_mp3'?'audio':'video';const quality=choice==='video_small'?'small':choice==='video_medium'?'medium':'best';await sendText(sock,j,'⏳ Downloading...');let file=null;try{file=await queue.add(()=>media.download(s.url,kind,quality));const stat=fs.statSync(file);const max=Number(process.env.MAX_DOWNLOAD_MB||100)*1024*1024;if(stat.size>max)throw new Error(t(j,'fileTooLarge'));const caption=`✨ MR DKxx\n${kind==='audio'?'🎵':'🎬'} ${path.basename(file)}`;if(kind==='audio')await sock.sendMessage(j,{audio:fs.readFileSync(file),mimetype:'audio/mpeg',fileName:path.basename(file),caption});else await sock.sendMessage(j,{video:fs.readFileSync(file),mimetype:'video/mp4',fileName:path.basename(file),caption});db.usage(j,`download_${kind}`)}finally{media.cleanup(file);sessions.delete(j)}}
async function runAi(sock,j,text,label='ai',provider='auto',geminiModel=''){
 const clean=String(text||'').trim().replace(/\s+/g,' ').toLowerCase();
 if(!clean)return null;
 const key=`${j}|${provider}|${label}|${geminiModel}|${clean}`;
 const now=Date.now();
 const doneAt=recentAiResponses.get(key);
 if(inFlightInputs.has(key))return null;
 if(doneAt && now-doneAt<5000)return null;
 inFlightInputs.add(key);
 const previous=aiChains.get(j)||Promise.resolve();
 const task=previous.catch(()=>{}).then(async()=>{
  aiBusyByJid.set(j,{at:Date.now(),text:clean,key});
  try{
   try{await sock.sendPresenceUpdate('composing',j)}catch{}
   const r=await askAI(text,j,{provider,geminiModel});
   recentAiResponses.set(key,Date.now());
   await sendText(sock,j,`✨ ${r.text}\n\n_${r.provider} • ${r.model}_`);
   db.usage(j,label);
   return r;
  }catch(e){
   recentAiResponses.set(key,Date.now());
   logger.warn({err:e.message,provider,label},'AI request failed after provider failover');
   await sendText(sock,j,'⚠️ AI is temporarily unavailable. Please try again in a moment.').catch(()=>{});
   return null;
  }finally{
   try{await sock.sendPresenceUpdate('paused',j)}catch{}
   const currentBusy=aiBusyByJid.get(j);
   if(currentBusy?.key===key)aiBusyByJid.delete(j);
   inFlightInputs.delete(key);
   if(recentAiResponses.size>2000){
    const cutoff=Date.now()-10*60*1000;
    for(const [k,ts] of recentAiResponses)if(ts<cutoff)recentAiResponses.delete(k);
   }
  }
 });
 aiChains.set(j,task);
 try{return await task}
 finally{if(aiChains.get(j)===task)aiChains.delete(j)}
}
async function handleChoice(sock,j,m,choice){
 if(choice==='language')return languageMenu(sock,j);
 if(choice==='si'||choice==='en'){change(j,choice);fallbackMenus.delete(j);await sendText(sock,j,t(j,'saved'));return home(sock,j)}
 if(choice==='home'||choice==='back'){db.setAiMode(j,false);sessions.delete(j);fallbackMenus.delete(j);return home(sock,j)}
 if(['ai','media','music','image','tools','group','settings','owner'].includes(choice))return submenu(sock,j,choice);
 if(choice==='help')return sendText(sock,j,t(j,'helpText'));
 if(choice==='clear'){clearHistory(j);db.setAiMode(j,false);sessions.delete(j);return sendText(sock,j,t(j,'cleared'))}
 if(choice==='stats'){if(!isOwner(j)){await sendText(sock,j,t(j,'owner'));return}const st=stats();return sendText(sock,j,`📊 MR DKxx Stats\n\n👤 Users: ${st.users}\n👥 Groups: ${st.groups}\n⚡ Actions: ${st.actions}`)}
 if(choice==='owner'){if(!isOwner(j))return sendText(sock,j,t(j,'owner'));return submenu(sock,j,'owner');}
 if(choice==='myid')return sendText(sock,j,`🆔 Your WhatsApp ID:\n${j}`);
 if(choice==='status')return sendText(sock,j,`${t(j,'statusText')}\n⏱️ Uptime: ${Math.floor((Date.now()-startedAt)/1000)}s\n📦 Queue: ${queue.size()}`);
 if(choice==='health')return sendText(sock,j,await healthText());
 if(choice==='gemini')return geminiMenu(sock,j);
 if(choice==='gemini_auto'){db.setAiMode(j,true);sessions.set(j,{mode:'ai',provider:'gemini',geminiModel:''});return sendText(sock,j,t(j,'aiOnGemini'))}
 const gm=geminiModels().find(x=>x.id===choice);
 if(gm){db.setAiMode(j,true);sessions.set(j,{mode:'ai',provider:'gemini',geminiModel:gm.name});return sendText(sock,j,`✨ Gemini • ${gm.name}\nSilent failover is enabled. Send your message now. Send back to exit.`)}
 if(choice==='chat'){db.setAiMode(j,true);sessions.set(j,{mode:'ai',provider:'auto'});return sendText(sock,j,t(j,'aiOn'))}
 if(choice==='local'){db.setAiMode(j,true);sessions.set(j,{mode:'ai',provider:'local'});return sendText(sock,j,t(j,'aiOnLocal'))}
 if(choice==='aistatus'){const rows=await providerStatus();return sendText(sock,j,`🧠 MR DKxx AI Status\n\n${rows.map(x=>`• ${x}`).join('\n')}`)}
 if(['summarize','translate','analyze','caption','hashtags','rewrite','imageai'].includes(choice))return prompt(sock,j,'prompt',choice);
 if(choice==='imageGen')return prompt(sock,j,'imageGen');
 if(choice==='video'||choice==='audio')return prompt(sock,j,'url',choice);
 if(choice==='downloads')return prompt(sock,j,'url','video');
 if(choice==='info')return prompt(sock,j,'info');
 if(choice==='sticker'){sessions.set(j,{mode:'sticker'});return sendText(sock,j,t(j,'sendSticker'))}
 if(['video_best','video_small','video_medium','audio_mp3'].includes(choice)){const s=sessions.get(j);if(!s?.url){await sendText(sock,j,t(j,'expired'));return}return executeDownload(sock,j,s,choice)}
 if(choice==='qr')return prompt(sock,j,'qr');
 if(choice==='calc')return prompt(sock,j,'calc');
 if(choice==='url')return prompt(sock,j,'info');
 if(choice==='tts')return prompt(sock,j,'tts');
 if(['rules','admins','groupStats','warnings','tagall','moderation'].includes(choice)){
  if(!isGroup(j)){await sendText(sock,j,t(j,'onlyGroup'));return}
  const meta=await sock.groupMetadata(j);
  if(choice==='rules')return sendText(sock,j,`📜 ${t(j,'rules')}\n\n${db.groupRules(j)||'No rules configured.'}`);
  if(choice==='admins')return sendText(sock,j,'🛡️ Admins\n\n'+meta.participants.filter(p=>p.admin).map(p=>`• ${p.id}`).join('\n'));
  if(choice==='groupStats')return sendText(sock,j,`📊 ${meta.subject}\n👥 Members: ${meta.participants.length}`);
  if(choice==='warnings')return sendText(sock,j,'⚠️ Warning storage is enabled. Admin actions can be added safely per group policy.');
  if(choice==='tagall'){if(!await requireGroupAdmin(sock,j,m))return;const mentions=meta.participants.map(p=>p.id);return sock.sendMessage(j,{text:mentions.map(x=>`@${x.split('@')[0]}`).join(' '),mentions})}
  if(choice==='moderation'){if(!await requireGroupAdmin(sock,j,m))return;return sendText(sock,j,'🛡️ Moderation panel ready. Automatic kicks/bans are intentionally not enabled by default.')}
 }
}
async function healthText(){
 const checks=[];for(const [name,bin,args] of [['Node','node',['--version']],['yt-dlp',process.env.YT_DLP_PATH||'yt-dlp',['--version']],['FFmpeg',process.env.FFMPEG_PATH||'ffmpeg',['-version']]]){try{const r=await media.run(bin,args,15000);checks.push(`✅ ${name}: ${(r.out||r.err).split(/\r?\n/)[0].slice(0,100)}`)}catch(e){checks.push(`❌ ${name}: ${e.message}`)}}checks.push(process.env.GEMINI_API_KEY?.trim()?`✅ Gemini API key: configured (${(process.env.GEMINI_MODELS||'').split(',').filter(Boolean).length||1} model(s))`:'⚠️ Gemini API key: not configured');checks.push(`🗃️ Database: ${db.stats? 'SQLite module loaded':'unknown'}`);return `🩺 MR DKxx System Check\n\n${checks.join('\n')}`}
async function startBot(){
 fs.mkdirSync(AUTH_DIR,{recursive:true});
 const {state,saveCreds}=await useMultiFileAuthState(AUTH_DIR);
 const sock=makeWASocket({auth:state,logger:P({level:'silent'}),browser:['Mr DKxx','Windows','3.0'],markOnlineOnConnect:false});
 sock.ev.on('creds.update',saveCreds);
 sock.ev.on('connection.update',({connection,lastDisconnect,qr:code})=>{
  if(code){console.log('\n=== MR DKxx QR ===\nScan with WhatsApp > Linked devices\n');qrcode.generate(code,{small:true})}
  if(connection==='open'){if(reconnectTimer){clearTimeout(reconnectTimer);reconnectTimer=null}logger.info('MR DKxx connected')}
  if(connection==='close'){
   const c=lastDisconnect?.error?.output?.statusCode;
   if(c===DisconnectReason.loggedOut){logger.error('WhatsApp session logged out; delete auth/mrdkxx and pair again.');return}
   if(!reconnectTimer){reconnectTimer=setTimeout(()=>{reconnectTimer=null;startBot().catch(e=>logger.error({err:e.message},'Reconnect failed'))},5000)}
  }
 });
 sock.ev.on('messages.upsert',async({messages,type})=>{
  if(type && type!=='notify') return;
  for(const m of messages||[]){
   if(!m||m.key.fromMe||!m.message)continue;
   const now=Date.now();
   const messageId=m.key.id;
   if(messageId){const seenAt=seenMessages.get(messageId);if(seenAt && now-seenAt<10*60*1000)continue;seenMessages.set(messageId,now);if(seenMessages.size>2000){for(const [id,ts] of seenMessages){if(now-ts>10*60*1000)seenMessages.delete(id)}}}
   const j=m.key.remoteJid;if(!j)continue;const text=getIncomingText(m);
   const normalizedIncoming=text.trim().replace(/\s+/g,' ').toLowerCase();
   const fingerprint=`${j}|${normalizedIncoming}`;
   const recentAt=recentInputs.get(fingerprint);
   if(recentAt && now-recentAt<6000)continue;
   recentInputs.set(fingerprint,now);
   if(recentInputs.size>2000){for(const [key,ts] of recentInputs){if(now-ts>10*60*1000)recentInputs.delete(key)}}
   const name=m.pushName||'User';db.ensureUser(j,name);if(isGroup(j))db.groupEnsure(j);
   const choice=getChoice(m)||getFallbackChoice(j,text);const lower=text.toLowerCase();
   try{
    if(choice){await handleChoice(sock,j,m,choice);continue}
    if(lower==='menu'||lower==='/menu'||lower==='home'||lower==='/start'){await home(sock,j);continue}
    if(lower==='back'){db.setAiMode(j,false);sessions.delete(j);fallbackMenus.delete(j);await home(sock,j);continue}
    if(lower==='/help'||lower==='help'){await sendText(sock,j,t(j,'helpText'));continue}
    if(lower==='/status'){await handleChoice(sock,j,m,'status');continue}
    if(lower==='/ping'||lower==='ping'){await sendText(sock,j,'🏓 Pong! MR DKxx is online.');continue}
    if(lower==='/id'||lower==='id'){await handleChoice(sock,j,m,'myid');continue}
    if(lower==='/clear'||lower==='clear'){await handleChoice(sock,j,m,'clear');continue}
    if(lower==='/features'||lower==='features'){await sendText(sock,j,t(j,'helpText'));continue}
    if(lower==='/health'){await handleChoice(sock,j,m,'health');continue}
    if(lower.startsWith('/gemini ')||lower.startsWith('gemini ')){const p=text.replace(/^\/?gemini\s+/i,'');await runAi(sock,j,p,'gemini','gemini','');continue}
    if(lower.startsWith('/local ')||lower.startsWith('local ')){const p=text.replace(/^\/?local\s+/i,'');await runAi(sock,j,p,'local','local','');continue}
    if(lower==='/aistatus'||lower==='aistatus'){const rows=await providerStatus();await sendText(sock,j,`🧠 MR DKxx AI Status\n\n${rows.map(x=>`• ${x}`).join('\n')}`);continue}
    const s=sessions.get(j);
    if(s?.mode==='sticker' && (m.message.imageMessage||m.message.videoMessage)){
      let input=null,output=null;try{const type=m.message.imageMessage?'image':'video';const stream=await downloadContentFromMessage(m.message[type+'Message'],type);input=path.join(process.env.TMP_DIR||path.join(require('./utils').tmpDir,'uploads'),`in-${Date.now()}`);fs.mkdirSync(path.dirname(input),{recursive:true});const ws=fs.createWriteStream(input);for await(const chunk of stream)ws.write(chunk);await new Promise(r=>ws.end(r));output=type==='image'?await sticker.imageToSticker(input):await sticker.videoToSticker(input);await sock.sendMessage(j,{sticker:fs.readFileSync(output)});db.usage(j,'sticker');}catch(e){await sendText(sock,j,`⚠️ ${safeText(e.message,600)}`)}finally{sticker.cleanup(input);sticker.cleanup(output);sessions.delete(j)}continue}
    if(s?.mode==='ai'||db.aiMode(j)){await runAi(sock,j,text,'ai',s?.provider||'auto',s?.geminiModel||'');continue}
    if(s?.mode==='url'){if(!isSafeUrl(text)){await sendText(sock,j,'⚠️ Please send a valid http/https URL.');continue}await sendDownloadMenu(sock,j,text);continue}
    if(s?.mode==='info'){if(!isSafeUrl(text)){await sendText(sock,j,'⚠️ Please send a valid URL.');continue}await sendText(sock,j,'🔎 Reading media info...');try{const x=await media.info(text);await sendText(sock,j,`🔎 ${x.title}\n👤 ${x.uploader||'-'}\n⏱️ ${duration(x.duration)}\n🔗 ${x.url}`)}catch(e){await sendText(sock,j,`⚠️ ${e.message}`)}sessions.delete(j);continue}
    if(s?.mode==='qr'){const file=await qr(text);try{await sock.sendMessage(j,{image:fs.readFileSync(file),caption:'🔳 MR DKxx QR'})}finally{try{fs.unlinkSync(file)}catch{}}sessions.delete(j);continue}
    if(s?.mode==='calc'){try{await sendText(sock,j,`🧮 ${calc(text)}`)}catch{await sendText(sock,j,'⚠️ Invalid calculation.')}sessions.delete(j);continue}
    if(s?.mode==='tts'){try{const p=await require('./services/providers').tts(text);await sock.sendMessage(j,{audio:fs.readFileSync(p),mimetype:'audio/mpeg',fileName:'mrdkxx-tts.mp3'});try{fs.unlinkSync(p)}catch{}}catch(e){await sendText(sock,j,`⚠️ ${e.message}`)}sessions.delete(j);continue}
    if(s?.mode==='prompt'){const prompts={summarize:`Summarize clearly in the user's language:\n\n${text}`,translate:`Translate naturally between Sinhala and English. Preserve meaning:\n\n${text}`,analyze:`Analyze this text and return useful key points, risks and conclusions:\n\n${text}`,caption:`Write 3 engaging social media captions for this content. Return Sinhala and English options where useful:\n\n${text}`,hashtags:`Generate 15 relevant hashtags for this content. Avoid spammy/repetitive tags:\n\n${text}`,rewrite:`Rewrite this naturally, clearly and professionally while preserving the meaning:\n\n${text}`,imageai:`Create a detailed safe image-generation prompt from this request. Return only the prompt:\n\n${text}`};await runAi(sock,j,prompts[s.kind],s.kind,'auto','');sessions.delete(j);continue}
    if(s?.mode==='imageGen'){
      await sendText(sock,j,'🎨 Creating image...');let file=null;try{file=await image(text);await sock.sendMessage(j,{image:fs.readFileSync(file),caption:'🎨 MR DKxx • AI Image'});db.usage(j,'image')}catch(e){await sendText(sock,j,`⚠️ ${e.message}`)}finally{if(file)try{fs.unlinkSync(file)}catch{}}sessions.delete(j);continue;
    }
    if(/^https?:\/\//i.test(text)){await sendDownloadMenu(sock,j,text);continue}
    await home(sock,j);
   }catch(e){logger.error({err:e.message},'message handler');await sendText(sock,j,`⚠️ ${t(j,'error')}\n${safeText(e.message,800)}`).catch(()=>{})}
  }
 });
 return sock;
}
module.exports={startBot};

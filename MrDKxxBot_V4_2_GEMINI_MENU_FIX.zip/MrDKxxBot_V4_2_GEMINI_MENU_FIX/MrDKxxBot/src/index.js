require('dotenv').config();
const fs=require('fs');
const path=require('path');
const {startBot}=require('./bot');
const {startDashboard}=require('./dashboard');
const {logger}=require('./utils');

const lockPath=path.resolve(process.env.INSTANCE_LOCK_FILE||'data/mrdkxx.pid');
function processExists(pid){try{process.kill(Number(pid),0);return true}catch{return false}}
function acquireLock(){
 fs.mkdirSync(path.dirname(lockPath),{recursive:true});
 try{fs.writeFileSync(lockPath,String(process.pid),{flag:'wx'});return true}catch(e){
  if(e.code!=='EEXIST')throw e;
  let oldPid='';try{oldPid=fs.readFileSync(lockPath,'utf8').trim()}catch{}
  if(oldPid&&processExists(oldPid))throw new Error(`Another MR DKxx instance is already running (PID ${oldPid}). Stop it before starting a second copy.`);
  try{fs.unlinkSync(lockPath)}catch{}
  fs.writeFileSync(lockPath,String(process.pid),{flag:'wx'});return true;
 }
}
function releaseLock(){try{if(fs.readFileSync(lockPath,'utf8').trim()===String(process.pid))fs.unlinkSync(lockPath)}catch{}}

(async()=>{
 acquireLock();
 process.once('exit',releaseLock);
 process.once('SIGINT',()=>{releaseLock();process.exit(0)});
 process.once('SIGTERM',()=>{releaseLock();process.exit(0)});
 await startBot();
 startDashboard();
})().catch(e=>{releaseLock();logger.error(e);process.exit(1)});

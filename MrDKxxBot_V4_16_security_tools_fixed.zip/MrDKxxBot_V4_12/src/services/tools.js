const QRCode=require('qrcode');
const crypto=require('crypto');
const path=require('path');
const dns=require('dns');
const tls=require('tls');
const {tmpDir}=require('../utils');
async function fetchWithTimeout(url,options={},ms=15000){
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),ms);
 try{return await fetch(url,{...options,signal:controller.signal})}catch(e){if(e?.name==='AbortError')throw new Error(`Request timed out after ${Math.round(ms/1000)}s`);throw e}finally{clearTimeout(timer)}
}

async function qr(text){const out=path.join(tmpDir,`qr-${Date.now()}.png`);await QRCode.toFile(out,String(text),{width:700,margin:2});return out}
function calc(expr){const s=String(expr||'').trim();if(!s||s.length>300||!/^[0-9+\-*/%().\s]+$/.test(s))throw new Error('Only arithmetic expressions are allowed');const v=Function(`"use strict";return (${s})`)();if(!Number.isFinite(Number(v)))throw new Error('Calculation returned a non-finite value');return v}
function isSafeUrl(v){try{const u=new URL(String(v));return ['http:','https:'].includes(u.protocol)}catch{return false}}
async function urlInfo(url){if(!isSafeUrl(url))throw new Error('Invalid URL');let r=null,last=null;for(const method of ['HEAD','GET'])try{r=await fetch(new URL(url),{method,redirect:'follow',headers:{'user-agent':'MR-DKxx/4.5'}});if(r.ok||method==='GET')break}catch(e){last=e}if(!r)throw last||new Error('URL request failed');let ct=r.headers.get('content-type')||'',title='';if(ct.includes('text/html')){let html='';try{html=await r.text()}catch{}title=(html.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1]||'').replace(/\s+/g,' ').trim().slice(0,180)}return {finalUrl:r.url||url,status:r.status,statusText:r.statusText||'',contentType:ct,contentLength:r.headers.get('content-length')||'',title:title||new URL(r.url||url).hostname}}
function uuid(){return crypto.randomUUID()}
function password(length=16){const n=Math.min(64,Math.max(6,Number(length)||16));const chars='ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%^&*_-+=';let out='';for(let i=0;i<n;i++)out+=chars[crypto.randomInt(chars.length)];return out}
function hash(text,algorithm='sha256'){const a=['md5','sha1','sha256','sha512'].includes(String(algorithm).toLowerCase())?String(algorithm).toLowerCase():'sha256';return crypto.createHash(a).update(String(text)).digest('hex')}
function base64Encode(text){return Buffer.from(String(text),'utf8').toString('base64')}
function base64Decode(text){const s=String(text).trim();if(!/^[A-Za-z0-9+/]*={0,2}$/.test(s)||s.length%4===1)throw new Error('Invalid Base64');return Buffer.from(s,'base64').toString('utf8')}
function randomNumber(min=1,max=100){let a=Math.ceil(Number(min)),b=Math.floor(Number(max));if(!Number.isFinite(a)||!Number.isFinite(b)||a>b)throw new Error('Invalid range');return crypto.randomInt(a,b+1)}
function jsonFormat(text){return JSON.stringify(JSON.parse(String(text)),null,2)}
function timestamp(value=''){const d=value?new Date(value):new Date();if(Number.isNaN(d.getTime()))throw new Error('Invalid date/time');return {iso:d.toISOString(),unix:Math.floor(d.getTime()/1000),local:d.toString()}}
function unitConvert(value,from,to){const v=Number(value);if(!Number.isFinite(v))throw new Error('Invalid number');const f=String(from).toLowerCase(),t=String(to).toLowerCase();const table={m:1,km:1000,cm:0.01,mm:0.001,mi:1609.344,ft:0.3048,yd:0.9144,in:0.0254,kg:1,g:0.001,lb:0.45359237,oz:0.028349523125,l:1,ml:0.001};if(!(f in table)||!(t in table))throw new Error('Supported units: m km cm mm mi ft yd in kg g lb oz l ml');return v*table[f]/table[t]}
// Free, no-API-key currency conversion via open.er-api.com (161 currencies, daily rates).
async function currencyConvert(amount,from,to){
 const amt=Number(amount);if(!Number.isFinite(amt))throw new Error('Invalid amount');
 const f=String(from||'').trim().toUpperCase(),tgt=String(to||'').trim().toUpperCase();
 if(!/^[A-Z]{3}$/.test(f)||!/^[A-Z]{3}$/.test(tgt))throw new Error('Use 3-letter currency codes, e.g. USD LKR');
 const r=await fetch(`https://open.er-api.com/v6/latest/${f}`,{headers:{'user-agent':'MR-DKxx/4.5'}});
 if(!r.ok)throw new Error('Currency service is unavailable right now.');
 const data=await r.json();
 if(data.result!=='success')throw new Error(data['error-type']||'Currency lookup failed');
 const rate=data.rates?.[tgt];
 if(!rate)throw new Error(`Unknown currency code: ${tgt}`);
 return {amount:amt,from:f,to:tgt,rate,result:amt*rate,updated:data.time_last_update_utc||''};
}
// Free, no-API-key weather via Open-Meteo (geocoding + forecast).
async function weather(city){
 const name=String(city||'').trim();if(!name)throw new Error('Please provide a city name');
 const g=await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(name)}&count=1`,{headers:{'user-agent':'MR-DKxx/4.5'}});
 if(!g.ok)throw new Error('Location service is unavailable right now.');
 const gj=await g.json();
 const place=gj.results?.[0];
 if(!place)throw new Error(`Could not find a location named "${name}"`);
 const f=await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${place.latitude}&longitude=${place.longitude}&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m&timezone=auto`,{headers:{'user-agent':'MR-DKxx/4.5'}});
 if(!f.ok)throw new Error('Weather service is unavailable right now.');
 const fj=await f.json();
 const c=fj.current||{};
 const codes={0:'☀️ Clear sky',1:'🌤️ Mostly clear',2:'⛅ Partly cloudy',3:'☁️ Overcast',45:'🌫️ Fog',48:'🌫️ Fog',51:'🌦️ Light drizzle',53:'🌦️ Drizzle',55:'🌦️ Heavy drizzle',61:'🌧️ Light rain',63:'🌧️ Rain',65:'🌧️ Heavy rain',71:'🌨️ Light snow',73:'🌨️ Snow',75:'🌨️ Heavy snow',80:'🌦️ Rain showers',81:'🌦️ Rain showers',82:'⛈️ Violent showers',95:'⛈️ Thunderstorm',96:'⛈️ Thunderstorm with hail',99:'⛈️ Thunderstorm with hail'};
 return {
  place:`${place.name}${place.country?', '+place.country:''}`,
  temp:c.temperature_2m,feelsLike:c.apparent_temperature,humidity:c.relative_humidity_2m,
  wind:c.wind_speed_10m,precipitation:c.precipitation,
  condition:codes[c.weather_code]||'🌡️ Weather data',
  timezone:fj.timezone||''
 };
}
// Free, no-API-key top headlines via Google News RSS.
async function newsHeadlines(topic=''){
 const q=String(topic||'').trim();
 const url=q?`https://news.google.com/rss/search?q=${encodeURIComponent(q)}&hl=en-US&gl=US&ceid=US:en`:'https://news.google.com/rss?hl=en-US&gl=US&ceid=US:en';
 const r=await fetch(url,{headers:{'user-agent':'MR-DKxx/4.5'}});
 if(!r.ok)throw new Error('News service is unavailable right now.');
 const xml=await r.text();
 const items=[...xml.matchAll(/<item>([\s\S]*?)<\/item>/g)].slice(0,8).map(m=>{
  const block=m[1];
  const title=(block.match(/<title>([\s\S]*?)<\/title>/)?.[1]||'').replace(/<!\[CDATA\[|\]\]>/g,'').trim();
  const link=(block.match(/<link>([\s\S]*?)<\/link>/)?.[1]||'').trim();
  const source=(block.match(/<source[^>]*>([\s\S]*?)<\/source>/)?.[1]||'').replace(/<!\[CDATA\[|\]\]>/g,'').trim();
  return {title,link,source};
 }).filter(x=>x.title);
 if(!items.length)throw new Error('No headlines found.');
 return items;
}
// Free, no-API-key prayer times via Aladhan API.
async function prayerTimes(city,country){
 const c=String(city||'').trim(),co=String(country||'').trim();
 if(!c)throw new Error('Please provide a city (and optionally a country).');
 const url=`https://api.aladhan.com/v1/timingsByCity?city=${encodeURIComponent(c)}&country=${encodeURIComponent(co||'')}&method=2`;
 const r=await fetch(url,{headers:{'user-agent':'MR-DKxx/4.5'}});
 if(!r.ok)throw new Error('Prayer times service is unavailable right now.');
 const j=await r.json();
 if(j.code!==200||!j.data)throw new Error('Could not find prayer times for that location.');
 const t=j.data.timings;
 return {date:j.data.date?.readable||'',fajr:t.Fajr,dhuhr:t.Dhuhr,asr:t.Asr,maghrib:t.Maghrib,isha:t.Isha,place:`${c}${co?', '+co:''}`};
}
function bmi(weightKg,heightCm){
 const w=Number(weightKg),h=Number(heightCm)/100;
 if(!Number.isFinite(w)||w<=0||!Number.isFinite(h)||h<=0)throw new Error('Use: weight(kg) height(cm) — example: 70 175');
 const value=w/(h*h);
 const category=value<18.5?'Underweight':value<25?'Normal weight':value<30?'Overweight':'Obese';
 return {value:Math.round(value*10)/10,category};
}
function ageCalc(dob){
 const d=new Date(String(dob).trim());
 if(isNaN(d.getTime()))throw new Error('Use a date like: 1998-05-20 or 20/05/1998');
 const now=new Date();
 if(d>now)throw new Error('That date is in the future.');
 let years=now.getFullYear()-d.getFullYear(),months=now.getMonth()-d.getMonth(),days=now.getDate()-d.getDate();
 if(days<0){months--;days+=new Date(now.getFullYear(),now.getMonth(),0).getDate()}
 if(months<0){years--;months+=12}
 const totalDays=Math.floor((now-d)/86400000);
 return {years,months,days,totalDays};
}
// Free, no-API-key IP/domain lookup via ipapi.co.
async function ipLookup(query){
 const q=String(query||'').trim();
 const url=q?`https://ipapi.co/${encodeURIComponent(q)}/json/`:'https://ipapi.co/json/';
 const r=await fetch(url,{headers:{'user-agent':'MR-DKxx/4.5'}});
 if(!r.ok)throw new Error('IP lookup service is unavailable right now.');
 const j=await r.json();
 if(j.error)throw new Error(j.reason||'Could not look up that address.');
 return {ip:j.ip,city:j.city,region:j.region,country:j.country_name,isp:j.org||j.asn||'',timezone:j.timezone,lat:j.latitude,lon:j.longitude};
}
// Free, no-API-key dad joke via icanhazdadjoke.com.
async function dadJoke(){
 const r=await fetch('https://icanhazdadjoke.com/',{headers:{Accept:'application/json','user-agent':'MR-DKxx/4.5'}});
 if(!r.ok)throw new Error('Joke service is unavailable right now.');
 const j=await r.json();
 if(!j.joke)throw new Error('No joke returned.');
 return j.joke;
}
// Free, no-API-key inspirational quote via ZenQuotes.
async function randomQuote(){
 const r=await fetch('https://zenquotes.io/api/random',{headers:{'user-agent':'MR-DKxx/4.5'}});
 if(!r.ok)throw new Error('Quote service is unavailable right now.');
 const j=await r.json();
 const q=Array.isArray(j)?j[0]:null;
 if(!q?.q)throw new Error('No quote returned.');
 return {text:q.q,author:q.a||'Unknown'};
}
const EIGHT_BALL_ANSWERS=['Yes, definitely.','It is certain.','Without a doubt.','Yes.','Most likely.','Outlook good.','Signs point to yes.','Reply hazy, try again.','Ask again later.','Better not tell you now.','Cannot predict now.',"Don't count on it.",'My reply is no.','My sources say no.','Outlook not so good.','Very doubtful.'];
function magic8ball(){return EIGHT_BALL_ANSWERS[crypto.randomInt(EIGHT_BALL_ANSWERS.length)]}
function rollDice(sides=6,count=1){
 const s=Math.min(1000,Math.max(2,Number(sides)||6));
 const n=Math.min(20,Math.max(1,Number(count)||1));
 const rolls=Array.from({length:n},()=>crypto.randomInt(1,s+1));
 return {sides:s,rolls,total:rolls.reduce((a,b)=>a+b,0)};
}
function coinFlip(){return crypto.randomInt(2)===0?'Heads':'Tails'}
// Free, no-API-key random dog photo via dog.ceo.
async function randomDogImage(){
 const r=await fetch('https://dog.ceo/api/breeds/image/random',{headers:{'user-agent':'MR-DKxx/4.5'}});
 if(!r.ok)throw new Error('Dog image service is unavailable right now.');
 const j=await r.json();
 if(j.status!=='success'||!j.message)throw new Error('No dog image returned.');
 return j.message;
}
// Free, no-API-key random cat photo via TheCatAPI's public search endpoint.
async function randomCatImage(){
 const r=await fetch('https://api.thecatapi.com/v1/images/search',{headers:{'user-agent':'MR-DKxx/4.5'}});
 if(!r.ok)throw new Error('Cat image service is unavailable right now.');
 const j=await r.json();
 const url=j?.[0]?.url;
 if(!url)throw new Error('No cat image returned.');
 return url;
}
// Free, no-API-key life advice via adviceslip.com.
async function advice(){
 const r=await fetch('https://api.adviceslip.com/advice',{headers:{'user-agent':'MR-DKxx/4.5'}});
 if(!r.ok)throw new Error('Advice service is unavailable right now.');
 const j=await r.json();
 const text=j?.slip?.advice;
 if(!text)throw new Error('No advice returned.');
 return text;
}
// Free, no-API-key trivia question via Open Trivia DB.
async function trivia(){
 const r=await fetch('https://opentdb.com/api.php?amount=1',{headers:{'user-agent':'MR-DKxx/4.5'}});
 if(!r.ok)throw new Error('Trivia service is unavailable right now.');
 const j=await r.json();
 const q=j?.results?.[0];
 if(!q)throw new Error('No trivia question returned.');
 const decode=(s)=>String(s||'').replace(/&#?\w+;/g,(e)=>{const map={'&amp;':'&','&quot;':'"','&#039;':"'",'&eacute;':'é','&uuml;':'ü','&ouml;':'ö','&auml;':'ä','&rsquo;':'’',' &ldquo;':'“','&rdquo;':'”'};return map[e]||e});
 const options=[...q.incorrect_answers.map(decode),decode(q.correct_answer)].sort(()=>Math.random()-0.5);
 return {category:decode(q.category),question:decode(q.question),options,answer:decode(q.correct_answer)};
}
// Free, no-API-key trivia fact about a number via numbersapi.com.
async function numberFact(n){
 const v=String(n||'').trim();
 const url=v&&/^-?\d+$/.test(v)?`https://numbersapi.com/${v}`:'https://numbersapi.com/random/trivia';
 const r=await fetch(url,{headers:{'user-agent':'MR-DKxx/4.5'}});
 if(!r.ok)throw new Error('Number fact service is unavailable right now.');
 return (await r.text()).trim();
}
// Free, no-API-key Chuck Norris joke via api.chucknorris.io.
async function chuckNorrisJoke(){
 const r=await fetch('https://api.chucknorris.io/jokes/random',{headers:{'user-agent':'MR-DKxx/4.5'}});
 if(!r.ok)throw new Error('Joke service is unavailable right now.');
 const j=await r.json();
 if(!j.value)throw new Error('No joke returned.');
 return j.value;
}
// Free, no-API-key URL shortener via is.gd.
async function shortenUrl(url){
 if(!isSafeUrl(url))throw new Error('Please send a valid http/https URL.');
 const r=await fetch(`https://is.gd/create.php?format=simple&url=${encodeURIComponent(url)}`,{headers:{'user-agent':'MR-DKxx/4.5'}});
 const text=(await r.text()).trim();
 if(!r.ok||!/^https?:\/\//.test(text))throw new Error(text||'URL shortening failed.');
 return text;
}
// Local, no-network word/character counter.
function wordCount(text){
 const s=String(text||'');
 const words=(s.trim().match(/\S+/g)||[]).length;
 const chars=s.length;
 const charsNoSpaces=s.replace(/\s/g,'').length;
 const sentences=(s.match(/[.!?]+(?:\s|$)/g)||[]).length||(s.trim()?1:0);
 return {words,chars,charsNoSpaces,sentences};
}
// Local, no-network text case converter. Returns all common variants.
function textCase(text){
 const s=String(text||'');
 const title=s.replace(/\w\S*/g,(w)=>w[0].toUpperCase()+w.slice(1).toLowerCase());
 const sentence=s.toLowerCase().replace(/(^\s*\w|[.!?]\s+\w)/g,(m)=>m.toUpperCase());
 return {upper:s.toUpperCase(),lower:s.toLowerCase(),title,sentence};
}
// Free, no-API-key Wikipedia search via MediaWiki API.
async function wikiSearch(query){
 const q=String(query||'').trim();if(!q)throw new Error('Please send a search term.');
 const url=`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(q.replace(/ /g,'_'))}`;
 const r=await fetch(url,{headers:{'user-agent':'MrDKxxBot/4.12','accept':'application/json'}});
 if(r.status===404){
  // Try search API if direct page lookup fails
  const sr=await fetch(`https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(q)}&format=json&utf8=1&srlimit=1`,{headers:{'user-agent':'MrDKxxBot/4.12'}});
  if(!sr.ok)throw new Error('Wikipedia service unavailable.');
  const sj=await sr.json();
  const top=sj.query?.search?.[0];
  if(!top)throw new Error(`No Wikipedia article found for "${q}".`);
  const r2=await fetch(`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(top.title.replace(/ /g,'_'))}`,{headers:{'user-agent':'MrDKxxBot/4.12','accept':'application/json'}});
  if(!r2.ok)throw new Error('Wikipedia article unavailable.');
  const j2=await r2.json();
  return {title:j2.title,extract:j2.extract?.slice(0,800)||'No summary.',url:j2.content_urls?.desktop?.page||''};
 }
 if(!r.ok)throw new Error('Wikipedia service unavailable.');
 const j=await r.json();
 if(j.type==='disambiguation')throw new Error(`"${j.title}" is a disambiguation page. Try a more specific search.`);
 return {title:j.title,extract:j.extract?.slice(0,800)||'No summary.',url:j.content_urls?.desktop?.page||''};
}
// Free, no-API-key English dictionary via dictionaryapi.dev (open source).
async function dictionary(word){
 const w=String(word||'').trim().split(/\s+/)[0];if(!w)throw new Error('Please send a word to look up.');
 const r=await fetch(`https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(w)}`,{headers:{'user-agent':'MrDKxxBot/4.12'}});
 if(r.status===404)throw new Error(`Word "${w}" not found in dictionary.`);
 if(!r.ok)throw new Error('Dictionary service unavailable.');
 const j=await r.json();
 const entry=Array.isArray(j)?j[0]:j;
 const meanings=(entry.meanings||[]).slice(0,3).map(m=>{
  const defs=m.definitions?.slice(0,2).map(d=>d.definition)||[];
  return {partOfSpeech:m.partOfSpeech,definitions:defs,synonyms:(m.synonyms||[]).slice(0,4)};
 });
 const phonetic=entry.phonetic||entry.phonetics?.find(p=>p.text)?.text||'';
 return {word:entry.word||w,phonetic,meanings};
}
// Free, no-API-key GitHub user/repo info via GitHub public API (60 req/hr).
async function githubInfo(query){
 const q=String(query||'').trim();if(!q)throw new Error('Send a GitHub username or user/repo.');
 const isRepo=q.includes('/');
 const url=isRepo?`https://api.github.com/repos/${q}`:`https://api.github.com/users/${q}`;
 const r=await fetch(url,{headers:{'user-agent':'MrDKxxBot/4.12','accept':'application/vnd.github+json'}});
 if(r.status===404)throw new Error(`"${q}" not found on GitHub.`);
 if(r.status===403)throw new Error('GitHub rate limit reached. Try again in a minute.');
 if(!r.ok)throw new Error('GitHub API unavailable.');
 const j=await r.json();
 if(isRepo){
  return {type:'repo',name:j.full_name,description:j.description||'',stars:j.stargazers_count,forks:j.forks_count,language:j.language||'-',topics:(j.topics||[]).slice(0,5),url:j.html_url,updated:j.updated_at?.slice(0,10)||''};
 }
 return {type:'user',login:j.login,name:j.name||'',bio:j.bio||'',repos:j.public_repos,followers:j.followers,following:j.following,url:j.html_url,joined:j.created_at?.slice(0,10)||''};
}
// Free, no-API-key country info via restcountries.com.
async function countryInfo(name){
 const n=String(name||'').trim();if(!n)throw new Error('Please send a country name.');
 const r=await fetch(`https://restcountries.com/v3.1/name/${encodeURIComponent(n)}?fields=name,capital,region,subregion,population,area,currencies,languages,flags,timezones,tld`,{headers:{'user-agent':'MrDKxxBot/4.12'}});
 if(r.status===404)throw new Error(`Country "${n}" not found.`);
 if(!r.ok)throw new Error('Country info service unavailable.');
 const j=await r.json();
 const c=Array.isArray(j)?j[0]:j;
 const currencies=Object.values(c.currencies||{}).map(x=>`${x.name} (${x.symbol||''})`).join(', ');
 const languages=Object.values(c.languages||{}).join(', ');
 return {name:c.name?.common||n,official:c.name?.official||'',capital:(c.capital||[])[0]||'-',region:c.region||'-',subregion:c.subregion||'-',population:c.population||0,area:c.area||0,currencies,languages,timezone:(c.timezones||[])[0]||'-',tld:(c.tld||[])[0]||'-',flag:c.flags?.emoji||''};
}
// Local, no-network Morse code encoder/decoder.
const MORSE_MAP={A:'.-',B:'-...',C:'-.-.',D:'-..',E:'.',F:'..-.',G:'--.',H:'....',I:'..',J:'.---',K:'-.-',L:'.-..',M:'--',N:'-.',O:'---',P:'.--.',Q:'--.-',R:'.-.',S:'...',T:'-',U:'..-',V:'...-',W:'.--',X:'-..-',Y:'-.--',Z:'--..',0:'-----',1:'.----',2:'..---',3:'...--',4:'....-',5:'.....',6:'-....',7:'--...',8:'---..',9:'----.','.':'.-.-.-',',':'--..--','?':'..--..','/':'-..-.','+':'.-.-.','-':'-....-','=':'-...-','@':'.--.-.'};
const REVERSE_MORSE=Object.fromEntries(Object.entries(MORSE_MAP).map(([k,v])=>[v,k]));
function morseCode(text){
 const s=String(text||'').trim();
 // auto-detect: if it looks like morse (only . - / spaces), decode; else encode
 if(/^[.\- /]+$/.test(s)){
  // decode morse
  const decoded=s.split(' / ').map(word=>word.split(' ').map(code=>REVERSE_MORSE[code]||'?').join('')).join(' ');
  return {mode:'decode',result:decoded};
 }
 // encode to morse
 const encoded=s.toUpperCase().split('').map(c=>{if(c===' ')return '/';return MORSE_MAP[c]||'?'}).join(' ');
 return {mode:'encode',result:encoded};
}
// Local, no-network Roman numeral encoder/decoder.
function romanNumerals(input){
 const s=String(input||'').trim();
 // decode if it looks like roman numerals
 if(/^[IVXLCDM]+$/i.test(s)){
  const vals={I:1,V:5,X:10,L:50,C:100,D:500,M:1000};
  const upper=s.toUpperCase();
  let result=0;
  for(let i=0;i<upper.length;i++){
   const curr=vals[upper[i]]||0,next=vals[upper[i+1]]||0;
   result+=curr<next?-curr:curr;
  }
  if(result<=0||result>3999)throw new Error('Invalid Roman numeral.');
  return {mode:'decode',input:upper,result};
 }
 // encode number to roman
 const n=parseInt(s,10);
 if(isNaN(n)||n<1||n>3999)throw new Error('Enter a number (1–3999) or valid Roman numerals (I–M).');
 const parts=[[1000,'M'],[900,'CM'],[500,'D'],[400,'CD'],[100,'C'],[90,'XC'],[50,'L'],[40,'XL'],[10,'X'],[9,'IX'],[5,'V'],[4,'IV'],[1,'I']];
 let rem=n,roman='';
 for(const [v,r] of parts){while(rem>=v){roman+=r;rem-=v}}
 return {mode:'encode',input:n,result:roman};
}
// Free, no-API-key fake person data generator (for dev/testing) — all local.
function fakePerson(){
 const firstM=['James','John','Robert','Michael','William','David','Richard','Joseph','Thomas','Charles','Amir','Carlos','Ravi','Sanjay','Mohamed','Liam','Noah','Oliver'];
 const firstF=['Mary','Patricia','Jennifer','Linda','Barbara','Elizabeth','Susan','Jessica','Sarah','Karen','Aisha','Sofia','Priya','Ayasha','Fatima','Emma','Olivia','Ava'];
 const last=['Smith','Johnson','Williams','Brown','Jones','Garcia','Miller','Davis','Wilson','Taylor','Anderson','Thomas','Jackson','White','Harris','Martin','Thompson','Lee'];
 const domains=['gmail.com','yahoo.com','outlook.com','proton.me','hotmail.com'];
 const cities=['New York','London','Paris','Tokyo','Sydney','Toronto','Dubai','Singapore','Mumbai','Colombo'];
 const isMale=Math.random()<0.5;
 const first=(isMale?firstM:firstF)[Math.floor(Math.random()*firstM.length)];
 const surname=last[Math.floor(Math.random()*last.length)];
 const birth=new Date(Date.now()-Math.random()*1.5e12-5e11);
 const email=`${first.toLowerCase()}.${surname.toLowerCase()}${Math.floor(Math.random()*999)+1}@${domains[Math.floor(Math.random()*domains.length)]}`;
 const phone=`+${Math.floor(Math.random()*9)+1}${Array.from({length:9},()=>Math.floor(Math.random()*10)).join('')}`;
 return {name:`${first} ${surname}`,gender:isMale?'Male':'Female',dob:birth.toISOString().slice(0,10),email,phone,city:cities[Math.floor(Math.random()*cities.length)]};
}
// Free, no-API-key colour info via thecolorapi.com (no key required).
async function colorInfo(hexOrName){
 const q=String(hexOrName||'').trim().replace(/^#/,'');
 const isHex=/^[0-9A-Fa-f]{3}$|^[0-9A-Fa-f]{6}$/.test(q);
 const param=isHex?`hex=${q}`:`name=${encodeURIComponent(q)}`;
 const r=await fetch(`https://www.thecolorapi.com/id?${param}&format=json`,{headers:{'user-agent':'MrDKxxBot/4.12'}});
 if(!r.ok)throw new Error('Color API unavailable.');
 const j=await r.json();
 return {name:j.name?.value||'Unknown',hex:j.hex?.value||'',rgb:`${j.rgb?.r},${j.rgb?.g},${j.rgb?.b}`,hsl:`${j.hsl?.h}°,${j.hsl?.s}%,${j.hsl?.l}%`,contrast:j.contrast?.value||''};
}
// Free, no-API-key "on this day in history" via Wikipedia API.
async function onThisDay(){
 const now=new Date();const m=now.getMonth()+1,d=now.getDate();
 const r=await fetch(`https://en.wikipedia.org/api/rest_v1/feed/onthisday/events/${m}/${d}`,{headers:{'user-agent':'MrDKxxBot/4.12','accept':'application/json'}});
 if(!r.ok)throw new Error('History service unavailable.');
 const j=await r.json();
 const events=(j.events||[]).slice(0,5).map(e=>({year:e.year,text:e.text?.slice(0,120)||''}));
 return {date:`${m}/${d}`,events};
}
// Local, no-network text encryption/decryption using AES-256-GCM.
const crypto2=require('crypto');
function encryptText(text,passphrase){
 const t=String(text||'').trim(),p=String(passphrase||'').trim();
 if(!t||!p)throw new Error('Usage: text | passphrase');
 const key=crypto2.scryptSync(p,'mrdkxx',32),iv=crypto2.randomBytes(12);
 const cipher=crypto2.createCipheriv('aes-256-gcm',key,iv);
 const enc=Buffer.concat([cipher.update(t,'utf8'),cipher.final()]);
 const tag=cipher.getAuthTag();
 return Buffer.concat([iv,tag,enc]).toString('base64');
}
function decryptText(encoded,passphrase){
 const p=String(passphrase||'').trim();if(!p)throw new Error('Usage: encrypted_text | passphrase');
 try{
  const buf=Buffer.from(String(encoded||'').trim(),'base64');
  const key=crypto2.scryptSync(p,'mrdkxx',32);
  const iv=buf.slice(0,12),tag=buf.slice(12,28),enc=buf.slice(28);
  const decipher=crypto2.createDecipheriv('aes-256-gcm',key,iv);
  decipher.setAuthTag(tag);
  return Buffer.concat([decipher.update(enc),decipher.final()]).toString('utf8');
 }catch{throw new Error('Decryption failed — wrong passphrase or corrupted data.')}
}
// ---- Extra free tools (V4.13) — all local/no-key or free public APIs, same style as above ----
// Local, no-network percentage calculator supporting several common phrasings.
function percentCalc(text){
 const s=String(text||'').trim();
 let m;
 if(m=s.match(/^([\d.]+)\s*%\s*of\s*([\d.]+)$/i)){
  const pct=Number(m[1]),base=Number(m[2]);
  return `${pct}% of ${base} = ${(pct/100*base).toFixed(2)}`;
 }
 if(m=s.match(/^([\d.]+)\s*increase\s*([\d.]+)\s*%$/i)){
  const base=Number(m[1]),pct=Number(m[2]);
  return `${base} increased by ${pct}% = ${(base*(1+pct/100)).toFixed(2)}`;
 }
 if(m=s.match(/^([\d.]+)\s*decrease\s*([\d.]+)\s*%$/i)){
  const base=Number(m[1]),pct=Number(m[2]);
  return `${base} decreased by ${pct}% = ${(base*(1-pct/100)).toFixed(2)}`;
 }
 if(m=s.match(/^([\d.]+)\s*is\s*what\s*percent\s*of\s*([\d.]+)$/i)){
  const part=Number(m[1]),base=Number(m[2]);
  if(!base)throw new Error('Base value cannot be zero.');
  return `${part} is ${(part/base*100).toFixed(2)}% of ${base}`;
 }
 throw new Error('Use one of:\n20% of 500\n500 increase 20%\n500 decrease 15%\n50 is what percent of 200');
}
// Local, no-network countdown/count-up to a target date.
function countdownCalc(text){
 const s=String(text||'').trim();
 const parts=s.split(/\s+/);
 const dateStr=parts[0];
 const label=parts.slice(1).join(' ')||'that date';
 if(!dateStr)throw new Error('Use: <date> [label]\nExample: 2026-12-31 New Year');
 const d=new Date(dateStr);
 if(isNaN(d.getTime()))throw new Error('Use a date like: 2026-12-31 New Year');
 const diffMs=d.getTime()-Date.now();
 const past=diffMs<0;
 const abs=Math.abs(diffMs);
 const days=Math.floor(abs/86400000);
 const hours=Math.floor((abs%86400000)/3600000);
 const minutes=Math.floor((abs%3600000)/60000);
 return {label,date:d.toDateString(),days,hours,minutes,past};
}
// Local, no-network bill/expense splitter with optional tip percentage.
function splitBill(text){
 const a=String(text||'').trim().split(/\s+/).filter(Boolean);
 const total=Number(a[0]),people=Number(a[1]),tipPct=a[2]?Number(a[2]):0;
 if(!Number.isFinite(total)||total<=0||!Number.isFinite(people)||people<1||!Number.isFinite(tipPct)||tipPct<0)
  throw new Error('Use: total_amount number_of_people [tip%]\nExample: 4500 4 10');
 const tipAmount=total*(tipPct/100);
 const grandTotal=total+tipAmount;
 return {total,people,tipPct,tipAmount,grandTotal,perPerson:grandTotal/Math.floor(people)};
}
// Local, no-network random winner/name picker (comma or newline separated entries).
function pickWinner(text,count=1){
 const entries=String(text||'').split(/[,\n]+/).map(x=>x.trim()).filter(Boolean);
 if(entries.length<2)throw new Error('Send at least 2 names/entries separated by commas or new lines.');
 const n=Math.min(Math.max(1,Number(count)||1),entries.length);
 const pool=[...entries];
 const winners=[];
 for(let i=0;i<n;i++){const idx=crypto.randomInt(pool.length);winners.push(pool.splice(idx,1)[0])}
 return {entries:entries.length,winners};
}
// Free, no-API-key public holidays via date.nager.at.
async function publicHolidays(text){
 const parts=String(text||'').trim().split(/\s+/).filter(Boolean);
 let code='',year=new Date().getFullYear();
 for(const p of parts){if(/^\d{4}$/.test(p))year=Number(p);else if(/^[A-Za-z]{2}$/.test(p))code=p.toUpperCase()}
 if(!code)throw new Error('Send a 2-letter country code (and optional year).\nExample: LK 2026\nExample: US');
 const r=await fetch(`https://date.nager.at/api/v3/PublicHolidays/${year}/${code}`,{headers:{'user-agent':'MrDKxxBot/4.13'}});
 if(r.status===404)throw new Error(`No holiday data for country code "${code}".`);
 if(!r.ok)throw new Error('Holiday service unavailable.');
 const j=await r.json();
 if(!Array.isArray(j)||!j.length)throw new Error(`No public holidays found for ${code} ${year}.`);
 return {code,year,holidays:j.slice(0,15).map(h=>({date:h.date,name:h.localName||h.name}))};
}
// ---- New Power Tools (V4.15) — pure JS or free/no-key public APIs, additive only ----
// Small city -> IANA timezone lookup for the time-zone converter (covers the most
// common cities for a Sri Lanka-based audience plus major world hubs).
const CITY_TZ={colombo:'Asia/Colombo',london:'Europe/London',dubai:'Asia/Dubai',doha:'Asia/Qatar',riyadh:'Asia/Riyadh',jeddah:'Asia/Riyadh',singapore:'Asia/Singapore','kuala lumpur':'Asia/Kuala_Lumpur',tokyo:'Asia/Tokyo',sydney:'Australia/Sydney',melbourne:'Australia/Melbourne',toronto:'America/Toronto','new york':'America/New_York','los angeles':'America/Los_Angeles',paris:'Europe/Paris',berlin:'Europe/Berlin',frankfurt:'Europe/Berlin',rome:'Europe/Rome',moscow:'Europe/Moscow',delhi:'Asia/Kolkata',mumbai:'Asia/Kolkata',chennai:'Asia/Kolkata',karachi:'Asia/Karachi',dhaka:'Asia/Dhaka',bangkok:'Asia/Bangkok','hong kong':'Asia/Hong_Kong',seoul:'Asia/Seoul',beijing:'Asia/Shanghai',shanghai:'Asia/Shanghai',auckland:'Pacific/Auckland',kuwait:'Asia/Kuwait',muscat:'Asia/Muscat',manama:'Asia/Bahrain','abu dhabi':'Asia/Dubai',amsterdam:'Europe/Amsterdam',zurich:'Europe/Zurich',madrid:'Europe/Madrid',lisbon:'Europe/Lisbon',cairo:'Africa/Cairo',nairobi:'Africa/Nairobi',johannesburg:'Africa/Johannesburg',jakarta:'Asia/Jakarta',manila:'Asia/Manila',male:'Indian/Maldives',kathmandu:'Asia/Kathmandu'};
function timezoneConvert(text){
 const s=String(text||'').trim();
 const m=s.match(/^(now|\d{1,2}:\d{2})\s+(.+?)\s+to\s+(.+)$/i);
 if(!m)throw new Error('Use: <time or "now"> <FromCity> to <ToCity>\nExample: 14:30 Colombo to London\nExample: now Colombo to Dubai');
 const [,timePart,fromCityRaw,toCityRaw]=m;
 const fromTz=CITY_TZ[fromCityRaw.trim().toLowerCase()],toTz=CITY_TZ[toCityRaw.trim().toLowerCase()];
 if(!fromTz)throw new Error(`Unknown city "${fromCityRaw.trim()}". Try a major city, e.g. Colombo, London, Dubai, Tokyo.`);
 if(!toTz)throw new Error(`Unknown city "${toCityRaw.trim()}". Try a major city, e.g. Colombo, London, Dubai, Tokyo.`);
 let base=new Date();
 if(timePart.toLowerCase()!=='now'){
  const [hh,mm]=timePart.split(':').map(Number);
  const nowInFrom=new Date(new Date().toLocaleString('en-US',{timeZone:fromTz}));
  const offsetMs=Date.now()-nowInFrom.getTime();
  nowInFrom.setHours(hh,mm,0,0);
  base=new Date(nowInFrom.getTime()+offsetMs);
 }
 const fmt=(tz)=>new Intl.DateTimeFormat('en-GB',{timeZone:tz,weekday:'short',day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit',hour12:true}).format(base);
 return {fromCity:fromCityRaw.trim(),toCity:toCityRaw.trim(),fromTime:fmt(fromTz),toTime:fmt(toTz)};
}
// Free, no-key crypto price lookup via CoinGecko's public API.
const COIN_ALIASES={btc:'bitcoin',eth:'ethereum',bnb:'binancecoin',sol:'solana',xrp:'ripple',doge:'dogecoin',ada:'cardano',matic:'matic-network',ltc:'litecoin',trx:'tron',dot:'polkadot',usdt:'tether',usdc:'usd-coin',shib:'shiba-inu',avax:'avalanche-2'};
async function cryptoPrice(text){
 const raw=String(text||'').trim().toLowerCase();
 if(!raw)throw new Error('Send a coin symbol or name.\nExample: btc\nExample: bitcoin');
 const id=COIN_ALIASES[raw]||raw.replace(/\s+/g,'-');
 const r=await fetchWithTimeout(`https://api.coingecko.com/api/v3/simple/price?ids=${encodeURIComponent(id)}&vs_currencies=usd,lkr&include_24hr_change=true`,{headers:{'user-agent':'MrDKxxBot/4.15'}},15000);
 if(!r.ok)throw new Error('Crypto price service unavailable right now.');
 const j=await r.json();
 const data=j?.[id];
 if(!data)throw new Error(`Coin "${raw}" not found. Try a symbol like btc, eth, sol, xrp.`);
 return {id,usd:data.usd,lkr:data.lkr,change24h:data.usd_24h_change};
}
// Local, no-network loan/EMI calculator.
function emiCalculate(text){
 const a=String(text||'').trim().split(/\s+/).filter(Boolean);
 const principal=Number(a[0]),annualRate=Number(a[1]),years=Number(a[2]);
 if(!Number.isFinite(principal)||principal<=0||!Number.isFinite(annualRate)||annualRate<0||!Number.isFinite(years)||years<=0)
  throw new Error('Use: principal annual_interest_rate years\nExample: 500000 12 5');
 const monthlyRate=annualRate/12/100,n=Math.round(years*12);
 const emi=monthlyRate===0?principal/n:(principal*monthlyRate*Math.pow(1+monthlyRate,n))/(Math.pow(1+monthlyRate,n)-1);
 const totalPayment=emi*n,totalInterest=totalPayment-principal;
 return {principal,annualRate,years,emi,totalPayment,totalInterest,n};
}
// Local, no-network digital business card (vCard) generator.
function vcardGenerate(text){
 const parts=String(text||'').split('|').map(x=>x.trim());
 const [name,phone,email,company]=parts;
 if(!name||!phone)throw new Error('Use: Name | Phone | Email | Company\nExample: Kasun Perera | +94771234567 | kasun@email.com | ABC Traders');
 const lines=['BEGIN:VCARD','VERSION:3.0',`FN:${name}`,`TEL;TYPE=CELL:${phone}`];
 if(email)lines.push(`EMAIL:${email}`);
 if(company)lines.push(`ORG:${company}`);
 lines.push('END:VCARD');
 return {name,vcf:lines.join('\r\n')};
}
// Local, no-network great-circle (Haversine) distance between two coordinates.
function haversineDistance(text){
 const parts=String(text||'').trim().split(/\s+/);
 const bad=()=>new Error('Use: lat1,lon1 lat2,lon2\nExample: 6.9271,79.8612 51.5074,-0.1278');
 if(parts.length<2)throw bad();
 const [lat1,lon1]=parts[0].split(',').map(Number),[lat2,lon2]=parts[1].split(',').map(Number);
 if(![lat1,lon1,lat2,lon2].every(Number.isFinite))throw bad();
 const R=6371,dLat=(lat2-lat1)*Math.PI/180,dLon=(lon2-lon1)*Math.PI/180;
 const aa=Math.sin(dLat/2)**2+Math.cos(lat1*Math.PI/180)*Math.cos(lat2*Math.PI/180)*Math.sin(dLon/2)**2;
 const km=R*2*Math.atan2(Math.sqrt(aa),Math.sqrt(1-aa));
 return {km,miles:km*0.621371};
}
// Local, no-network RFC 6238 TOTP 2FA code generator (same algorithm as Google/Microsoft Authenticator).
function base32Decode(input){
 const alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
 const clean=String(input||'').toUpperCase().replace(/[^A-Z2-7]/g,'');
 let bits='';for(const c of clean){const idx=alphabet.indexOf(c);if(idx>=0)bits+=idx.toString(2).padStart(5,'0')}
 const bytes=[];for(let i=0;i+8<=bits.length;i+=8)bytes.push(parseInt(bits.slice(i,i+8),2));
 return Buffer.from(bytes);
}
function totpGenerate(secret){
 const key=base32Decode(secret);
 if(!key.length)throw new Error('Send a valid base32 2FA secret key (the text shown under "can\'t scan the QR code" when setting up 2FA).');
 const step=30,counter=Math.floor(Date.now()/1000/step);
 const buf=Buffer.alloc(8);buf.writeBigUInt64BE(BigInt(counter));
 const hmac=crypto.createHmac('sha1',key).update(buf).digest();
 const offset=hmac[hmac.length-1]&0xf;
 const code=((hmac[offset]&0x7f)<<24|(hmac[offset+1]&0xff)<<16|(hmac[offset+2]&0xff)<<8|(hmac[offset+3]&0xff))%1000000;
 return {code:String(code).padStart(6,'0'),secondsLeft:step-(Math.floor(Date.now()/1000)%step)};
}
// Local, no-network stylised Unicode "fancy text" generator (Mathematical Alphanumeric block).
function fancyTextTransform(str,upperStart,lowerStart,digitStart){
 let out='';
 for(const ch of str){
  const code=ch.codePointAt(0);
  if(ch>='A'&&ch<='Z'&&upperStart)out+=String.fromCodePoint(upperStart+(code-65));
  else if(ch>='a'&&ch<='z'&&lowerStart)out+=String.fromCodePoint(lowerStart+(code-97));
  else if(ch>='0'&&ch<='9'&&digitStart)out+=String.fromCodePoint(digitStart+(code-48));
  else out+=ch;
 }
 return out;
}
function fancyText(text){
 const s=String(text||'').trim();
 if(!s)throw new Error('Send some text to style.\nExample: Mr DKxx');
 return [
  ['Bold',fancyTextTransform(s,0x1D400,0x1D41A,0x1D7CE)],
  ['Italic',fancyTextTransform(s,0x1D434,0x1D44E,0)],
  ['Monospace',fancyTextTransform(s,0x1D670,0x1D68A,0x1D7F6)],
  ['Bubble',fancyTextTransform(s,0x24B6,0x24D0,0)]
 ];
}
// Free, no-key synonyms/antonyms via the Datamuse public API.
async function thesaurusLookup(text){
 const word=String(text||'').trim().toLowerCase().split(/\s+/)[0];
 if(!word)throw new Error('Send a single word to look up.\nExample: happy');
 const [synRes,antRes]=await Promise.all([
  fetchWithTimeout(`https://api.datamuse.com/words?rel_syn=${encodeURIComponent(word)}&max=10`,{},15000),
  fetchWithTimeout(`https://api.datamuse.com/words?rel_ant=${encodeURIComponent(word)}&max=10`,{},15000)
 ]);
 const syn=synRes.ok?await synRes.json():[];
 const ant=antRes.ok?await antRes.json():[];
 if(!syn.length&&!ant.length)throw new Error(`No synonyms/antonyms found for "${word}".`);
 return {word,synonyms:syn.map(x=>x.word),antonyms:ant.map(x=>x.word)};
}
// Local, no-network phonetic Singlish -> Sinhala Unicode converter. This is a simple
// rule-based/phonetic mapping (not a dictionary), so casual chat words convert well
// but exact formal spelling (e.g. long "aa" endings on some verbs) may need a manual tweak.
const SG_VOWELS_INDEP=[['aae','ඈ'],['aa','ආ'],['ee','ඒ'],['ii','ඊ'],['uu','ඌ'],['oo','ඕ'],['ai','ඓ'],['au','ඖ'],['ae','ඇ'],['a','අ'],['i','ඉ'],['u','උ'],['e','එ'],['o','ඔ']].sort((a,b)=>b[0].length-a[0].length);
const SG_VOWEL_SIGNS=[['aae','ෑ'],['aa','ා'],['ee','ේ'],['ii','ී'],['uu','ූ'],['oo','ෝ'],['ai','ෛ'],['au','ෞ'],['ae','ැ'],['a',''],['i','ි'],['u','ු'],['e','ෙ'],['o','ො']].sort((a,b)=>b[0].length-a[0].length);
// Case matters here: lowercase t/d/n/l map to the dental/soft letters (ත/ද/න/ල) used
// in most everyday words (gedara, mama, kohomada); capitalised T/D/N/L map to the
// retroflex/hard letters (ට/ඩ/ණ/ළ) needed for words like oyaTa, kaDe, praaNa.
const SG_HARD_CONSONANTS=[['Th','ඨ'],['Dh','ඪ'],['T','ට'],['D','ඩ'],['N','ණ'],['L','ළ']].sort((a,b)=>b[0].length-a[0].length);
const SG_CONSONANTS=[['kh','ඛ'],['gh','ඝ'],['ng','ඞ'],['ch','ච'],['jh','ඣ'],['ny','ඤ'],['th','ථ'],['dh','ධ'],['ph','ඵ'],['bh','භ'],['sh','ශ'],['k','ක'],['g','ග'],['c','ච'],['j','ජ'],['t','ත'],['d','ද'],['n','න'],['p','ප'],['b','බ'],['m','ම'],['y','ය'],['r','ර'],['l','ල'],['v','ව'],['w','ව'],['s','ස'],['h','හ'],['f','ෆ']].sort((a,b)=>b[0].length-a[0].length);
function sgMatch(list,str,pos){for(const [key,val] of list)if(str.startsWith(key,pos))return {key,val};return null}
function singlishToSinhala(text){
 const raw=String(text||'');
 let out='',i=0;
 while(i<raw.length){
  const ch=raw[i];
  if(!/[a-zA-Z]/.test(ch)){out+=ch;i++;continue}
  let cons=sgMatch(SG_HARD_CONSONANTS,raw,i);
  if(!cons)cons=sgMatch(SG_CONSONANTS,raw.toLowerCase(),i);
  if(cons){
   i+=cons.key.length;
   const v=sgMatch(SG_VOWEL_SIGNS,raw.toLowerCase(),i);
   if(v&&v.key!=='a'){out+=cons.val+v.val;i+=v.key.length}
   else if(v&&v.key==='a'){out+=cons.val;i+=1}
   else out+=cons.val+'්';
   continue;
  }
  const vi=sgMatch(SG_VOWELS_INDEP,raw.toLowerCase(),i);
  if(vi){out+=vi.val;i+=vi.key.length;continue}
  out+=ch;i++;
 }
 return out;
}
// ---- Security & OSINT Tools (V4.16) — defensive/informational checks only. No port
// scanning, subdomain brute-forcing, or active exploitation: every function here does
// no more than a normal browser/monitoring tool already does (a plain public-info
// lookup, a normal TLS handshake, or a plain GET request) and only against a domain
// the user themselves provides — never used to attack or gain unauthorized access.
// Free public RDAP WHOIS lookup (rdap.org routes to the correct registry automatically).
async function whoisLookup(domainRaw){
 const d=String(domainRaw||'').trim().toLowerCase().replace(/^https?:\/\//,'').split('/')[0];
 if(!d||!/^[a-z0-9.-]+\.[a-z]{2,}$/i.test(d))throw new Error('Send a valid domain name.\nExample: example.com');
 const r=await fetchWithTimeout(`https://rdap.org/domain/${encodeURIComponent(d)}`,{headers:{'user-agent':'MrDKxxBot/4.16','accept':'application/rdap+json'}},15000);
 if(r.status===404)throw new Error(`No public registration data found for "${d}".`);
 if(!r.ok)throw new Error('WHOIS/RDAP service unavailable right now.');
 const j=await r.json();
 const events=Object.fromEntries((j.events||[]).map(e=>[e.eventAction,e.eventDate]));
 const ns=(j.nameservers||[]).map(n=>n.ldhName).filter(Boolean);
 return {domain:j.ldhName||d,status:(j.status||[]).join(', ')||'unknown',registered:events.registration||'unknown',expires:events.expiration||'unknown',updated:events['last changed']||events['last update of RDAP database']||'unknown',nameservers:ns};
}
// Standard public DNS record lookup (Node's built-in resolver — same as any device does).
async function dnsLookup(text){
 const parts=String(text||'').trim().split(/\s+/).filter(Boolean);
 const domain=(parts[0]||'').replace(/^https?:\/\//,'').split('/')[0];
 const type=(parts[1]||'A').toUpperCase();
 const supported=['A','AAAA','MX','TXT','NS','CNAME','SOA'];
 if(!domain)throw new Error(`Use: <domain> [record type]\nSupported types: ${supported.join(', ')}\nExample: example.com\nExample: example.com MX`);
 if(!supported.includes(type))throw new Error(`Supported record types: ${supported.join(', ')}`);
 try{const records=await dns.promises.resolve(domain,type);return {domain,type,records}}
 catch(e){throw new Error(`No ${type} records found for "${domain}" (${e.code||e.message}).`)}
}
// TLS/SSL certificate info — a plain TLS handshake to the site's public port 443,
// exactly what every browser does when you open the site; no scanning involved.
function sslCheck(hostnameRaw){
 const hostname=String(hostnameRaw||'').trim().replace(/^https?:\/\//,'').split('/')[0];
 if(!hostname)throw new Error('Send a domain name.\nExample: example.com');
 return new Promise((resolve,reject)=>{
  const socket=tls.connect({host:hostname,port:443,servername:hostname,timeout:10000},()=>{
   const cert=socket.getPeerCertificate();
   socket.end();
   if(!cert||!Object.keys(cert).length)return reject(new Error('No certificate returned by that host.'));
   const daysLeft=Math.ceil((new Date(cert.valid_to).getTime()-Date.now())/86400000);
   resolve({hostname,subject:cert.subject?.CN||hostname,issuer:cert.issuer?.O||cert.issuer?.CN||'Unknown',validFrom:cert.valid_from,validTo:cert.valid_to,daysLeft});
  });
  socket.on('error',(e)=>reject(new Error(`Could not connect on port 443: ${e.message}`)));
  socket.on('timeout',()=>{socket.destroy();reject(new Error('Connection timed out.'))});
 });
}
// HTTP security headers audit (same idea as securityheaders.com) — one plain GET
// request, then just reads which standard defensive headers the site already sends.
async function securityHeadersCheck(urlRaw){
 let url=String(urlRaw||'').trim();
 if(url&&!/^https?:\/\//i.test(url))url=`https://${url}`;
 if(!isSafeUrl(url))throw new Error('Send a valid http(s) URL.\nExample: example.com');
 const r=await fetchWithTimeout(url,{method:'GET',redirect:'follow',headers:{'user-agent':'MrDKxxBot-SecurityCheck/1.0'}},15000);
 const checks=[
  ['Strict-Transport-Security',r.headers.get('strict-transport-security')],
  ['Content-Security-Policy',r.headers.get('content-security-policy')],
  ['X-Frame-Options',r.headers.get('x-frame-options')],
  ['X-Content-Type-Options',r.headers.get('x-content-type-options')],
  ['Referrer-Policy',r.headers.get('referrer-policy')],
  ['Permissions-Policy',r.headers.get('permissions-policy')]
 ];
 const present=checks.filter(([,v])=>v).length;
 return {url:r.url||url,status:r.status,score:`${present}/${checks.length}`,checks};
}
// Password breach check using Have I Been Pwned's k-anonymity API: only the first 5
// hex characters of the SHA-1 hash are ever sent, so the full password/hash never
// leaves this check. Free, no API key. Standard practice used by password managers.
async function pwnedPasswordCheck(passwordRaw){
 const pw=String(passwordRaw||'');
 if(!pw)throw new Error('Send a password to check (use a test/throwaway password if you\'re unsure about pasting a real one into chat).');
 const sha1=crypto.createHash('sha1').update(pw).digest('hex').toUpperCase();
 const prefix=sha1.slice(0,5),suffix=sha1.slice(5);
 const r=await fetchWithTimeout(`https://api.pwnedpasswords.com/range/${prefix}`,{headers:{'user-agent':'MrDKxxBot/4.16'}},15000);
 if(!r.ok)throw new Error('Breach-check service unavailable right now.');
 const body=await r.text();
 const line=body.split('\n').find(l=>l.split(':')[0].trim()===suffix);
 const count=line?Number(line.split(':')[1]):0;
 return {pwned:count>0,count};
}
// Local, no-network password strength heuristic (length/character-class/entropy based).
function passwordStrength(passwordRaw){
 const pw=String(passwordRaw||'');
 if(!pw)throw new Error('Send a password to analyze.');
 const checks={length12plus:pw.length>=12,hasUpper:/[A-Z]/.test(pw),hasLower:/[a-z]/.test(pw),hasDigit:/[0-9]/.test(pw),hasSymbol:/[^A-Za-z0-9]/.test(pw),noLongRepeat:!/(.)\1{2,}/.test(pw)};
 const score=Object.values(checks).filter(Boolean).length;
 const label=score>=5?'Strong':score>=3?'Medium':'Weak';
 const poolSize=(checks.hasLower?26:0)+(checks.hasUpper?26:0)+(checks.hasDigit?10:0)+(checks.hasSymbol?32:0)||1;
 const entropyBits=Math.round(pw.length*Math.log2(poolSize));
 return {length:pw.length,label,score,entropyBits,checks};
}
module.exports={qr,calc,isSafeUrl,urlInfo,uuid,password,hash,base64Encode,base64Decode,randomNumber,jsonFormat,timestamp,unitConvert,currencyConvert,weather,newsHeadlines,prayerTimes,bmi,ageCalc,ipLookup,dadJoke,randomQuote,magic8ball,rollDice,coinFlip,randomDogImage,randomCatImage,advice,trivia,numberFact,chuckNorrisJoke,shortenUrl,wordCount,textCase,wikiSearch,dictionary,githubInfo,countryInfo,morseCode,romanNumerals,fakePerson,colorInfo,onThisDay,encryptText,decryptText,percentCalc,countdownCalc,splitBill,pickWinner,publicHolidays,timezoneConvert,cryptoPrice,emiCalculate,vcardGenerate,haversineDistance,totpGenerate,fancyText,thesaurusLookup,singlishToSinhala,whoisLookup,dnsLookup,sslCheck,securityHeadersCheck,pwnedPasswordCheck,passwordStrength};

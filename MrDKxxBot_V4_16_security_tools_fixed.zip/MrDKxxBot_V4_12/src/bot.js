const baileys=require('@whiskeysockets/baileys');
const {default:makeWASocket,useMultiFileAuthState,DisconnectReason,generateWAMessageFromContent,proto}=baileys;
const qrcode=require('qrcode-terminal');
const P=require('pino');
const fs=require('fs'),path=require('path');
const {logger,safeText}=require('./utils');
const db=require('./db');
const {t,change}=require('./i18n');
const {askAI,askWeb,providerStatus,geminiModels}=require('./services/ai');
const media=require('./services/media');
const {qr,calc,isSafeUrl,timestamp,unitConvert,dadJoke,randomQuote,magic8ball,rollDice,coinFlip,randomDogImage,randomCatImage,advice,trivia,numberFact,chuckNorrisJoke,shortenUrl,wordCount,textCase,wikiSearch,dictionary,githubInfo,countryInfo,morseCode,romanNumerals,fakePerson,colorInfo,onThisDay,encryptText,decryptText}=require('./services/tools');
const {image,tts,ocr,stt,vision,imageChoices,imageModels,providerStatus:imageProviderStatus}=require('./services/providers');
const sticker=require('./services/sticker');
const {downloadContentFromMessage}=baileys;
const {stats,clearHistory}=db;
const {JobQueue}=require('./services/queue');
const {isGroup,isOwner,isAdmin}=require('./group');

const AUTH_DIR=path.resolve(process.env.AUTH_DIR||'auth/mrdkxx');
const LOGO=path.resolve('assets/mr-dkxx-logo.png');
const sessions=new Map();
const fallbackMenus=new Map();
const seenMessages=new Map();
const recentInputs=new Map();
const inFlightInputs=new Set();
const aiBusyByJid=new Map();
const aiChains=new Map();
const recentAiResponses=new Map();
const logoSent=new Set();
let reconnectTimer=null;
let botPaused=false;
const queue=new JobQueue(Number(process.env.MAX_CONCURRENT_JOBS||2));
const startedAt=Date.now();

const {normalizeText,listParams,quickParams,nativeFlow}=require('./services/menu');
function row(id,title,description=''){return {title:String(title).slice(0,60),description:String(description).slice(0,72),rowId:id}}
function sessionKey(j,m){
 const actor=m?.key?.participant||m?.participant||j;
 return isGroup(j)?`${j}|${actor}`:j;
}
function buildMixedNativeFlowBizNode(){
 const privacy=(Math.floor(Date.now()/1000)-77980457).toString();
 return {tag:'biz',attrs:{actual_actors:'2',host_storage:'2',privacy_mode_ts:privacy},content:[
  {tag:'interactive',attrs:{type:'native_flow',v:'1'},content:[{tag:'native_flow',attrs:{v:'9',name:'mixed'}}]},
  {tag:'quality_control',attrs:{source_type:'third_party'}}
 ]};
}
function menuSection(type,id){
 const main={
  ai:'🧠 AI & INTELLIGENCE',media:'🎬 MEDIA & CONTENT',music:'🎵 MUSIC',image:'🎨 IMAGE AI',
  tools:'🛠️ TOOLS & UTILITIES',group:'👥 GROUP & ADMIN',downloads:'📥 DOWNLOADS',
  settings:'⚙️ SETTINGS',help:'ℹ️ HELP',owner:'👑 OWNER TOOLS',extra:'🎁 EXTRA TOOLS',security:'🛡️ SECURITY TOOLS'
 };
 if(type==='home') return main[id]||'📌 MENU';
 const groups={
  ai:{gemini:'🤖 AI CORE',chat:'🤖 AI CORE',local:'🤖 AI CORE',aistatus:'🤖 AI CORE',websearch:'🌐 UNDERSTANDING & WEB',vision:'🌐 UNDERSTANDING & WEB',summarize:'✍️ TEXT TOOLS',translate:'✍️ TEXT TOOLS',analyze:'✍️ TEXT TOOLS',grammar:'✍️ TEXT TOOLS',coding:'✍️ TEXT TOOLS',caption:'✍️ TEXT TOOLS',hashtags:'✍️ TEXT TOOLS',rewrite:'✍️ TEXT TOOLS',imageai:'🎨 IMAGE PROMPTS'},
  media:{video:'📹 VIDEO',audio:'🎵 AUDIO',info:'🔎 MEDIA INFO',compress_video:'🗜️ MEDIA TOOLS',audio_convert:'🗜️ MEDIA TOOLS',thumbnail:'🖼️ MEDIA TOOLS',gif:'🎞️ MEDIA TOOLS',sticker:'✨ MEDIA TOOLS',sticker2img:'✨ MEDIA TOOLS'},
  music:{audio:'🎵 MUSIC',info:'🔎 MEDIA INFO'},
  image:{imageGen:'🎨 GENERATE',imageModels:'🧠 MODELS',imageStatus:'🩺 STATUS',imageai:'✍️ PROMPTS'},
  tools:{qr:'🔧 QUICK TOOLS',calc:'🔧 QUICK TOOLS',url:'🔧 QUICK TOOLS',shorten:'🔧 QUICK TOOLS',wordcount:'🔧 QUICK TOOLS',textcase:'🔧 QUICK TOOLS',tts:'🎙️ VOICE & TEXT',ocr:'🎙️ VOICE & TEXT',stt:'🎙️ VOICE & TEXT',unit:'📐 CONVERTERS',timestamp:'📐 CONVERTERS',currency:'📐 CONVERTERS',bmi:'🩺 HEALTH & CALC',age:'🩺 HEALTH & CALC',weather:'🌦️ LIVE DATA',news:'🌦️ LIVE DATA',prayer:'🌦️ LIVE DATA',ipLookup:'🌦️ LIVE DATA',reminder:'⏰ REMINDERS',uuid:'🔐 SECURITY & DATA',password:'🔐 SECURITY & DATA',hash:'🔐 SECURITY & DATA',base64:'🔐 SECURITY & DATA',json:'🔐 SECURITY & DATA',encrypt:'🔐 SECURITY & DATA',decrypt:'🔐 SECURITY & DATA',random:'🔢 MISC',myid:'🔢 MISC',health:'🩺 SYSTEM',status:'🩺 SYSTEM',joke:'🎉 FUN & GAMES',quote:'🎉 FUN & GAMES',eightball:'🎉 FUN & GAMES',dice:'🎉 FUN & GAMES',coinflip:'🎉 FUN & GAMES',dogpic:'🎉 FUN & GAMES',catpic:'🎉 FUN & GAMES',advice:'🎉 FUN & GAMES',trivia:'🎉 FUN & GAMES',numberfact:'🎉 FUN & GAMES',chucknorris:'🎉 FUN & GAMES',fakeperson:'🎉 FUN & GAMES',wiki:'🌐 SEARCH & INFO',dict:'🌐 SEARCH & INFO',github:'🌐 SEARCH & INFO',country:'🌐 SEARCH & INFO',onthisday:'🌐 SEARCH & INFO',morse:'🔤 TEXT TOOLS',roman:'🔤 TEXT TOOLS',color:'🎨 COLOUR TOOLS'},
  group:{rules:'👥 GROUP INFO',setrules:'🛡️ ADMIN TOOLS',admins:'🛡️ ADMIN TOOLS',groupStats:'📊 GROUP INFO',warnings:'🛡️ MODERATION',tagall:'🛡️ MODERATION',moderation:'🛡️ MODERATION',poll:'📊 ENGAGEMENT',welcome:'👋 ENGAGEMENT'},
  settings:{language:'⚙️ SETTINGS',clear:'⚙️ SETTINGS',status:'⚙️ SETTINGS'},
  owner:{stats:'👑 OWNER',backup:'👑 OWNER',health:'👑 OWNER'},
  security:{whois:'🔎 DOMAIN INFO',dnslookup:'🔎 DOMAIN INFO',sslcheck:'🔒 CERTIFICATE',headers:'🛡️ WEB SECURITY',pwnedpw:'🕵️ BREACH CHECK',pwstrength:'💪 PASSWORD'},
  extra:{percent:'🧮 QUICK CALCULATORS',splitbill:'🧮 QUICK CALCULATORS',countdown:'🧮 QUICK CALCULATORS',emi:'🧮 QUICK CALCULATORS',distance:'🧮 QUICK CALCULATORS',picker:'🎉 GROUP FUN',notes:'📝 PERSONAL',holidays:'🌍 LIVE DATA',groupinvite:'👥 GROUP TOOLS',timezone:'🌍 LIVE DATA',cryptoprice:'🌍 LIVE DATA',vcard:'📇 SHARING',totp:'🔐 SECURITY',fancytext:'🎨 FUN & STYLE',thesaurus:'📚 LANGUAGE',singlish:'📚 LANGUAGE'}
 };
 return groups[type]?.[id]||'📌 MENU';
}
function buildPrettyMenu(body,items,{footer='MR DKxx',stateKey,type='home',title='MENU'}={}){
 const mapped=items.map((x,i)=>({number:String(i+1),id:String(x[0])}));
 fallbackMenus.set(stateKey,mapped);
 const width=38;
 const numBold=(value)=>String(value).replace(/\d/g,d=>({'0':'𝟎','1':'𝟏','2':'𝟐','3':'𝟑','4':'𝟒','5':'𝟓','6':'𝟔','7':'𝟕','8':'𝟖','9':'𝟗'}[d]||d));
 // Converts plain A-Z letters to bold mathematical unicode so section titles render
 // noticeably bigger/bolder on WhatsApp without relying on markdown asterisks.
 const boldCaps=(text)=>String(text).toUpperCase().split('').map(ch=>{
  const code=ch.codePointAt(0);
  if(code>=65&&code<=90)return String.fromCodePoint(0x1D400+(code-65));
  return ch;
 }).join('');
 // Unicode "small caps" letters for sub-item description bullets — gives each line a
 // deliberately smaller/lighter look than the bold item title above it, without
 // relying on italics (which some WhatsApp fonts render inconsistently).
 const SMALL_CAPS={a:'ᴀ',b:'ʙ',c:'ᴄ',d:'ᴅ',e:'ᴇ',f:'ꜰ',g:'ɢ',h:'ʜ',i:'ɪ',j:'ᴊ',k:'ᴋ',l:'ʟ',m:'ᴍ',n:'ɴ',o:'ᴏ',p:'ᴘ',q:'q',r:'ʀ',s:'ꜱ',t:'ᴛ',u:'ᴜ',v:'ᴠ',w:'ᴡ',x:'x',y:'ʏ',z:'ᴢ'};
 const smallCaps=(text)=>String(text).toLowerCase().split('').map(ch=>SMALL_CAPS[ch]||ch).join('');
 // Centers text within `width` visual columns. Used only for standalone header lines
 // (never alongside a fixed-width side border), so minor proportional-font drift
 // never shows up as a broken/misaligned box.
 const center=(txt)=>{
  const raw=String(txt||'').replace(/[*_]/g,'');
  // Split by Unicode code point (not UTF-16 code unit) so bold-unicode letters and
  // emoji, which are surrogate pairs, never get cut in half mid-character.
  const chars=Array.from(raw);
  const t=chars.slice(0,width-4);
  const left=Math.max(0,Math.floor((width-t.length)/2));
  const right=Math.max(0,width-t.length-left);
  return ' '.repeat(left)+t.join('')+' '.repeat(right);
 };
 const sectionTitle=(section)=>{
  const parts=String(section).split(/\s+/);
  const emoji=parts.shift()||'';
  const label=parts.join(' ').toUpperCase();
  return `${emoji} ${boldCaps(label)}`;
 };
 const out=[
  '╔══════════════════════════════════════╗',
  `║${center('✨ '+boldCaps('MR DKxx')+' ✨')}║`,
  `║${center(boldCaps(type==='home'?'MAIN MENU':String(title||'MENU')))}║`,
  '╚══════════════════════════════════════╝',
  '',
  normalizeText(body),
  ''
 ];
 let lastSection=null;
 items.forEach((x,i)=>{
  const id=String(x[0]);
  const section=menuSection(type,id);
  if(section!==lastSection){
   if(lastSection)out.push('');
   out.push(`╔─ ❖➤ ${sectionTitle(section)} ➥`);
   lastSection=section;
  }
  const n=numBold(String(i+1).padStart(2,'0'));
  const itemTitle=String(x[1]||'').trim();
  const desc=String(x[2]||'').trim();
  out.push(`║ ${n}  *${itemTitle}*`);
  if(desc){
   const parts=desc.split(',').map(p=>p.trim()).filter(Boolean);
   for(const p of parts)out.push(`║     ↳ ${smallCaps(p)}`);
  }
 });
 out.push('');
 out.push(`╔─ ❖➤ ${boldCaps('Navigation')} ➥`);
 out.push(`║ Reply with *${numBold('1-'+String(items.length))}* to select a service.`);
 out.push('║ ↩️ Type *back* to return to the previous menu.');
 out.push(`║ ${normalizeText(footer||'MR DKxx')}`);
 return out.join('\n');
}
function buildUniversalGroupMenu(body,items,{footer='MR DKxx',stateKey,type='home',title='MENU'}={}){
 return buildPrettyMenu(body,items,{footer,stateKey,type,title});
}
async function sendUniversalGroupMenu(sock,jid,body,items,{footer='MR DKxx',stateKey,type='home',title='MENU'}={}){
 const text=buildPrettyMenu(body,items,{footer,stateKey,type,title});
 await sock.sendMessage(jid,{text});
 return true;
}
async function sendInteractive(sock,jid,body,items,{title='Select',footer='MR DKxx',quick=false,stateKeyArg=null,type='home'}={}){
 const stateKey=stateKeyArg||jid;
 const mapped=items.map((x,i)=>({number:String(i+1),id:String(x[0])}));
 fallbackMenus.set(stateKey,mapped);
 // UNIVERSAL MENU TRANSPORT: plain text only for client compatibility.
 // This deliberately avoids native-flow/list/button payloads that can render
 // as "message not supported" on older or incompatible WhatsApp clients.
 const text=buildPrettyMenu(body,items,{footer,stateKey,type,title});
 await sock.sendMessage(jid,{text});
 return true;
}

async function sendLogo(sock,jid){
 try{
  if(!fs.existsSync(LOGO)) return false;
  await sock.sendMessage(jid,{image:fs.readFileSync(LOGO),caption:`✨ MR DKxx\n${t(jid,'welcome')}\n\n${t(jid,'choose')}`});
  return true;
 }catch(e){logger.warn({err:e.message},'Logo send failed');return false}
}
function homeItems(j){return [
 ['ai',t(j,'ai'),'Gemini, local AI, web search, vision and smart text tools'],['media',t(j,'media'),'Video, audio, media info and sticker tools'],['music',t(j,'music'),'MP3/audio downloads'],['image',t(j,'image'),'Generate images and image prompts'],['tools',t(j,'tools'),'QR, calculator, URL, OCR, STT, conversions and health'],['group',t(j,'group'),'Group tools and admin utilities'],['downloads',t(j,'downloads'),'Download from public/authorized URLs'],['extra',t(j,'extra'),'Bill splitter, countdown, giveaway picker, notes, public holidays, group invite link'],['security',t(j,'security'),'WHOIS, DNS, SSL, security headers, breach & password checks — defensive/informational only'],['settings',t(j,'settings'),'Language and bot settings'],['help',t(j,'help'),'Help and supported features'],['owner',t(j,'ownerMenu'),'Owner/admin tools']
]}
function geminiItems(j){
 const list=geminiModels();
 return [
  ['gemini_auto','✨ Gemini Auto','Tries the configured Gemini models silently in order'],
  ...list.map((x)=>[x.id,`🧠 ${x.name}`,'Chat with this Gemini model; silent failover to the next one']),
  ['back',t(j,'back')]
 ];
}
function subItems(j,type){const M={
 ai:[['gemini',t(j,'gemini')],['chat',t(j,'chat')],['local',t(j,'local')],['aistatus',t(j,'aistatus')],['websearch',t(j,'websearch')],['vision',t(j,'vision')],['summarize',t(j,'summarize')],['translate',t(j,'translate')],['analyze',t(j,'analyze')],['grammar',t(j,'grammar')],['coding',t(j,'coding')],['caption',t(j,'caption')],['hashtags',t(j,'hashtags')],['rewrite',t(j,'rewrite')],['imageai',t(j,'imageai')],['back',t(j,'back')]],
 media:[['video',t(j,'video')],['audio',t(j,'audio')],['info',t(j,'info')],['compress_video',t(j,'compressVideo')],['audio_convert',t(j,'audioConvert')],['thumbnail',t(j,'thumbnail')],['gif',t(j,'gif')],['sticker',t(j,'sticker')],['sticker2img',t(j,'sticker2img')],['back',t(j,'back')]],
 music:[['audio',t(j,'audio')],['info',t(j,'info')],['back',t(j,'back')]],
 image:[['imageGen',t(j,'imageGen')],['imageModels',t(j,'imageModels')],['imageStatus',t(j,'imageStatus')],['imageai',t(j,'imageai')],['back',t(j,'back')]],
 tools:[['qr',t(j,'qr')],['calc',t(j,'calc')],['url',t(j,'url')],['shorten',t(j,'shorten')],['wordcount',t(j,'wordcount')],['textcase',t(j,'textcase')],['morse','🔤 Morse Code'],['roman','🏛️ Roman Numerals'],['tts',t(j,'tts')],['ocr',t(j,'ocr')],['stt',t(j,'stt')],['unit',t(j,'unit')],['timestamp',t(j,'timestamp')],['currency',t(j,'currency')],['bmi',t(j,'bmi')],['age',t(j,'age')],['weather',t(j,'weather')],['news',t(j,'news')],['prayer',t(j,'prayer')],['ipLookup',t(j,'ipLookup')],['reminder',t(j,'reminder')],['wiki','🔍 Wikipedia'],['dict','📖 Dictionary'],['github','🐙 GitHub Info'],['country','🌍 Country Info'],['onthisday','📅 On This Day'],['color','🎨 Colour Info'],['uuid',t(j,'uuid')],['password',t(j,'password')],['hash',t(j,'hash')],['base64',t(j,'base64')],['json',t(j,'json')],['encrypt','🔒 Encrypt Text'],['decrypt','🔓 Decrypt Text'],['random',t(j,'random')],['myid',t(j,'myid')],['health',t(j,'health')],['status',t(j,'status')],['joke',t(j,'joke')],['quote',t(j,'quote')],['eightball',t(j,'eightball')],['dice',t(j,'dice')],['coinflip',t(j,'coinflip')],['dogpic',t(j,'dogpic')],['catpic',t(j,'catpic')],['advice',t(j,'advice')],['trivia',t(j,'trivia')],['numberfact',t(j,'numberfact')],['chucknorris',t(j,'chucknorris')],['fakeperson','🪪 Fake Person'],['back',t(j,'back')]],
 group:[['rules',t(j,'rules')],['setrules','📝 Set Rules'],['admins',t(j,'admins')],['groupStats',t(j,'groupStats')],['warnings',t(j,'warnings')],['tagall',t(j,'tagall')],['moderation',t(j,'moderation')],['poll',t(j,'poll')],['welcome',t(j,'welcomeToggle')],['back',t(j,'back')]],
 settings:[['language',t(j,'language')],['clear',t(j,'clear')],['status',t(j,'status')],['back',t(j,'back')]],
 owner:[['stats',t(j,'stats')],['backup',t(j,'backup')],['health',t(j,'health')],['back',t(j,'back')]],
 security:[['whois',t(j,'whois')],['dnslookup',t(j,'dnslookup')],['sslcheck',t(j,'sslcheck')],['headers',t(j,'headers')],['pwnedpw',t(j,'pwnedpw')],['pwstrength',t(j,'pwstrength')],['back',t(j,'back')]],
 extra:[['percent',t(j,'percent')],['countdown',t(j,'countdown')],['splitbill',t(j,'splitbill')],['picker',t(j,'picker')],['holidays',t(j,'holidays')],['notes',t(j,'notes')],['groupinvite',t(j,'groupinvite')],['timezone',t(j,'timezone')],['cryptoprice',t(j,'cryptoprice')],['emi',t(j,'emi')],['vcard',t(j,'vcard')],['distance',t(j,'distance')],['totp',t(j,'totp')],['fancytext',t(j,'fancytext')],['thesaurus',t(j,'thesaurus')],['singlish',t(j,'singlish')],['back',t(j,'back')]]
};return M[type]||[]}
async function home(sock,j,m){
 if(!logoSent.has(j)){if(await sendLogo(sock,j))logoSent.add(j)}
 return sendInteractive(sock,j,`✨ MR DKxx\n\n${t(j,'choose')}`,homeItems(j),{title:'MAIN MENU',footer:'Mr DKxx • Main Menu',stateKeyArg:sessionKey(j,m),type:'home'});
}
async function submenu(sock,j,type,m){return sendInteractive(sock,j,`✨ MR DKxx\n\n${t(j,type)}`,subItems(j,type),{title:`${type} menu`,footer:'Mr DKxx • Menu',stateKeyArg:sessionKey(j,m),type})}
async function geminiMenu(sock,j,m){return sendInteractive(sock,j,`✨ Gemini\n\n${t(j,'geminiChoose')}`,geminiItems(j),{title:'GEMINI MODELS',footer:'MR DKxx • Silent failover',stateKeyArg:sessionKey(j,m),type:'ai'})}
function imageModelNames(){return imageModels()}
function imageItems(j){return [...imageChoices().map(x=>[x.id,x.label,x.provider==='auto'?'Tries configured image providers silently':`Generate with ${x.provider}; safe failover is enabled`]),['back',t(j,'back')]]}
async function imageMenu(sock,j,m){return sendInteractive(sock,j,`🎨 Image AI\n\n${t(j,'imageChoose')}`,imageItems(j),{title:'IMAGE MODELS',footer:'MR DKxx • Silent failover',stateKeyArg:sessionKey(j,m),type:'image'})}
async function languageMenu(sock,j,m){return sendInteractive(sock,j,t(j,'chooseLang'),[['si',t(j,'si')],['en',t(j,'en')]],{title:'LANGUAGE',quick:true,stateKeyArg:sessionKey(j,m),type:'settings'})}
async function sendText(sock,j,text){return sock.sendMessage(j,{text:normalizeText(String(text))})}
async function prompt(sock,j,mode,kind,m){sessions.set(sessionKey(j,m),{mode,kind});if(mode==='vision')return sendText(sock,j,'🖼️ Please send an image now. You can add a question/caption.');if(mode==='ocr')return sendText(sock,j,'🖼️ Please send an image or document now.');if(mode==='stt')return sendText(sock,j,'🎙️ Please send a voice/audio message now.');if(mode==='mediaTool')return sendText(sock,j,'📎 Please send the media file now.');if(mode==='currency')return sendText(sock,j,'💱 Send: amount FROM TO\nExample: 100 USD LKR');if(mode==='bmi')return sendText(sock,j,'🩺 Send: weight(kg) height(cm)\nExample: 70 175');if(mode==='age')return sendText(sock,j,'🎂 Send your date of birth.\nExample: 1998-05-20');if(mode==='ipLookup')return sendText(sock,j,'🌐 Send an IP address or domain (or just send "." to look up this server\'s own IP).');if(mode==='weather')return sendText(sock,j,'🌦️ Send a city name.\nExample: Colombo');if(mode==='news')return sendText(sock,j,'📰 Send a topic to search, or just send "." for general top headlines.');if(mode==='prayer')return sendText(sock,j,'🕌 Send: City, Country\nExample: Colombo, Sri Lanka');if(mode==='reminder')return sendText(sock,j,'⏰ Send: <number> m/h <message>\nExample: 30m Check the download folder');if(mode==='url')return sendText(sock,j,'🔗 Send a video/audio link — YouTube, etc.\n\n🔎 Or just type what you\'re looking for (no link needed) and I\'ll search YouTube and show you a pick-list.');if(mode==='eightball')return sendText(sock,j,'🎱 Ask your yes/no question now.');if(mode==='dice')return sendText(sock,j,'🎲 Send: <sides> <count> (both optional)\nExample: 20 2 — or just send anything to roll a default d6.');if(mode==='numberfact')return sendText(sock,j,'🔢 Send a number, or send anything else for a random number fact.');if(mode==='shorten')return sendText(sock,j,'✂️ Send the URL you want to shorten.');if(mode==='wordcount')return sendText(sock,j,'📝 Send the text you want counted.');if(mode==='textcase')return sendText(sock,j,'🔠 Send the text you want converted.');if(mode==='wiki')return sendText(sock,j,'🔍 Send a topic to search on Wikipedia.\nExample: Elon Musk');if(mode==='dict')return sendText(sock,j,'📖 Send an English word to look up.\nExample: ephemeral');if(mode==='github')return sendText(sock,j,'🐙 Send a GitHub username or user/repo.\nExamples: torvalds\n          facebook/react');if(mode==='country')return sendText(sock,j,'🌍 Send a country name.\nExample: Sri Lanka');if(mode==='morse')return sendText(sock,j,'🔤 Send text to encode, or Morse code (dots & dashes) to decode.\nEncode: Hello World\nDecode: .... . .-.. .-.. --- / .-- --- .-. .-.. -..');if(mode==='roman')return sendText(sock,j,'🏛️ Send a number (1–3999) to convert to Roman numerals, or Roman numerals to convert to a number.\nExample: 2024 → MMXXIV\nExample: XIV → 14');if(mode==='color')return sendText(sock,j,'🎨 Send a HEX colour code or colour name.\nExamples: #FF5733\n           crimson');if(mode==='encrypt')return sendText(sock,j,'🔒 Send your text and a passphrase separated by " | "\nExample: Hello World | mypassword123');if(mode==='decrypt')return sendText(sock,j,'🔓 Send the encrypted text and passphrase separated by " | "\nExample: <encrypted> | mypassword123');if(mode==='percent')return sendText(sock,j,'📊 Send a percentage question.\nExamples:\n20% of 500\n500 increase 20%\n500 decrease 15%\n50 is what percent of 200');if(mode==='countdown')return sendText(sock,j,'📅 Send a target date, optionally with a label.\nExample: 2026-12-31 New Year\nExample: 2026-04-13 Avurudu');if(mode==='splitbill')return sendText(sock,j,'🧾 Send: total_amount number_of_people [tip%]\nExample: 4500 4 10');if(mode==='picker')return sendText(sock,j,'🎯 Send a list of names/entries separated by commas or new lines. I will pick a random winner.\nExample: Amal, Kasun, Nimal, Saman');if(mode==='holidays')return sendText(sock,j,'📖 Send a 2-letter country code, optionally with a year.\nExample: LK 2026\nExample: US');if(mode==='notesAdd')return sendText(sock,j,'📝 Send the note text you want to save.');if(mode==='timezone')return sendText(sock,j,'🌍 Send: <time or "now"> <FromCity> to <ToCity>\nExample: 14:30 Colombo to London\nExample: now Colombo to Dubai');if(mode==='cryptoprice')return sendText(sock,j,'💰 Send a coin symbol or name.\nExample: btc\nExample: bitcoin');if(mode==='emi')return sendText(sock,j,'🏦 Send: principal annual_interest_rate years\nExample: 500000 12 5');if(mode==='vcard')return sendText(sock,j,'📇 Send: Name | Phone | Email | Company\n(Email and Company are optional)\nExample: Kasun Perera | +94771234567 | kasun@email.com | ABC Traders');if(mode==='distance')return sendText(sock,j,'📍 Send: lat1,lon1 lat2,lon2\nExample: 6.9271,79.8612 51.5074,-0.1278');if(mode==='totp')return sendText(sock,j,'🔐 Send your 2FA base32 secret key (the text shown under "can\'t scan the QR code" when setting up 2FA on an account). I\'ll generate the current 6-digit code.');if(mode==='fancytext')return sendText(sock,j,'🎨 Send some text and I\'ll style it a few different ways.\nExample: Mr DKxx');if(mode==='thesaurus')return sendText(sock,j,'📚 Send a single English word to find synonyms/antonyms for.\nExample: happy');if(mode==='singlish')return sendText(sock,j,'📝 Send Singlish (romanized Sinhala) text to convert to Sinhala script.\nTip: lowercase t/d/n = ත/ද/න (soft), CAPITAL T/D/N = ට/ඩ/ණ (hard) — e.g. "oyaTa" → ඔයට.\nThis is a phonetic converter, not a dictionary, so double-check important text.\nExample: mama gedara yanawa');if(mode==='whois')return sendText(sock,j,'🔎 Send a domain name to look up public registration info.\nExample: example.com');if(mode==='dnslookup')return sendText(sock,j,'🌐 Send: <domain> [record type]\nSupported types: A, AAAA, MX, TXT, NS, CNAME, SOA\nExample: example.com\nExample: example.com MX');if(mode==='sslcheck')return sendText(sock,j,'🔒 Send a domain name to check its SSL/TLS certificate (issuer + expiry).\nExample: example.com');if(mode==='headers')return sendText(sock,j,'🛡️ Send a URL to check which security headers it sends (HSTS, CSP, etc.) — informational only.\nExample: example.com');if(mode==='pwnedpw')return sendText(sock,j,'🕵️ Send a password to check if it has appeared in known data breaches (uses the privacy-preserving k-anonymity method — your full password/hash is never sent). Use a test password if you\'re unsure about pasting a real one into chat.');if(mode==='pwstrength')return sendText(sock,j,'💪 Send a password to analyze its strength (checked locally, not sent anywhere).');return sendText(sock,j,t(j,'sendPrompt'))}
async function sendDownloadMenu(sock,j,url,m){sessions.set(sessionKey(j,m),{mode:'download',url});return sendInteractive(sock,j,`🔗 ${url}\n\nChoose download type:`,[['video_best','🎬 Video • Best'],['video_small','📱 Video • 480p'],['video_medium','📺 Video • 720p'],['audio_mp3','🎵 Audio • MP3'],['back',t(j,'back')]],{title:'DOWNLOAD',footer:'Mr DKxx • Downloader',stateKeyArg:sessionKey(j,m),type:'downloads'})}
function unwrapMessage(message){
 let msg=message||{};
 // WhatsApp may wrap incoming messages in ephemeral/view-once containers.
 for(let i=0;i<6;i++){
  const next=msg.ephemeralMessage?.message||msg.viewOnceMessage?.message||msg.viewOnceMessageV2?.message||msg.documentWithCaptionMessage?.message||msg.editedMessage?.message;
  if(!next||next===msg)break;
  msg=next;
 }
 return msg;
}
function getIncomingText(m){
 const msg=unwrapMessage(m.message);
 return (msg.conversation||msg.extendedTextMessage?.text||msg.imageMessage?.caption||msg.videoMessage?.caption||msg.documentMessage?.caption||msg.interactiveMessage?.body?.text||msg.interactiveResponseMessage?.body?.text||'').trim();
}
function mediaKind(m){const msg=unwrapMessage(m?.message);if(msg?.imageMessage)return 'image';if(msg?.videoMessage)return 'video';if(msg?.audioMessage)return 'audio';if(msg?.documentMessage)return 'document';return null}
async function saveIncomingMedia(m){const kind=mediaKind(m);if(!kind)throw new Error('Please send an image, video, audio or document.');const msg=unwrapMessage(m.message)[`${kind}Message`];const stream=await downloadContentFromMessage(msg,kind);const mime=String(msg.mimetype||'').toLowerCase();const ext=mime.includes('png')?'.png':mime.includes('webp')?'.webp':mime.includes('jpeg')||mime.includes('jpg')?'.jpg':mime.includes('mp4')?'.mp4':mime.includes('pdf')?'.pdf':kind==='audio'?'.ogg':kind==='video'?'.mp4':kind==='image'?'.jpg':'';const input=path.join(require('./utils').tmpDir,`upload-${Date.now()}-${Math.random().toString(16).slice(2)}${ext}`);fs.mkdirSync(path.dirname(input),{recursive:true});const ws=fs.createWriteStream(input);for await(const chunk of stream)ws.write(chunk);await new Promise((resolve,reject)=>{ws.on('finish',resolve);ws.on('error',reject);ws.end()});return {kind,input,mime}}
function getChoice(m){
 const msg=unwrapMessage(m.message);
 const a=msg.buttonsResponseMessage?.selectedButtonId||msg.listResponseMessage?.singleSelectReply?.selectedRowId||msg.templateButtonReplyMessage?.selectedId;
 if(a)return String(a);
 const p=msg.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson;
 if(p){
  try{
   const j=typeof p==='string'?JSON.parse(p):p;
   return j?.id||j?.selected_id||j?.row_id||j?.selectedRowId||j?.selected_id?.id||j?.params?.id||null;
  }catch{}
 }
 return null;
}
function getFallbackChoice(key,text){const n=String(text||'').trim();if(!/^\d{1,2}$/.test(n))return null;return fallbackMenus.get(key)?.find(x=>x.number===n)?.id||null}
function parseDkPrefix(text){
 const raw=String(text||'').normalize('NFKC');
 const m=raw.match(/^\s*d[\s._-]*k(?:\s*[:,-]\s*|\s+|$)/iu);
 if(!m)return null;
 return raw.slice(m[0].length).trim();
}
function actorJid(m,j){return m?.key?.participant||j}
function duration(sec){sec=Number(sec||0);if(!sec)return '-';const h=Math.floor(sec/3600),m=Math.floor(sec%3600/60),s=Math.floor(sec%60);return h?`${h}h ${m}m ${s}s`:`${m}m ${s}s`}
async function requireGroupAdmin(sock,j,m){if(!isGroup(j)){await sendText(sock,j,t(j,'onlyGroup'));return false}const sender=m.key.participant||m.key.remoteJid;if(!await isAdmin(sock,j,sender)){await sendText(sock,j,t(j,'admin'));return false}return true}
async function react(sock,j,m,emoji){try{await sock.sendMessage(j,{react:{text:emoji,key:m.key}})}catch{}}
// Extension -> WhatsApp message-type map. A link that isn't a recognized video/audio
// site (a direct PDF/ZIP/image/APK/etc. link, downloaded via media.genericDownload's
// raw-bytes fallback) must NOT be forced into a video/audio message - WhatsApp will
// silently reject or corrupt it. Send it as whatever type actually matches its bytes.
function sendByExtension(sock,j,file,caption){
 const ext=path.extname(file).toLowerCase();
 const videoExt=new Set(['.mp4','.mov','.mkv','.webm','.avi','.3gp']);
 const audioExt=new Set(['.mp3','.m4a','.wav','.ogg','.opus','.flac','.aac']);
 const imageExt=new Set(['.jpg','.jpeg','.png','.webp']);
 if(videoExt.has(ext))return sock.sendMessage(j,{video:fs.readFileSync(file),mimetype:'video/mp4',fileName:path.basename(file),caption});
 if(audioExt.has(ext))return sock.sendMessage(j,{audio:fs.readFileSync(file),mimetype:ext==='.mp3'?'audio/mpeg':'audio/mp4',fileName:path.basename(file),caption});
 if(imageExt.has(ext))return sock.sendMessage(j,{image:fs.readFileSync(file),caption});
 if(ext==='.gif')return sock.sendMessage(j,{document:fs.readFileSync(file),mimetype:'image/gif',fileName:path.basename(file),caption});
 const mimeMap={'.pdf':'application/pdf','.zip':'application/zip','.apk':'application/vnd.android.package-archive','.txt':'text/plain','.json':'application/json'};
 return sock.sendMessage(j,{document:fs.readFileSync(file),mimetype:mimeMap[ext]||'application/octet-stream',fileName:path.basename(file),caption});
}
async function executeDownload(sock,j,s,choice,m){const kind=choice==='audio_mp3'?'audio':'video';const quality=choice==='video_small'?'small':choice==='video_medium'?'medium':'best';
 // Fail fast with a clear, actionable message if yt-dlp/ffmpeg aren't actually
 // installed/on PATH on this machine, instead of showing "Downloading..." and
 // then surfacing a cryptic low-level error a minute later. Skip this check
 // when the cobalt engine can handle the link on its own (it needs neither
 // binary), so those downloads still work even without yt-dlp/ffmpeg.
 const bins=media.detectCobaltService(s.url)?{ytdlp:true,ffmpeg:true}:await media.checkBinaries();
 if(!bins.ytdlp||!bins.ffmpeg){
  const missing=[!bins.ytdlp?'yt-dlp':null,!bins.ffmpeg?'ffmpeg':null].filter(Boolean).join(' & ');
  await react(sock,j,m,'\u274c');
  await sendText(sock,j,`\u26a0\ufe0f Download engine (${missing}) is not installed on this server, so nothing can be downloaded yet.\n\n\ud83d\udee0\ufe0f Install ${missing} and make sure it's on PATH, then restart the bot. See docs/SETUP.md.\n\n(\u0dc3\u0dd2\u0d82\u0dc4\u0dbd: \u0db6\u0dc0\u0dda\u0d9a \u0dc3\u0dd0\u0dbb\u0dca\u0dc0\u0dbb\u0dda \u0dc0\u0dd0\u0daf\u0d9c\u0dad\u0dca\u0dc0\u0d9a\u0dda\u0d9a\u0dca \u0daf\u0dcf\u0dbd\u0dcf \u0db6\u0dda\u0dc4\u0dda \u0daf\u0dd2\u0dc4\u0dcf \u0db6\u0d9c\u0dda \u0dc0\u0dd2\u0daf\u0dd2\u0dba\u0da7 \u0daf\u0dcf\u0dbd\u0dcf \u0db6\u0da7\u0dda \u0dbb\u0dca\u200d\u0dc3\u0dca\u0da7\u0dcf\u0dbb\u0dca\u0da7\u0dca \u0d9a\u0dbb\u0db1\u0dca\u0db1.)`);
  return;
 }
 await react(sock,j,m,'\u23f3');await sendText(sock,j,'\u23f3 Downloading...');let file=null;try{file=await queue.add(()=>media.download(s.url,kind,quality));const stat=fs.statSync(file);const max=Number(process.env.MAX_DOWNLOAD_MB||100)*1024*1024;if(stat.size>max)throw new Error(t(j,'fileTooLarge'));const caption=`\u2728 MR DKxx\n\ud83d\udcc1 ${path.basename(file)}`;await sendByExtension(sock,j,file,caption);db.usage(j,`download_${kind}`);await react(sock,j,m,'\u2705');sessions.delete(sessionKey(j,m))}catch(e){await react(sock,j,m,'\u274c');throw e}finally{media.cleanup(file)}}
async function runAi(sock,j,text,label='ai',provider='auto',geminiModel='',stateJid=j){
 const clean=String(text||'').trim().replace(/\s+/g,' ').toLowerCase();
 if(!clean)return null;
 const key=`${stateJid}|${provider}|${label}|${geminiModel}|${clean}`;
 const now=Date.now();
 const doneAt=recentAiResponses.get(key);
 if(inFlightInputs.has(key))return null;
 if(doneAt && now-doneAt<5000)return null;
 inFlightInputs.add(key);
 const previous=aiChains.get(stateJid)||Promise.resolve();
 const task=previous.catch(()=>{}).then(async()=>{
  aiBusyByJid.set(stateJid,{at:Date.now(),text:clean,key});
  try{
   try{await sock.sendPresenceUpdate('composing',j)}catch{}
   const r=await askAI(text,stateJid,{provider,geminiModel});
   recentAiResponses.set(key,Date.now());
   await sendText(sock,j,`✨ ${r.text}\n\n_${r.provider} • ${r.model}_`);
   db.usage(stateJid,label);
   return r;
  }catch(e){
   recentAiResponses.set(key,Date.now());
   logger.warn({err:e.message,provider,label},'AI request failed after provider failover');
   await sendText(sock,j,'⚠️ AI is temporarily unavailable. Please try again in a moment.').catch(()=>{});
   return null;
  }finally{
   try{await sock.sendPresenceUpdate('paused',j)}catch{}
   const currentBusy=aiBusyByJid.get(stateJid);
   if(currentBusy?.key===key)aiBusyByJid.delete(stateJid);
   inFlightInputs.delete(key);
   if(recentAiResponses.size>2000){
    const cutoff=Date.now()-10*60*1000;
    for(const [k,ts] of recentAiResponses)if(ts<cutoff)recentAiResponses.delete(k);
   }
  }
 });
 aiChains.set(stateJid,task);
 try{return await task}
 finally{if(aiChains.get(stateJid)===task)aiChains.delete(stateJid)}
}
async function handleChoice(sock,j,m,choice){
 const actor=actorJid(m,j);
 const sk=sessionKey(j,m);
 if(choice==='language')return languageMenu(sock,j,m);
 if(choice==='si'||choice==='en'){change(j,choice);fallbackMenus.delete(sk);await sendText(sock,j,t(j,'saved'));return home(sock,j,m)}
 if(choice==='home'||choice==='back'){db.setAiMode(actor,false);sessions.delete(sk);fallbackMenus.delete(sk);return home(sock,j,m)}
 if(['ai','media','music','image','tools','group','settings','owner','extra','security'].includes(choice))return submenu(sock,j,choice,m);
 if(choice==='help')return sendText(sock,j,t(j,'helpText'));
 if(choice==='clear'){clearHistory(actor);db.setAiMode(actor,false);sessions.delete(sk);return sendText(sock,j,t(j,'cleared'))}
 if(choice==='backup'){if(!isOwner(actor))return sendText(sock,j,t(j,'owner'));const out=db.backup();return sendText(sock,j,`💾 Database backup created:\n${out}`)}
 if(choice==='stats'){if(!isOwner(actor)){await sendText(sock,j,t(j,'owner'));return}const st=stats();return sendText(sock,j,`📊 MR DKxx Stats\n\n👤 Users: ${st.users}\n👥 Groups: ${st.groups}\n⚡ Actions: ${st.actions}`)}
 if(choice==='owner'){if(!isOwner(actor))return sendText(sock,j,t(j,'owner'));return submenu(sock,j,'owner',m);}
 if(choice==='myid')return sendText(sock,j,`🆔 Your WhatsApp ID:\n${actor}`);
 if(choice==='status')return sendText(sock,j,`${t(j,'statusText')}\n⏱️ Uptime: ${Math.floor((Date.now()-startedAt)/1000)}s\n📦 Queue: ${queue.size()}`);
 if(choice==='health')return sendText(sock,j,await healthText());
 if(choice==='gemini')return geminiMenu(sock,j,m);
 if(choice==='gemini_auto'){db.setAiMode(actor,true);sessions.set(sk,{mode:'ai',provider:'gemini',geminiModel:''});return sendText(sock,j,t(j,'aiOnGemini'))}
 const gm=geminiModels().find(x=>x.id===choice);
 if(gm){db.setAiMode(actor,true);sessions.set(sk,{mode:'ai',provider:'gemini',geminiModel:gm.name});return sendText(sock,j,`✨ Gemini • ${gm.name}\nSilent failover is enabled. Send your message now. Send back to exit.`)}
 if(choice==='chat'){db.setAiMode(actor,true);sessions.set(sk,{mode:'ai',provider:'auto'});return sendText(sock,j,t(j,'aiOn'))}
 if(choice==='local'){db.setAiMode(actor,true);sessions.set(sk,{mode:'ai',provider:'local'});return sendText(sock,j,t(j,'aiOnLocal'))}
 if(choice==='aistatus'){const rows=await providerStatus();return sendText(sock,j,`🧠 MR DKxx AI Status\n\n${rows.map(x=>`• ${x}`).join('\n')}\n\n🎨 Image AI\n${imageProviderStatus().map(x=>`• ${x}`).join('\n')}`)}
 if(choice==='websearch')return prompt(sock,j,'websearch','websearch',m);
 if(choice==='vision')return prompt(sock,j,'vision','vision',m);
 if(['summarize','translate','analyze','grammar','coding','caption','hashtags','rewrite','imageai'].includes(choice))return prompt(sock,j,'prompt',choice,m);
 if(choice==='imageGen')return imageMenu(sock,j,m);
 if(choice==='imageModels')return imageMenu(sock,j,m);
 if(choice==='imageStatus')return sendText(sock,j,`🩺 Image AI Status\n\n${imageProviderStatus().map(x=>`• ${x}`).join('\n')}`);
 // Match ANY valid image-provider choice id (was previously a hand-written regex
 // that missed the free Pollinations Flux/Turbo options — selecting those did
 // nothing at all because no branch matched them). Checking against the live
 // imageChoices() list means every current and future provider option works and
 // stays correct even if new providers are added to services/providers.js.
 if(imageChoices().some(x=>x.id===choice))return prompt(sock,j,'imageGen',choice,m)
 if(choice==='video'||choice==='audio')return prompt(sock,j,'url',choice,m);
 if(choice==='downloads')return prompt(sock,j,'url','video',m);
 if(choice==='info')return prompt(sock,j,'info','',m);
 if(choice==='sticker'){sessions.set(sk,{mode:'sticker'});return sendText(sock,j,t(j,'sendSticker'))}
 if(choice==='sticker2img'){sessions.set(sk,{mode:'sticker2img'});return sendText(sock,j,'🖼️ Send a WhatsApp sticker now to convert it back to a PNG image.')}
 if(['video_best','video_small','video_medium','audio_mp3'].includes(choice)){const s=sessions.get(sk);if(!s?.url){await sendText(sock,j,t(j,'expired'));return}return executeDownload(sock,j,s,choice,m)}
 if(choice==='joke'){try{return sendText(sock,j,`😂 ${await dadJoke()}`)}catch(e){return sendText(sock,j,`⚠️ ${safeText(e.message,300)}`)}}
 if(choice==='quote'){try{const q=await randomQuote();return sendText(sock,j,`💬 "${q.text}"\n— ${q.author}`)}catch(e){return sendText(sock,j,`⚠️ ${safeText(e.message,300)}`)}}
 if(choice==='coinflip')return sendText(sock,j,`🪙 ${coinFlip()}`);
 if(choice==='eightball')return prompt(sock,j,'eightball','',m);
 if(choice==='dice')return prompt(sock,j,'dice','',m);
 if(choice==='dogpic'){try{return sock.sendMessage(j,{image:{url:await randomDogImage()},caption:'🐶 Woof!'})}catch(e){return sendText(sock,j,`⚠️ ${safeText(e.message,300)}`)}}
 if(choice==='catpic'){try{return sock.sendMessage(j,{image:{url:await randomCatImage()},caption:'🐱 Meow!'})}catch(e){return sendText(sock,j,`⚠️ ${safeText(e.message,300)}`)}}
 if(choice==='advice'){try{return sendText(sock,j,`🧠 ${await advice()}`)}catch(e){return sendText(sock,j,`⚠️ ${safeText(e.message,300)}`)}}
 if(choice==='chucknorris'){try{return sendText(sock,j,`🥋 ${await chuckNorrisJoke()}`)}catch(e){return sendText(sock,j,`⚠️ ${safeText(e.message,300)}`)}}
 if(choice==='trivia'){try{const q=await trivia();const letters=['A','B','C','D'];return sendText(sock,j,`❓ ${q.category}\n\n${q.question}\n\n${q.options.map((o,i)=>`${letters[i]}) ${o}`).join('\n')}\n\n✅ Answer: ${q.answer}`)}catch(e){return sendText(sock,j,`⚠️ ${safeText(e.message,300)}`)}}
 if(choice==='numberfact')return prompt(sock,j,'numberfact','',m);
 if(choice==='shorten')return prompt(sock,j,'shorten','',m);
 if(choice==='wordcount')return prompt(sock,j,'wordcount','',m);
 if(choice==='textcase')return prompt(sock,j,'textcase','',m);
 if(choice==='qr')return prompt(sock,j,'qr','',m);
 if(choice==='calc')return prompt(sock,j,'calc','',m);
 if(choice==='url')return prompt(sock,j,'urlInfo','',m);
 if(choice==='tts')return prompt(sock,j,'tts','',m);
 if(choice==='ocr')return prompt(sock,j,'ocr','',m);
 if(choice==='stt')return prompt(sock,j,'stt','',m);
 if(choice==='unit')return prompt(sock,j,'unit','',m);
 if(choice==='timestamp')return prompt(sock,j,'timestamp','',m);
 if(choice==='currency')return prompt(sock,j,'currency','',m);
 if(choice==='bmi')return prompt(sock,j,'bmi','',m);
 if(choice==='age')return prompt(sock,j,'age','',m);
 if(choice==='ipLookup')return prompt(sock,j,'ipLookup','',m);
 if(choice==='weather')return prompt(sock,j,'weather','',m);
 if(choice==='news')return prompt(sock,j,'news','',m);
 if(choice==='prayer')return prompt(sock,j,'prayer','',m);
 if(choice==='reminder')return prompt(sock,j,'reminder','',m);
 if(choice==='uuid')return sendText(sock,j,`🆔 ${require('./services/tools').uuid()}`);
 if(choice==='fakeperson'){const fp=require('./services/tools').fakePerson();return sendText(sock,j,`🪪 Fake Person\n\n👤 ${fp.name}\n🚻 ${fp.gender}\n🎂 ${fp.dob}\n📧 ${fp.email}\n📞 ${fp.phone}\n🏙️ ${fp.city}`);}
 if(choice==='onthisday'){try{const x=await require('./services/tools').onThisDay();return sendText(sock,j,`📅 On This Day (${x.date})\n\n${x.events.map(e=>`• ${e.year}: ${e.text}`).join('\n\n')}`);}catch(e){return sendText(sock,j,`⚠️ ${e.message}`);}}
 if(choice==='password')return prompt(sock,j,'password','',m);
 if(choice==='hash')return prompt(sock,j,'hash','',m);
 if(choice==='base64')return prompt(sock,j,'base64','',m);
 if(choice==='json')return prompt(sock,j,'json','',m);
 if(choice==='random')return prompt(sock,j,'random','',m);
 if(choice==='wiki')return prompt(sock,j,'wiki','',m);
 if(choice==='dict')return prompt(sock,j,'dict','',m);
 if(choice==='github')return prompt(sock,j,'github','',m);
 if(choice==='country')return prompt(sock,j,'country','',m);
 if(choice==='morse')return prompt(sock,j,'morse','',m);
 if(choice==='roman')return prompt(sock,j,'roman','',m);
 if(choice==='color')return prompt(sock,j,'color','',m);
 if(choice==='encrypt')return prompt(sock,j,'encrypt','',m);
 if(choice==='decrypt')return prompt(sock,j,'decrypt','',m);
 if(choice==='compress_video')return prompt(sock,j,'mediaTool','compress_video',m);
 if(choice==='audio_convert')return prompt(sock,j,'mediaTool','audio_convert',m);
 if(choice==='thumbnail')return prompt(sock,j,'mediaTool','thumbnail',m);
 if(choice==='gif')return prompt(sock,j,'mediaTool','gif',m);
 if(choice==='setrules'){if(!await requireGroupAdmin(sock,j,m))return;sessions.set(sk,{mode:'setrules'});return sendText(sock,j,'📝 Send the new group rules text. Send back to cancel.')}
 if(choice==='poll'){if(!isGroup(j)){await sendText(sock,j,t(j,'onlyGroup'));return}sessions.set(sk,{mode:'poll'});return sendText(sock,j,'📊 Send your poll like this (first line = question, next lines = options, 2-12 options):\n\nWhat time works best?\n6 PM\n7 PM\n8 PM')}
 if(choice==='welcome'){if(!await requireGroupAdmin(sock,j,m))return;const on=!db.groupWelcome(j);db.setGroupWelcome(j,on);return sendText(sock,j,on?'👋 Welcome messages for new members: ON':'👋 Welcome messages for new members: OFF')}
 if(['rules','admins','groupStats','warnings','tagall','moderation'].includes(choice)){
  if(!isGroup(j)){await sendText(sock,j,t(j,'onlyGroup'));return}
  const meta=await sock.groupMetadata(j);
  if(choice==='rules')return sendText(sock,j,`📜 ${t(j,'rules')}\n\n${db.groupRules(j)||'No rules configured.'}`);
  if(choice==='admins')return sendText(sock,j,'🛡️ Admins\n\n'+meta.participants.filter(p=>p.admin).map(p=>`• ${p.id}`).join('\n'));
  if(choice==='groupStats')return sendText(sock,j,`📊 ${meta.subject}\n👥 Members: ${meta.participants.length}`);
  if(choice==='warnings'){const sender=m.key.participant||j;return sendText(sock,j,`⚠️ Your warnings in this group: ${db.warnCount(j,sender)}\n\nAdmin warning records are stored locally. Use an admin command to add a warning.`)}
  if(choice==='tagall'){if(!await requireGroupAdmin(sock,j,m))return;const mentions=meta.participants.map(p=>p.id);return sock.sendMessage(j,{text:mentions.map(x=>`@${x.split('@')[0]}`).join(' '),mentions})}
  if(choice==='moderation'){if(!await requireGroupAdmin(sock,j,m))return;return sendText(sock,j,'🛡️ Moderation Panel\n\n• Tag all: available\n• Rules: available\n• Warning storage: available\n• Automatic kicks/bans: disabled by default for safety.')}
 }
 // ---- Extra Tools (V4.13) — free, no-key, additive main-menu category ----
 if(choice==='percent')return prompt(sock,j,'percent','',m);
 if(choice==='countdown')return prompt(sock,j,'countdown','',m);
 if(choice==='splitbill')return prompt(sock,j,'splitbill','',m);
 if(choice==='picker')return prompt(sock,j,'picker','',m);
 if(choice==='holidays')return prompt(sock,j,'holidays','',m);
 if(choice==='notes')return sendInteractive(sock,j,'📝 My Notes\n\nSave quick personal notes/reminders. Only you can see your own notes.',[['notes_add','📝 Add Note'],['notes_list','📋 List My Notes'],['notes_clear','🗑️ Clear All Notes'],['back',t(j,'back')]],{title:'NOTES',footer:'Mr DKxx • Notes',stateKeyArg:sk,type:'extra'});
 if(choice==='notes_add')return prompt(sock,j,'notesAdd','',m);
 if(choice==='notes_list'){const rows=db.noteList(actor);if(!rows.length)return sendText(sock,j,'📋 You have no saved notes yet.');return sendText(sock,j,`📋 Your Notes\n\n${rows.map((n,i)=>`${i+1}. ${n.text}`).join('\n')}`)}
 if(choice==='notes_clear'){db.noteClear(actor);return sendText(sock,j,'🗑️ All your notes were cleared.')}
 if(choice==='groupinvite'){if(!await requireGroupAdmin(sock,j,m))return;try{const code=await sock.groupInviteCode(j);return sendText(sock,j,`🔗 Group Invite Link\n\nhttps://chat.whatsapp.com/${code}`)}catch(e){return sendText(sock,j,`⚠️ ${safeText(e.message,300)}`)}}
 // ---- More Power Tools (V4.15) — free, no-key, additive to Extra Tools ----
 if(choice==='timezone')return prompt(sock,j,'timezone','',m);
 if(choice==='cryptoprice')return prompt(sock,j,'cryptoprice','',m);
 if(choice==='emi')return prompt(sock,j,'emi','',m);
 if(choice==='vcard')return prompt(sock,j,'vcard','',m);
 if(choice==='distance')return prompt(sock,j,'distance','',m);
 if(choice==='totp')return prompt(sock,j,'totp','',m);
 if(choice==='fancytext')return prompt(sock,j,'fancytext','',m);
 if(choice==='thesaurus')return prompt(sock,j,'thesaurus','',m);
 if(choice==='singlish')return prompt(sock,j,'singlish','',m);
 // ---- Security & OSINT Tools (V4.16) — defensive/informational checks only ----
 if(choice==='whois')return prompt(sock,j,'whois','',m);
 if(choice==='dnslookup')return prompt(sock,j,'dnslookup','',m);
 if(choice==='sslcheck')return prompt(sock,j,'sslcheck','',m);
 if(choice==='headers')return prompt(sock,j,'headers','',m);
 if(choice==='pwnedpw')return prompt(sock,j,'pwnedpw','',m);
 if(choice==='pwstrength')return prompt(sock,j,'pwstrength','',m);
}
async function healthText(){
 const checks=[];for(const [name,bin,args] of [['Node','node',['--version']],['yt-dlp',process.env.YT_DLP_PATH||'yt-dlp',['--version']],['FFmpeg',process.env.FFMPEG_PATH||'ffmpeg',['-version']]]){try{const r=await media.run(bin,args,15000);checks.push(`✅ ${name}: ${(r.out||r.err).split(/\r?\n/)[0].slice(0,100)}`)}catch(e){checks.push(`❌ ${name}: ${e.message}`)}}
 try{const c=await media.checkCobaltReachable();checks.push(`${c.ok?'✅':'❌'} Cobalt directory: ${c.detail}`)}catch(e){checks.push(`❌ Cobalt directory: ${e.message}`)}
 checks.push(process.env.GEMINI_API_KEY?.trim()?`✅ Gemini API key: configured (${(process.env.GEMINI_MODELS||'').split(',').filter(Boolean).length||1} model(s))`:'⚠️ Gemini API key: not configured');checks.push(`🗃️ Database: ${db.stats? 'SQLite module loaded':'unknown'}`);return `🩺 MR DKxx System Check\n\n${checks.join('\n')}`}
async function startBot(){
 fs.mkdirSync(AUTH_DIR,{recursive:true});
 const {state,saveCreds}=await useMultiFileAuthState(AUTH_DIR);
 const sock=makeWASocket({auth:state,logger:P({level:'silent'}),browser:['Mr DKxx','Windows','3.0'],markOnlineOnConnect:false});
 sock.ev.on('creds.update',saveCreds);
 sock.ev.on('connection.update',({connection,lastDisconnect,qr:code})=>{
  if(code){console.log('\n=== MR DKxx QR ===\nScan with WhatsApp > Linked devices\n');qrcode.generate(code,{small:true})}
  if(connection==='open'){if(reconnectTimer){clearTimeout(reconnectTimer);reconnectTimer=null}logger.info('MR DKxx connected')}
  if(connection==='close'){
   const c=lastDisconnect?.error?.output?.statusCode;
   if(c===DisconnectReason.loggedOut){logger.error('WhatsApp session logged out; delete auth/mrdkxx and pair again.');return}
   if(!reconnectTimer){reconnectTimer=setTimeout(()=>{reconnectTimer=null;startBot().catch(e=>logger.error({err:e.message},'Reconnect failed'))},5000)}
  }
 });
 sock.ev.on('group-participants.update',async({id,participants,action})=>{
  try{
   if(action!=='add'||!db.groupWelcome(id))return;
   for(const p of participants||[]){
    await sock.sendMessage(id,{text:`👋 Welcome @${String(p).split('@')[0]} to the group!\n\n✨ MR DKxx bot is here — send *menu* to see what I can help with.`,mentions:[p]});
   }
  }catch(e){logger.warn({err:e.message},'welcome message failed')}
 });
 sock.ev.on('messages.upsert',async({messages,type})=>{
  if(type && type!=='notify') return;
  for(const m of messages||[]){
   if(!m||m.key.fromMe||!m.message)continue;
   const now=Date.now();
   const messageId=m.key.id;
   if(messageId){const seenAt=seenMessages.get(messageId);if(seenAt && now-seenAt<10*60*1000)continue;seenMessages.set(messageId,now);if(seenMessages.size>2000){for(const [id,ts] of seenMessages){if(now-ts>10*60*1000)seenMessages.delete(id)}}}
   const j=m.key.remoteJid;if(!j)continue;const text=getIncomingText(m);
   const normalizedIncoming=text.trim().replace(/\s+/g,' ').toLowerCase();
   const fingerprint=`${j}|${actorJid(m,j)}|${normalizedIncoming}`;
   const recentAt=recentInputs.get(fingerprint);
   if(recentAt && now-recentAt<6000)continue;
   recentInputs.set(fingerprint,now);
   if(recentInputs.size>2000){for(const [key,ts] of recentInputs){if(now-ts>10*60*1000)recentInputs.delete(key)}}
   const name=m.pushName||'User';db.ensureUser(j,name);
   const actor=actorJid(m,j);db.ensureUser(actor,name);
   if(isGroup(j))db.groupEnsure(j);
   const sk=sessionKey(j,m);
   const normalized=String(text||'').normalize('NFKC').trim().toLowerCase().replace(/\s+/g,' ');
   const dkPayload=parseDkPrefix(text);
   // A stale fallbackMenus entry from a PREVIOUS numbered menu (e.g. the media
   // submenu) must never be allowed to hijack a plain numeric reply that belongs to
   // the CURRENT session's own numbered list (e.g. picking 1-5 from YouTube search
   // results, which is sent as plain text, not a fallbackMenus-backed menu). Session
   // modes that interpret a bare number themselves are excluded from fallback-menu
   // resolution so their own handler further down gets first chance at it.
   const rawTextModes=new Set(['urlsearch']);
   const sessionPeek=sessions.get(sk);
   const choice=rawTextModes.has(sessionPeek?.mode)?null:(getChoice(m)||getFallbackChoice(sk,text));
   try{
    // Owner-only global pause/resume. Paused mode ignores all normal messages.
    if((normalized==='stop'||normalized==='/stop') && isOwner(actor)){
      botPaused=true; db.setAiMode(j,false); sessions.clear(); fallbackMenus.clear();
      await sendText(sock,j,'⏹️ MR DKxx bot paused. Owner can send start/resume to enable it again.');
      continue;
    }
    if((normalized==='start'||normalized==='resume'||normalized==='/start'||normalized==='/resume') && isOwner(actor)){
      botPaused=false; await sendText(sock,j,'▶️ MR DKxx bot resumed.'); continue;
    }
    if(botPaused) continue;
    // BUGFIX: a numbered menu's fallback mapping (e.g. "1" -> image_auto) was never
    // cleared once the user picked an option and moved into a mode that expects free
    // text (like "send the image description now"). If that free-text reply happened
    // to be a bare 1-2 digit number — or the user re-tapped/re-sent the same digit —
    // it was silently reinterpreted as the OLD menu choice again instead of being
    // passed through as the actual answer, re-showing "send your text now" and then
    // generating an image from an empty/stale prompt. Clearing the stale mapping the
    // moment a choice is actually acted on stops it from shadowing anything sent
    // afterward; any handler that shows a NEW menu repopulates it immediately anyway.
    if(choice){fallbackMenus.delete(sk);await handleChoice(sock,j,m,choice);continue}
    if(normalized==='menu'||normalized==='/menu'||normalized==='home'||normalized==='/home'||normalized==='/start'||normalized==='dk'){await home(sock,j,m);continue}
    if(normalized==='dk menu'||normalized==='dk home'){await home(sock,j,m);continue}
    if(normalized==='back'){db.setAiMode(actor,false);sessions.delete(sk);fallbackMenus.delete(sk);await home(sock,j,m);continue}
    if(normalized==='/help'||normalized==='help'){await sendText(sock,j,t(j,'helpText'));continue}
    if(normalized==='/status'){await handleChoice(sock,j,m,'status');continue}
    if(normalized==='/ping'||normalized==='ping'){await sendText(sock,j,'🏓 Pong! MR DKxx is online.');continue}
    if(normalized==='/id'||normalized==='id'){await handleChoice(sock,j,m,'myid');continue}
    if(normalized==='/clear'||normalized==='clear'){await handleChoice(sock,j,m,'clear');continue}
    if(normalized==='/features'||normalized==='features'){await sendText(sock,j,t(j,'helpText'));continue}
    if(normalized==='/health'){await handleChoice(sock,j,m,'health');continue}
    if(normalized==='/aistatus'||normalized==='aistatus'){const rows=await providerStatus();await sendText(sock,j,`🧠 MR DKxx AI Status\n\n${rows.map(x=>`• ${x}`).join('\n')}\n\n🎨 Image AI\n${imageProviderStatus().map(x=>`• ${x}`).join('\n')}`);continue}
    // AI chat requires the explicit DK prefix. It is case/spacing tolerant (DK, dk, D K, d-k, etc.).
    if(dkPayload!==null){
      const dkCommand=dkPayload.toLowerCase().replace(/\s+/g,' ').trim();
      if(!dkCommand||dkCommand==='menu'||dkCommand==='home'){await home(sock,j,m);continue}
      const s0=sessions.get(sk);
      const aiProvider=s0?.provider||'auto';
      const aiModel=s0?.geminiModel||'';
      await runAi(sock,j,dkPayload,'ai',aiProvider,aiModel,actor);
      continue;
    }
    const s=sessions.get(sk);
    const incomingMsg=unwrapMessage(m.message);
    if(s?.mode==='sticker' && (incomingMsg.imageMessage||incomingMsg.videoMessage)){
      let input=null,output=null;try{const type=incomingMsg.imageMessage?'image':'video';const stream=await downloadContentFromMessage(incomingMsg[type+'Message'],type);input=path.join(process.env.TMP_DIR||path.join(require('./utils').tmpDir,'uploads'),`in-${Date.now()}`);fs.mkdirSync(path.dirname(input),{recursive:true});const ws=fs.createWriteStream(input);for await(const chunk of stream)ws.write(chunk);await new Promise(r=>ws.end(r));output=type==='image'?await sticker.imageToSticker(input):await sticker.videoToSticker(input);await sock.sendMessage(j,{sticker:fs.readFileSync(output)});db.usage(j,'sticker');}catch(e){await sendText(sock,j,`⚠️ ${safeText(e.message,600)}`)}finally{sticker.cleanup(input);sticker.cleanup(output);sessions.delete(sk)}continue}
    if(s?.mode==='sticker2img' && incomingMsg.stickerMessage){
      let input=null,output=null;try{const stream=await downloadContentFromMessage(incomingMsg.stickerMessage,'sticker');input=path.join(process.env.TMP_DIR||path.join(require('./utils').tmpDir,'uploads'),`in-${Date.now()}.webp`);fs.mkdirSync(path.dirname(input),{recursive:true});const ws=fs.createWriteStream(input);for await(const chunk of stream)ws.write(chunk);await new Promise(r=>ws.end(r));output=await sticker.stickerToImage(input);await sock.sendMessage(j,{image:fs.readFileSync(output),caption:'✨ MR DKxx • Sticker → Image'});db.usage(j,'sticker2img');}catch(e){await sendText(sock,j,`⚠️ ${safeText(e.message,600)}`)}finally{sticker.cleanup(input);sticker.cleanup(output);sessions.delete(sk)}continue}
    if(s?.mode==='ai'){continue}
    if(s?.mode==='setrules'){if(!isGroup(j)){sessions.delete(sk);await sendText(sock,j,t(j,'onlyGroup'));continue}try{const sender=m.key.participant||j;if(!await isAdmin(sock,j,sender)){await sendText(sock,j,t(j,'admin'));sessions.delete(sk);continue}db.setGroupRules(j,text.slice(0,4000));await sendText(sock,j,'✅ Group rules updated.')}catch(e){await sendText(sock,j,`⚠️ ${safeText(e.message,500)}`)}sessions.delete(sk);continue}
    if(s?.mode==='url'){
      if(isSafeUrl(text)){await sendDownloadMenu(sock,j,text,m);continue}
      // Not a link — treat it as a YouTube search query instead of just erroring.
      try{
        await sendText(sock,j,'🔎 Searching YouTube...');
        const results=await media.searchYoutube(text,5);
        sessions.set(sk,{mode:'urlsearch',results});
        fallbackMenus.delete(sk); // stop any older numbered menu from shadowing these picks
        const list=results.map((r,i)=>`${i+1}. 🎬 *${r.title}*\n     👤 ${r.uploader||'-'} • ⏱️ ${duration(r.duration)}`).join('\n\n');
        await sendText(sock,j,`🔎 YouTube Results • "${text}"\n\n${list}\n\n💬 Reply with a number (1-${results.length}) to pick one, or paste a direct link.`);
      }catch(e){await sendText(sock,j,`⚠️ ${safeText(e.message,600)}`)}
      continue;
    }
    if(s?.mode==='urlsearch'){
      const n=Number(text.trim());
      if(Number.isInteger(n)&&s.results&&n>=1&&n<=s.results.length){await sendDownloadMenu(sock,j,s.results[n-1].url,m);continue}
      if(isSafeUrl(text)){await sendDownloadMenu(sock,j,text,m);continue}
      await sendText(sock,j,`⚠️ Reply with a number (1-${s.results?.length||5}) or a valid link.`);continue;
    }
    if(s?.mode==='info'){if(!isSafeUrl(text)){await sendText(sock,j,'⚠️ Please send a valid URL.');continue}await sendText(sock,j,'🔎 Reading media info...');try{const x=await media.info(text);await sendText(sock,j,`🔎 ${x.title}\n👤 ${x.uploader||'-'}\n⏱️ ${duration(x.duration)}\n🔗 ${x.url}`)}catch(e){await sendText(sock,j,`⚠️ ${e.message}`)}sessions.delete(sk);continue}
    if(s?.mode==='urlInfo'){if(!isSafeUrl(text)){await sendText(sock,j,'⚠️ Please send a valid URL.');continue}try{const x=await require('./services/tools').urlInfo(text);await sendText(sock,j,`🔗 URL Info\n\n🌐 ${x.finalUrl}\n📌 ${x.title}\n📡 ${x.status} ${x.statusText}\n📦 ${x.contentType||'-'}\n📏 ${x.contentLength||'-'}`)}catch(e){await sendText(sock,j,`⚠️ URL info failed: ${safeText(e.message,500)}`)}sessions.delete(sk);continue}
    if(s?.mode==='eightball'){try{await sendText(sock,j,`🎱 ${magic8ball()}`)}catch(e){await sendText(sock,j,`⚠️ ${safeText(e.message,300)}`)}sessions.delete(sk);continue}
    if(s?.mode==='dice'){try{const parts=text.trim().split(/\s+/).filter(Boolean);const sides=/^\d+$/.test(parts[0])?Number(parts[0]):6;const count=/^\d+$/.test(parts[1])?Number(parts[1]):1;const r=rollDice(sides,count);await sendText(sock,j,`🎲 d${r.sides} x${r.rolls.length}: ${r.rolls.join(', ')} (total ${r.total})`)}catch(e){await sendText(sock,j,`⚠️ ${safeText(e.message,300)}`)}sessions.delete(sk);continue}
    if(s?.mode==='numberfact'){try{await sendText(sock,j,`🔢 ${await numberFact(text)}`)}catch(e){await sendText(sock,j,`⚠️ ${safeText(e.message,300)}`)}sessions.delete(sk);continue}
    if(s?.mode==='shorten'){try{await sendText(sock,j,`✂️ ${await shortenUrl(text)}`)}catch(e){await sendText(sock,j,`⚠️ ${safeText(e.message,300)}`)}sessions.delete(sk);continue}
    if(s?.mode==='wordcount'){try{const c=wordCount(text);await sendText(sock,j,`📝 Words: ${c.words}\n🔤 Characters: ${c.chars} (${c.charsNoSpaces} without spaces)\n📄 Sentences: ${c.sentences}`)}catch(e){await sendText(sock,j,`⚠️ ${safeText(e.message,300)}`)}sessions.delete(sk);continue}
    if(s?.mode==='textcase'){try{const c=textCase(text);await sendText(sock,j,`🔠 UPPER: ${c.upper}\n\n🔡 lower: ${c.lower}\n\n🔤 Title Case: ${c.title}\n\n🔡 Sentence case: ${c.sentence}`)}catch(e){await sendText(sock,j,`⚠️ ${safeText(e.message,300)}`)}sessions.delete(sk);continue}
    if(s?.mode==='wiki'){try{const x=await wikiSearch(text);await sendText(sock,j,`🔍 *${x.title}*\n\n${x.extract}${x.url?'\n\n🔗 '+x.url:''}`)}catch(e){await sendText(sock,j,`⚠️ ${safeText(e.message,400)}`)}sessions.delete(sk);continue}
    if(s?.mode==='dict'){try{const x=await dictionary(text);const body=x.meanings.map(m=>`*${m.partOfSpeech}*\n${m.definitions.map((d,i)=>`${i+1}. ${d}`).join('\n')}${m.synonyms.length?'\nSynonyms: '+m.synonyms.join(', '):''}`).join('\n\n');await sendText(sock,j,`📖 *${x.word}* ${x.phonetic?`(${x.phonetic})`:''}\n\n${body}`)}catch(e){await sendText(sock,j,`⚠️ ${safeText(e.message,400)}`)}sessions.delete(sk);continue}
    if(s?.mode==='github'){try{const x=await githubInfo(text.trim());if(x.type==='repo'){await sendText(sock,j,`🐙 *${x.name}*\n${x.description||''}\n\n⭐ Stars: ${x.stars}\n🍴 Forks: ${x.forks}\n💻 Language: ${x.language}\n🏷️ Topics: ${x.topics.join(', ')||'-'}\n🔗 ${x.url}\n📅 Updated: ${x.updated}`)}else{await sendText(sock,j,`🐙 *${x.login}*${x.name?` (${x.name})`:''}\n${x.bio||''}\n\n📦 Repos: ${x.repos}\n👥 Followers: ${x.followers} | Following: ${x.following}\n🔗 ${x.url}\n📅 Joined: ${x.joined}`)}}catch(e){await sendText(sock,j,`⚠️ ${safeText(e.message,400)}`)}sessions.delete(sk);continue}
    if(s?.mode==='country'){try{const x=await countryInfo(text);await sendText(sock,j,`🌍 *${x.flag} ${x.name}*\n📋 ${x.official}\n\n🏙️ Capital: ${x.capital}\n🌎 Region: ${x.subregion}, ${x.region}\n👥 Population: ${x.population.toLocaleString()}\n📐 Area: ${(x.area||0).toLocaleString()} km²\n💰 Currency: ${x.currencies||'-'}\n🗣️ Languages: ${x.languages||'-'}\n🕐 Timezone: ${x.timezone}\n🌐 TLD: ${x.tld}`)}catch(e){await sendText(sock,j,`⚠️ ${safeText(e.message,400)}`)}sessions.delete(sk);continue}
    if(s?.mode==='morse'){try{const r=morseCode(text);await sendText(sock,j,`🔤 Morse ${r.mode==='encode'?'Encode ▶️':'Decode ◀️'}\n\n${r.result}`)}catch(e){await sendText(sock,j,`⚠️ ${safeText(e.message,300)}`)}sessions.delete(sk);continue}
    if(s?.mode==='roman'){try{const r=romanNumerals(text.trim());await sendText(sock,j,`🏛️ ${r.input} → *${r.result}*`)}catch(e){await sendText(sock,j,`⚠️ ${safeText(e.message,300)}`)}sessions.delete(sk);continue}
    if(s?.mode==='color'){try{const x=await colorInfo(text.trim());await sendText(sock,j,`🎨 *${x.name}*\n\n🔲 HEX: ${x.hex}\n🔴🟢🔵 RGB: ${x.rgb}\n🌈 HSL: ${x.hsl}${x.contrast?'\n⚫ Contrast: '+x.contrast:''}`)}catch(e){await sendText(sock,j,`⚠️ ${safeText(e.message,400)}`)}sessions.delete(sk);continue}
    if(s?.mode==='encrypt'){try{const parts=text.split('|');if(parts.length<2)throw new Error('Usage: your text | passphrase');const enc=encryptText(parts.slice(0,-1).join('|').trim(),parts[parts.length-1].trim());await sendText(sock,j,`🔒 Encrypted:\n\n${enc}\n\n⚠️ Remember your passphrase — without it, the text cannot be decrypted.`)}catch(e){await sendText(sock,j,`⚠️ ${safeText(e.message,400)}`)}sessions.delete(sk);continue}
    if(s?.mode==='decrypt'){try{const parts=text.split('|');if(parts.length<2)throw new Error('Usage: encrypted_text | passphrase');const dec=decryptText(parts.slice(0,-1).join('|').trim(),parts[parts.length-1].trim());await sendText(sock,j,`🔓 Decrypted:\n\n${dec}`)}catch(e){await sendText(sock,j,`⚠️ ${safeText(e.message,400)}`)}sessions.delete(sk);continue}
    if(s?.mode==='qr'){const file=await qr(text);try{await sock.sendMessage(j,{image:fs.readFileSync(file),caption:'🔳 MR DKxx QR'})}finally{try{fs.unlinkSync(file)}catch{}}sessions.delete(sk);continue}
    if(s?.mode==='calc'){try{await sendText(sock,j,`🧮 ${calc(text)}`)}catch{await sendText(sock,j,'⚠️ Invalid calculation.')}sessions.delete(sk);continue}
    if(s?.mode==='password'){try{const n=/^\d+$/.test(text.trim())?Number(text.trim()):16;await sendText(sock,j,`🔐 ${require('./services/tools').password(n)}`)}catch(e){await sendText(sock,j,`⚠️ ${e.message}`)}sessions.delete(sk);continue}
    if(s?.mode==='hash'){try{const a=text.split(/\r?\n/,2),alg=(a[0]||'sha256').trim().toLowerCase(),value=a.length>1?a[1]:text;await sendText(sock,j,`🔒 ${require('./services/tools').hash(value,alg)}\nAlgorithm: ${['md5','sha1','sha256','sha512'].includes(alg)?alg:'sha256'}`)}catch(e){await sendText(sock,j,`⚠️ ${e.message}`)}sessions.delete(sk);continue}
    if(s?.mode==='base64'){try{if(/^decode$/i.test(text.trim())){sessions.set(sk,{mode:'base64Decode'});await sendText(sock,j,'🔤 Send Base64 text to decode.')}else{await sendText(sock,j,`🔤 Base64: ${require('./services/tools').base64Encode(text)}`);sessions.delete(sk)}}catch(e){await sendText(sock,j,`⚠️ ${e.message}`);sessions.delete(sk)}continue}
    if(s?.mode==='base64Decode'){try{await sendText(sock,j,`🔤 Decoded: ${require('./services/tools').base64Decode(text)}`)}catch(e){await sendText(sock,j,`⚠️ ${e.message}`)}sessions.delete(sk);continue}
    if(s?.mode==='json'){try{await sendText(sock,j,`🧾\n${require('./services/tools').jsonFormat(text)}`)}catch(e){await sendText(sock,j,`⚠️ Invalid JSON: ${e.message}`)}sessions.delete(sk);continue}
    if(s?.mode==='random'){try{const a=text.trim().split(/\s+/),min=a.length>1?Number(a[0]):1,max=a.length>1?Number(a[1]):Number(a[0])||100;await sendText(sock,j,`🎲 ${require('./services/tools').randomNumber(min,max)}`)}catch(e){await sendText(sock,j,`⚠️ ${e.message}`)}sessions.delete(sk);continue}
    if(s?.mode==='tts'){try{const p=await require('./services/providers').tts(text);await sock.sendMessage(j,{audio:fs.readFileSync(p),mimetype:'audio/mpeg',fileName:'mrdkxx-tts.mp3'});try{fs.unlinkSync(p)}catch{}}catch(e){await sendText(sock,j,`⚠️ ${e.message}`)}sessions.delete(sk);continue}
    if(s?.mode==='unit'){try{const a=text.trim().split(/\s+/);if(a.length!==3)throw new Error('Use: value fromUnit toUnit (example: 10 km m)');await sendText(sock,j,`📏 ${unitConvert(a[0],a[1],a[2])} ${a[2]}`)}catch(e){await sendText(sock,j,`⚠️ ${e.message}`)}sessions.delete(sk);continue}
    if(s?.mode==='timestamp'){try{const x=timestamp(text.trim());await sendText(sock,j,`🕒 ISO: ${x.iso}\n🔢 Unix: ${x.unix}\n📍 Local: ${x.local}`)}catch(e){await sendText(sock,j,`⚠️ ${e.message}`)}sessions.delete(sk);continue}
    if(s?.mode==='currency'){try{const a=text.trim().split(/\s+/);if(a.length!==3)throw new Error('Use: amount FROM TO (example: 100 USD LKR)');const r=await require('./services/tools').currencyConvert(a[0],a[1],a[2]);await sendText(sock,j,`💱 ${r.amount} ${r.from} = *${r.result.toFixed(2)} ${r.to}*\n📊 Rate: 1 ${r.from} = ${r.rate} ${r.to}\n🕒 ${r.updated}`)}catch(e){await sendText(sock,j,`⚠️ ${e.message}`)}sessions.delete(sk);continue}
    if(s?.mode==='bmi'){try{const a=text.trim().split(/\s+/);if(a.length!==2)throw new Error('Use: weight(kg) height(cm) — example: 70 175');const r=require('./services/tools').bmi(a[0],a[1]);await sendText(sock,j,`🩺 BMI: *${r.value}*\n📊 Category: ${r.category}`)}catch(e){await sendText(sock,j,`⚠️ ${e.message}`)}sessions.delete(sk);continue}
    if(s?.mode==='age'){try{const r=require('./services/tools').ageCalc(text);await sendText(sock,j,`🎂 Age: *${r.years} years, ${r.months} months, ${r.days} days*\n📅 Total days lived: ${r.totalDays}`)}catch(e){await sendText(sock,j,`⚠️ ${e.message}`)}sessions.delete(sk);continue}
    if(s?.mode==='ipLookup'){try{const q=text.trim()==='.'?'':text.trim();const r=await require('./services/tools').ipLookup(q);await sendText(sock,j,`🌐 IP Lookup\n\n📍 IP: ${r.ip}\n🏙️ ${r.city||'-'}, ${r.region||'-'}, ${r.country||'-'}\n🏢 ISP: ${r.isp||'-'}\n🕒 Timezone: ${r.timezone||'-'}`)}catch(e){await sendText(sock,j,`⚠️ ${e.message}`)}sessions.delete(sk);continue}
    if(s?.mode==='weather'){try{const w=await require('./services/tools').weather(text.trim());await sendText(sock,j,`🌦️ Weather • ${w.place}\n\n${w.condition}\n🌡️ Temp: ${w.temp}°C (feels like ${w.feelsLike}°C)\n💧 Humidity: ${w.humidity}%\n💨 Wind: ${w.wind} km/h\n🌧️ Precipitation: ${w.precipitation} mm`)}catch(e){await sendText(sock,j,`⚠️ ${e.message}`)}sessions.delete(sk);continue}
    if(s?.mode==='news'){try{const topic=text.trim()==='.'?'':text.trim();const items=await require('./services/tools').newsHeadlines(topic);await sendText(sock,j,`📰 Top Headlines${topic?` • ${topic}`:''}\n\n${items.map((x,i)=>`${i+1}. ${x.title}${x.source?` (${x.source})`:''}`).join('\n\n')}`)}catch(e){await sendText(sock,j,`⚠️ ${e.message}`)}sessions.delete(sk);continue}
    if(s?.mode==='percent'){try{const r=require('./services/tools').percentCalc(text);await sendText(sock,j,`📊 ${r}`)}catch(e){await sendText(sock,j,`⚠️ ${safeText(e.message,300)}`)}sessions.delete(sk);continue}
    if(s?.mode==='countdown'){try{const r=require('./services/tools').countdownCalc(text);await sendText(sock,j,r.past?`📅 ${r.label} (${r.date}) was *${r.days}d ${r.hours}h ${r.minutes}m* ago.`:`📅 ${r.label} (${r.date}) is in *${r.days}d ${r.hours}h ${r.minutes}m*.`)}catch(e){await sendText(sock,j,`⚠️ ${safeText(e.message,300)}`)}sessions.delete(sk);continue}
    if(s?.mode==='splitbill'){try{const r=require('./services/tools').splitBill(text);await sendText(sock,j,`🧾 Bill Split\n\n💵 Total: ${r.total}\n👥 People: ${r.people}${r.tipPct?`\n💁 Tip (${r.tipPct}%): ${r.tipAmount.toFixed(2)}`:''}\n🧮 Grand total: ${r.grandTotal.toFixed(2)}\n\n👉 Each person pays: *${r.perPerson.toFixed(2)}*`)}catch(e){await sendText(sock,j,`⚠️ ${safeText(e.message,400)}`)}sessions.delete(sk);continue}
    if(s?.mode==='picker'){try{const r=require('./services/tools').pickWinner(text,1);await sendText(sock,j,`🎯 ${r.entries} entries received.\n\n🏆 Winner: *${r.winners[0]}*`)}catch(e){await sendText(sock,j,`⚠️ ${safeText(e.message,300)}`)}sessions.delete(sk);continue}
    if(s?.mode==='holidays'){try{const r=await require('./services/tools').publicHolidays(text);await sendText(sock,j,`📖 Public Holidays • ${r.code} ${r.year}\n\n${r.holidays.map(h=>`• ${h.date}: ${h.name}`).join('\n')}`)}catch(e){await sendText(sock,j,`⚠️ ${safeText(e.message,400)}`)}sessions.delete(sk);continue}
    if(s?.mode==='notesAdd'){const noteText=String(text||'').trim();if(!noteText){continue}try{db.noteAdd(actor,noteText.slice(0,1000));await sendText(sock,j,'✅ Note saved. Use "My Notes → List My Notes" to view it anytime.')}catch(e){await sendText(sock,j,`⚠️ ${safeText(e.message,300)}`)}sessions.delete(sk);continue}
    if(s?.mode==='timezone'){if(!String(text||'').trim())continue;try{const r=require('./services/tools').timezoneConvert(text);await sendText(sock,j,`🌍 Time Zone Convert\n\n🏙️ ${r.fromCity}: ${r.fromTime}\n🏙️ ${r.toCity}: ${r.toTime}`)}catch(e){await sendText(sock,j,`⚠️ ${safeText(e.message,400)}`)}sessions.delete(sk);continue}
    if(s?.mode==='cryptoprice'){if(!String(text||'').trim())continue;try{const r=await require('./services/tools').cryptoPrice(text);const chg=Number.isFinite(r.change24h)?`\n📈 24h: ${r.change24h>=0?'+':''}${r.change24h.toFixed(2)}%`:'';await sendText(sock,j,`💰 ${r.id}\n\n💵 USD: $${r.usd?.toLocaleString()||'-'}\n🇱🇰 LKR: Rs. ${r.lkr?.toLocaleString()||'-'}${chg}`)}catch(e){await sendText(sock,j,`⚠️ ${safeText(e.message,300)}`)}sessions.delete(sk);continue}
    if(s?.mode==='emi'){if(!String(text||'').trim())continue;try{const r=require('./services/tools').emiCalculate(text);await sendText(sock,j,`🏦 Loan / EMI\n\n💵 Principal: ${r.principal.toLocaleString()}\n📊 Rate: ${r.annualRate}% / year\n📅 Term: ${r.years} years (${r.n} months)\n\n👉 Monthly EMI: *${r.emi.toFixed(2)}*\n💰 Total payment: ${r.totalPayment.toFixed(2)}\n💸 Total interest: ${r.totalInterest.toFixed(2)}`)}catch(e){await sendText(sock,j,`⚠️ ${safeText(e.message,400)}`)}sessions.delete(sk);continue}
    if(s?.mode==='vcard'){if(!String(text||'').trim())continue;try{const r=require('./services/tools').vcardGenerate(text);await sock.sendMessage(j,{document:Buffer.from(r.vcf,'utf8'),mimetype:'text/vcard',fileName:`${r.name.replace(/[^\w\- ]/g,'')||'contact'}.vcf`,caption:`📇 vCard for ${r.name}`})}catch(e){await sendText(sock,j,`⚠️ ${safeText(e.message,400)}`)}sessions.delete(sk);continue}
    if(s?.mode==='distance'){if(!String(text||'').trim())continue;try{const r=require('./services/tools').haversineDistance(text);await sendText(sock,j,`📍 Distance\n\n${r.km.toFixed(2)} km\n${r.miles.toFixed(2)} miles`)}catch(e){await sendText(sock,j,`⚠️ ${safeText(e.message,300)}`)}sessions.delete(sk);continue}
    if(s?.mode==='totp'){if(!String(text||'').trim())continue;try{const r=require('./services/tools').totpGenerate(text);await sendText(sock,j,`🔐 2FA Code\n\n*${r.code}*\n⏳ Valid for ${r.secondsLeft}s more`)}catch(e){await sendText(sock,j,`⚠️ ${safeText(e.message,300)}`)}sessions.delete(sk);continue}
    if(s?.mode==='fancytext'){if(!String(text||'').trim())continue;try{const styles=require('./services/tools').fancyText(text);await sendText(sock,j,`🎨 Fancy Text\n\n${styles.map(([name,val])=>`${name}: ${val}`).join('\n\n')}`)}catch(e){await sendText(sock,j,`⚠️ ${safeText(e.message,300)}`)}sessions.delete(sk);continue}
    if(s?.mode==='thesaurus'){if(!String(text||'').trim())continue;try{const r=await require('./services/tools').thesaurusLookup(text);await sendText(sock,j,`📚 ${r.word}\n\n✅ Synonyms: ${r.synonyms.length?r.synonyms.join(', '):'none found'}\n❌ Antonyms: ${r.antonyms.length?r.antonyms.join(', '):'none found'}`)}catch(e){await sendText(sock,j,`⚠️ ${safeText(e.message,300)}`)}sessions.delete(sk);continue}
    if(s?.mode==='singlish'){if(!String(text||'').trim())continue;try{const r=require('./services/tools').singlishToSinhala(text);await sendText(sock,j,`📝 ${r}`)}catch(e){await sendText(sock,j,`⚠️ ${safeText(e.message,300)}`)}sessions.delete(sk);continue}
    if(s?.mode==='whois'){if(!String(text||'').trim())continue;try{const r=await require('./services/tools').whoisLookup(text);await sendText(sock,j,`🔎 WHOIS • ${r.domain}\n\n📌 Status: ${r.status}\n📅 Registered: ${r.registered}\n⏳ Expires: ${r.expires}\n🔄 Updated: ${r.updated}\n🖥️ Nameservers: ${r.nameservers.length?r.nameservers.join(', '):'none listed'}`)}catch(e){await sendText(sock,j,`⚠️ ${safeText(e.message,300)}`)}sessions.delete(sk);continue}
    if(s?.mode==='dnslookup'){if(!String(text||'').trim())continue;try{const r=await require('./services/tools').dnsLookup(text);const recs=r.records.map(x=>typeof x==='object'?JSON.stringify(x):String(x));await sendText(sock,j,`🌐 DNS • ${r.domain} (${r.type})\n\n${recs.map(x=>`• ${x}`).join('\n')}`)}catch(e){await sendText(sock,j,`⚠️ ${safeText(e.message,300)}`)}sessions.delete(sk);continue}
    if(s?.mode==='sslcheck'){if(!String(text||'').trim())continue;try{const r=await require('./services/tools').sslCheck(text);await sendText(sock,j,`🔒 SSL Certificate • ${r.hostname}\n\n👤 Subject: ${r.subject}\n🏢 Issuer: ${r.issuer}\n📅 Valid from: ${r.validFrom}\n⏳ Valid to: ${r.validTo}\n${r.daysLeft<0?'❌ EXPIRED':`✅ ${r.daysLeft} days remaining`}`)}catch(e){await sendText(sock,j,`⚠️ ${safeText(e.message,300)}`)}sessions.delete(sk);continue}
    if(s?.mode==='headers'){if(!String(text||'').trim())continue;try{const r=await require('./services/tools').securityHeadersCheck(text);await sendText(sock,j,`🛡️ Security Headers • ${r.url}\n\n📊 Score: ${r.score}\n\n${r.checks.map(([name,v])=>`${v?'✅':'❌'} ${name}`).join('\n')}`)}catch(e){await sendText(sock,j,`⚠️ ${safeText(e.message,300)}`)}sessions.delete(sk);continue}
    if(s?.mode==='pwnedpw'){if(!String(text||'').trim())continue;try{const r=await require('./services/tools').pwnedPasswordCheck(text);await sendText(sock,j,r.pwned?`🕵️ ⚠️ This password has appeared in *${r.count.toLocaleString()}* known data breaches. Change it if you're using it anywhere.`:'🕵️ ✅ Good news — this password was not found in any known breach list.')}catch(e){await sendText(sock,j,`⚠️ ${safeText(e.message,300)}`)}sessions.delete(sk);continue}
    if(s?.mode==='pwstrength'){if(!String(text||'').trim())continue;try{const r=require('./services/tools').passwordStrength(text);const c=r.checks;await sendText(sock,j,`💪 Password Strength: *${r.label}*\n\n📏 Length: ${r.length}\n🎲 Est. entropy: ~${r.entropyBits} bits\n\n${c.length12plus?'✅':'❌'} 12+ characters\n${c.hasUpper?'✅':'❌'} Uppercase letter\n${c.hasLower?'✅':'❌'} Lowercase letter\n${c.hasDigit?'✅':'❌'} Number\n${c.hasSymbol?'✅':'❌'} Symbol\n${c.noLongRepeat?'✅':'❌'} No long repeated runs`)}catch(e){await sendText(sock,j,`⚠️ ${safeText(e.message,300)}`)}sessions.delete(sk);continue}
    if(s?.mode==='prayer'){try{const [city,...rest]=text.trim().split(',');const x=await require('./services/tools').prayerTimes(city,rest.join(',').trim());await sendText(sock,j,`🕌 Prayer Times • ${x.place}\n📅 ${x.date}\n\n🌅 Fajr: ${x.fajr}\n☀️ Dhuhr: ${x.dhuhr}\n🌇 Asr: ${x.asr}\n🌆 Maghrib: ${x.maghrib}\n🌙 Isha: ${x.isha}`)}catch(e){await sendText(sock,j,`⚠️ ${e.message}`)}sessions.delete(sk);continue}
    if(s?.mode==='reminder'){
      try{
        const raw=text.trim();
        const mm=raw.match(/^(\d+)\s*(m|min|mins|minute|minutes|h|hr|hrs|hour|hours)\b[:\-]?\s*(.*)$/i);
        if(!mm)throw new Error('Use: <number> m/h <message>\nExample: 30m Check the download folder');
        const n=Number(mm[1]);const unit=mm[2].toLowerCase();const msg=mm[3].trim()||'⏰ Reminder!';
        const ms=(unit.startsWith('h')?n*3600:n*60)*1000;
        if(ms>24*3600*1000)throw new Error('Maximum reminder time is 24 hours.');
        setTimeout(()=>{sendText(sock,j,`⏰ Reminder: ${msg}`).catch(()=>{})},ms);
        await sendText(sock,j,`✅ Reminder set for ${n} ${unit.startsWith('h')?'hour(s)':'minute(s)'} from now.\n\n⚠️ Note: reminders are kept in memory only — if the bot restarts before it fires, it will be lost.`);
      }catch(e){await sendText(sock,j,`⚠️ ${e.message}`)}
      sessions.delete(sk);continue
    }
    if(s?.mode==='poll'){
      try{
        if(!isGroup(j))throw new Error('Polls can only be created in groups.');
        const lines=text.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
        if(lines.length<3)throw new Error('Send a question on the first line and at least 2 options, each on its own line.');
        const [question,...options]=lines;
        if(options.length>12)throw new Error('Maximum 12 options.');
        await sock.sendMessage(j,{poll:{name:question,values:options,selectableCount:1}});
      }catch(e){await sendText(sock,j,`⚠️ ${e.message}`)}
      sessions.delete(sk);continue
    }
    if(s?.mode==='websearch'){try{await sendText(sock,j,'🌐 Searching...');const r=await askWeb(text,j);await sendText(sock,j,`🌐 Web Search\n\n${r.text||r}`)}catch(e){await sendText(sock,j,`⚠️ Web search failed: ${safeText(e.message,700)}`)}sessions.delete(sk);continue}
    if(s?.mode==='vision'){
      if(!incomingMsg.imageMessage){await sendText(sock,j,'🖼️ Please send an image now. You can add a caption/question.');continue}
      let f=null;
      try{const x=await saveIncomingMedia(m);f=x.input;await sendText(sock,j,'👁️ Analyzing image...');await sendText(sock,j,await vision(f,text||'Describe this image accurately and extract any visible text. Answer in the user language.'));}
      catch(e){await sendText(sock,j,`⚠️ Vision failed: ${safeText(e.message,700)}`)}
      finally{if(f)try{fs.unlinkSync(f)}catch{};sessions.delete(sk)}
      continue
    }
    if(s?.mode==='ocr'){
      if(!(incomingMsg.imageMessage||incomingMsg.documentMessage)){await sendText(sock,j,'🖼️ Please send an image or document now.');continue}
      let f=null;
      try{const x=await saveIncomingMedia(m);f=x.input;await sendText(sock,j,'🔎 Reading text...');await sendText(sock,j,await ocr(f));}
      catch(e){await sendText(sock,j,`⚠️ OCR failed: ${safeText(e.message,700)}`)}
      finally{if(f)try{fs.unlinkSync(f)}catch{};sessions.delete(sk)}
      continue
    }
    if(s?.mode==='stt'){
      if(!(incomingMsg.audioMessage||incomingMsg.documentMessage)){await sendText(sock,j,'🎙️ Please send a voice/audio message now.');continue}
      let f=null;
      try{const x=await saveIncomingMedia(m);f=x.input;await sendText(sock,j,'🎙️ Transcribing...');await sendText(sock,j,await stt(f));}
      catch(e){await sendText(sock,j,`⚠️ STT failed: ${safeText(e.message,700)}`)}
      finally{if(f)try{fs.unlinkSync(f)}catch{};sessions.delete(sk)}
      continue
    }
    if(s?.mode==='mediaTool'){
      if(!(incomingMsg.imageMessage||incomingMsg.videoMessage||incomingMsg.audioMessage||incomingMsg.documentMessage)){await sendText(sock,j,'📎 Please send the requested media file now.');continue}
      let input=null,out=null;
      try{
        const x=await saveIncomingMedia(m);input=x.input;await sendText(sock,j,'⚙️ Processing media...');
        if(s.kind==='compress_video')out=await media.transcode(input,{type:'video',format:'mp4',quality:'medium'});
        else if(s.kind==='audio_convert')out=await media.audioExtract(input);
        else if(s.kind==='thumbnail')out=await media.thumbnail(input);
        else if(s.kind==='gif')out=await media.gif(input);
        if(!out)throw new Error('No output was produced.');
        const ext=path.extname(out).toLowerCase();
        if(ext==='.mp3'||ext==='.wav'||ext==='.ogg')await sock.sendMessage(j,{audio:fs.readFileSync(out),mimetype:ext==='.wav'?'audio/wav':'audio/mpeg',fileName:path.basename(out)});
        else if(ext==='.gif')await sock.sendMessage(j,{document:fs.readFileSync(out),mimetype:'image/gif',fileName:path.basename(out)});
        else if(ext==='.jpg'||ext==='.jpeg'||ext==='.png'||ext==='.webp')await sock.sendMessage(j,{image:fs.readFileSync(out),caption:'✨ MR DKxx • Media Tool'});
        else await sock.sendMessage(j,{video:fs.readFileSync(out),mimetype:'video/mp4',fileName:path.basename(out)});
      }catch(e){await sendText(sock,j,`⚠️ Media tool failed: ${safeText(e.message,700)}`)}
      finally{if(input)try{fs.unlinkSync(input)}catch{};if(out)try{fs.unlinkSync(out)}catch{};sessions.delete(sk)}
      continue
    }
    if(s?.mode==='prompt'){const prompts={summarize:`Summarize clearly in the user's language:\n\n${text}`,translate:`Translate naturally between Sinhala and English. Preserve meaning:\n\n${text}`,analyze:`Analyze this text and return useful key points, risks and conclusions:\n\n${text}`,grammar:`Proofread and correct grammar/spelling while preserving the original meaning and tone:\n\n${text}`,coding:`Act as a careful coding assistant. Explain the solution, identify bugs and provide safe corrected code when needed:\n\n${text}`,caption:`Write 3 engaging social media captions for this content. Return Sinhala and English options where useful:\n\n${text}`,hashtags:`Generate 15 relevant hashtags for this content. Avoid spammy/repetitive tags:\n\n${text}`,rewrite:`Rewrite this naturally, clearly and professionally while preserving the meaning:\n\n${text}`,imageai:`Create a detailed safe image-generation prompt from this request. Return only the prompt:\n\n${text}`};await runAi(sock,j,prompts[s.kind],s.kind,'auto','',actor);sessions.delete(sk);continue}
    if(s?.mode==='imageGen'){
      // BUGFIX: picking a numbered image model (e.g. "5", "12") from the pretty-menu
      // sometimes delivers a stray follow-up event with empty/whitespace text right
      // after the real selection (WhatsApp/Baileys echo of the interactive tap, or an
      // overlapping duplicate event). Previously that stray empty text was fed straight
      // into image(), which immediately threw "the text was empty" and — worse —
      // unconditionally cleared the session, silently cancelling the "send your text
      // now" prompt before the user ever got to type it. That's why it took going Back
      // and re-entering the menu two or three times before a prompt actually stuck.
      // Now a blank trigger is just ignored: the session stays alive and still waiting
      // for the user's real prompt, with no confusing error shown.
      const imgPrompt=String(text||'').trim();
      if(!imgPrompt)continue;
      // Guard against the same session being run twice concurrently (e.g. if a
      // duplicate event for the same prompt slips through), which previously showed
      // "Creating image..." twice for a single request.
      const imgLockKey=`imgGen:${sk}`;
      if(inFlightInputs.has(imgLockKey))continue;
      inFlightInputs.add(imgLockKey);
      await react(sock,j,m,'⏳');await sendText(sock,j,'🎨 Creating image...');let file=null;try{file=await image(imgPrompt,s?.kind||'image_auto');if(!file||!fs.existsSync(file)||fs.statSync(file).size===0)throw new Error('Image generation returned no usable file.');const ext=path.extname(file).toLowerCase();const mimetype=ext==='.jpg'||ext==='.jpeg'?'image/jpeg':ext==='.webp'?'image/webp':'image/png';await sock.sendMessage(j,{image:{stream:fs.createReadStream(file)},mimetype,caption:'🎨 MR DKxx • AI Image'});db.usage(j,'image');await react(sock,j,m,'✅')}catch(e){await react(sock,j,m,'❌');await sendText(sock,j,`⚠️ Image generation failed: ${safeText(e.message,700)}`)}finally{if(file)try{fs.unlinkSync(file)}catch{};inFlightInputs.delete(imgLockKey)}sessions.delete(sk);continue;
    }
    if(/^https?:\/\//i.test(text)){await sendDownloadMenu(sock,j,text,m);continue}
    // Unmatched ordinary messages are intentionally ignored.
    // AI replies require the explicit DK prefix; menu actions use explicit commands/buttons.
    continue;
   }catch(e){logger.error({err:e.message},'message handler');await sendText(sock,j,`⚠️ ${t(j,'error')}\n${safeText(e.message,800)}`).catch(()=>{})}
  }
 });
 return sock;
}
module.exports={startBot};

# Image generation ignoring the prompt (always looked like "the same photo")

## Symptom
Sending a Sinhala prompt to Image Auto (or any specific image model) produced a
generic-looking portrait that had nothing to do with what was actually asked for —
every request looked like it rendered "the same photo," regardless of wording.

## Root cause
`services/providers.js` sent the raw prompt text straight to whichever image
provider handled the request. The free/no-key fallback providers (Pollinations,
and by extension whatever "Image Auto" lands on) are trained almost entirely on
English captions and effectively can't read Sinhala script — a prompt they can't
parse doesn't error, it just quietly renders a generic default-looking image no
matter what was typed. Gemini's own image models aren't guaranteed either:
Sinhala is not in Google's list of best-supported prompt languages for Nano
Banana / Nano Banana Pro.

This was never about which image model was picked — every provider was receiving
a prompt it couldn't reliably use.

## Fix
Added `translateImagePrompt()` in `services/providers.js`, called once at the top
of the shared `image()` function (so it applies to Image Auto and every specific
model choice alike):

- If the prompt is already plain ASCII/English, it is returned unchanged — no
  behavior change, no extra latency, for prompts that already worked.
- Otherwise, if `GEMINI_API_KEY` is configured, Gemini's text model
  (`gemini-3.6-flash`) restates the prompt as a detailed English
  image-generation prompt, keeping every subject/action/detail from the
  original request, before it reaches any image provider.
- Any failure (no key, network issue, safety block) silently falls back to the
  original raw prompt — image generation still runs exactly as it did before
  this fix, it just doesn't get the translation benefit.

## Not changed
Provider order, fallback behavior, menu options, model lists, error handling and
every other file are untouched. Only `services/providers.js` was edited.

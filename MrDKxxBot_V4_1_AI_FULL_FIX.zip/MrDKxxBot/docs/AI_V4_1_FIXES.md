# MR DKxx 4.1 AI Reliability Upgrade

- Removed per-model WhatsApp error spam during Gemini failover.
- Updated the default Gemini model list to the current stable model IDs.
- Added silent provider failover: Gemini -> Pollinations (when configured) -> local Ollama.
- Added local AI support through Ollama; no cloud API key is needed once Ollama + a model are installed on the VPS.
- Added AI Provider Status menu and `/aistatus` command.
- Added `/local <prompt>` for local AI and `/gemini <prompt>` for Gemini-first requests.
- Preserved the existing menu, media, downloads, group, tools, database and sticker features.
- Added explicit AI timeout controls and a concise final error instead of repeated model errors.

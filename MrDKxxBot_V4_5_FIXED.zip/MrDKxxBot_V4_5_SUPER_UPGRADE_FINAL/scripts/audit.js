const fs=require('fs');
const path=require('path');
const root=path.resolve(__dirname,'..');
const bot=fs.readFileSync(path.join(root,'src','bot.js'),'utf8');
const checks=[
  [!/\blower\s*[!=]=/.test(bot),'No undefined lower-variable references'],
  [bot.includes('if(dkPayload!==null)'),'AI has an explicit DK prefix gate'],
  [bot.includes('Unmatched ordinary messages are intentionally ignored'),'Unmatched messages are ignored'],
  [!bot.includes("await runAi(sock,j,p,'gemini','gemini','')"),'Direct Gemini command cannot bypass DK gate'],
  [bot.includes('function imageModelNames()'),'Image model selection is explicit'],
  [bot.includes('imageProviderStatus'),'Image provider status is exposed'],
  [bot.includes("choice==='url'"),'Generic URL info tool is wired'],
  [bot.includes("if(botPaused) continue"),'Paused mode ignores incoming messages'],
];
let failed=0;
for(const [ok,label] of checks){console.log(`${ok?'OK  ':'FAIL'} ${label}`);if(!ok)failed++}
if(failed)process.exit(1);
console.log(`\nRuntime-gate audit passed: ${checks.length} checks.`);

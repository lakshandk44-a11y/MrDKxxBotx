const fs=require('fs');
const path=require('path');
const root=path.resolve(__dirname,'..');
const bot=fs.readFileSync(path.join(root,'src','bot.js'),'utf8');
const menu=fs.readFileSync(path.join(root,'src','services','menu.js'),'utf8');
const jsFiles=[];
function walk(dir){for(const name of fs.readdirSync(dir)){const p=path.join(dir,name);const st=fs.statSync(p);if(st.isDirectory())walk(p);else if(name.endsWith('.js'))jsFiles.push(p)}}
walk(path.join(root,'src'));
const allJs=jsFiles.map(f=>fs.readFileSync(f,'utf8')).join('\n');
const checks=[
  [!(/\blower\s*[!=]=/.test(bot)),'No undefined lower-variable references'],
  [bot.includes('if(dkPayload!==null)'),'AI has an explicit DK prefix gate'],
  [bot.includes('Unmatched ordinary messages are intentionally ignored'),'Unmatched messages are ignored'],
  [!bot.includes("await runAi(sock,j,p,'gemini','gemini','')"),'Direct Gemini command cannot bypass DK gate'],
  [bot.includes('function imageModelNames()'),'Image model selection is explicit'],
  [bot.includes('imageProviderStatus'),'Image provider status is exposed'],
  [bot.includes("choice==='url'"),'Generic URL info tool is wired'],
  [bot.includes("if(botPaused) continue"),'Paused mode ignores incoming messages'],
  [bot.includes("if(isGroup(jid))") && bot.includes("Reply with the number of your choice."),'Group menus use a WhatsApp-compatible plain-text fallback'],
  [bot.includes('function sessionKey(j,m)') && bot.includes("return isGroup(j)?`${j}|${actor}`:j;"),'Group interactive sessions are isolated per sender'],
  [bot.includes('getFallbackChoice(sk,text)'),'Group numbered menu replies use per-sender state'],
  [bot.includes("stateKeyArg:sessionKey(j,m)"),'Menu state is scoped to the requesting sender'],
  [!allJs.match(/(?:âœ¨|âš¡|ðŸ|ï¸|â€¢)/),'No common emoji mojibake remains in source JavaScript'],
  [!bot.includes('generateWAMessageFromContent(jid,{viewOnceMessage'),'Group menus are not wrapped as outgoing view-once messages'],
];
let failed=0;
for(const [ok,label] of checks){console.log(`${ok?'OK  ':'FAIL'} ${label}`);if(!ok)failed++}
if(failed)process.exit(1);
console.log(`\nRuntime-gate audit passed: ${checks.length} checks.`);

# MR DKxx V4.5

- Preserved all V4.4 functionality and the existing WhatsApp auth/session architecture.
- Added optional Groq and OpenRouter text AI failover.
- Added explicit Gemini Google Search grounding flow.
- Added Gemini image understanding / vision flow.
- Added optional fal.ai and Hugging Face image providers.
- Expanded Image Auto failover order.
- Added OCR and STT menu flows with external-provider and local Tesseract/Whisper fallbacks.
- Added video compression, audio conversion, thumbnails and video-to-GIF tools.
- Added unit conversion and timestamp tools.
- Added owner-only SQLite database backup.
- Expanded provider status and self-tests.
- Kept Pollinations image generation opt-in because the previously deployed endpoint returned HTTP 404.
- Kept downloads limited to public/authorized content and retained existing queue/size protections.

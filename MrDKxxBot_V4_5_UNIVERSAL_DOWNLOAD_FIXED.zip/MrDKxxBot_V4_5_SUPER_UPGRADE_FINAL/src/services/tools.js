const QRCode=require('qrcode');
const crypto=require('crypto');
const path=require('path');
const {tmpDir}=require('../utils');

async function qr(text){const out=path.join(tmpDir,`qr-${Date.now()}.png`);await QRCode.toFile(out,String(text),{width:700,margin:2});return out}
function calc(expr){const s=String(expr||'').trim();if(!s||s.length>300||!/^[0-9+\-*/%().\s]+$/.test(s))throw new Error('Only arithmetic expressions are allowed');const v=Function(`"use strict";return (${s})`)();if(!Number.isFinite(Number(v)))throw new Error('Calculation returned a non-finite value');return v}
function isSafeUrl(v){try{const u=new URL(String(v));return ['http:','https:'].includes(u.protocol)}catch{return false}}
async function urlInfo(url){if(!isSafeUrl(url))throw new Error('Invalid URL');let r=null,last=null;for(const method of ['HEAD','GET'])try{r=await fetch(new URL(url),{method,redirect:'follow',headers:{'user-agent':'MR-DKxx/4.5'}});if(r.ok||method==='GET')break}catch(e){last=e}if(!r)throw last||new Error('URL request failed');let ct=r.headers.get('content-type')||'',title='';if(ct.includes('text/html')){let html='';try{html=await r.text()}catch{}title=(html.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1]||'').replace(/\s+/g,' ').trim().slice(0,180)}return {finalUrl:r.url||url,status:r.status,statusText:r.statusText||'',contentType:ct,contentLength:r.headers.get('content-length')||'',title:title||new URL(r.url||url).hostname}}
function uuid(){return crypto.randomUUID()}
function password(length=16){const n=Math.min(64,Math.max(6,Number(length)||16));const chars='ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%^&*_-+=';let out='';for(let i=0;i<n;i++)out+=chars[crypto.randomInt(chars.length)];return out}
function hash(text,algorithm='sha256'){const a=['md5','sha1','sha256','sha512'].includes(String(algorithm).toLowerCase())?String(algorithm).toLowerCase():'sha256';return crypto.createHash(a).update(String(text)).digest('hex')}
function base64Encode(text){return Buffer.from(String(text),'utf8').toString('base64')}
function base64Decode(text){const s=String(text).trim();if(!/^[A-Za-z0-9+/]*={0,2}$/.test(s)||s.length%4===1)throw new Error('Invalid Base64');return Buffer.from(s,'base64').toString('utf8')}
function randomNumber(min=1,max=100){let a=Math.ceil(Number(min)),b=Math.floor(Number(max));if(!Number.isFinite(a)||!Number.isFinite(b)||a>b)throw new Error('Invalid range');return crypto.randomInt(a,b+1)}
function jsonFormat(text){return JSON.stringify(JSON.parse(String(text)),null,2)}
function timestamp(value=''){const d=value?new Date(value):new Date();if(Number.isNaN(d.getTime()))throw new Error('Invalid date/time');return {iso:d.toISOString(),unix:Math.floor(d.getTime()/1000),local:d.toString()}}
function unitConvert(value,from,to){const v=Number(value);if(!Number.isFinite(v))throw new Error('Invalid number');const f=String(from).toLowerCase(),t=String(to).toLowerCase();const table={m:1,km:1000,cm:0.01,mm:0.001,mi:1609.344,ft:0.3048,yd:0.9144,in:0.0254,kg:1,g:0.001,lb:0.45359237,oz:0.028349523125,l:1,ml:0.001};if(!(f in table)||!(t in table))throw new Error('Supported units: m km cm mm mi ft yd in kg g lb oz l ml');return v*table[f]/table[t]}
// Free, no-API-key currency conversion via open.er-api.com (161 currencies, daily rates).
async function currencyConvert(amount,from,to){
 const amt=Number(amount);if(!Number.isFinite(amt))throw new Error('Invalid amount');
 const f=String(from||'').trim().toUpperCase(),tgt=String(to||'').trim().toUpperCase();
 if(!/^[A-Z]{3}$/.test(f)||!/^[A-Z]{3}$/.test(tgt))throw new Error('Use 3-letter currency codes, e.g. USD LKR');
 const r=await fetch(`https://open.er-api.com/v6/latest/${f}`,{headers:{'user-agent':'MR-DKxx/4.5'}});
 if(!r.ok)throw new Error('Currency service is unavailable right now.');
 const data=await r.json();
 if(data.result!=='success')throw new Error(data['error-type']||'Currency lookup failed');
 const rate=data.rates?.[tgt];
 if(!rate)throw new Error(`Unknown currency code: ${tgt}`);
 return {amount:amt,from:f,to:tgt,rate,result:amt*rate,updated:data.time_last_update_utc||''};
}
// Free, no-API-key weather via Open-Meteo (geocoding + forecast).
async function weather(city){
 const name=String(city||'').trim();if(!name)throw new Error('Please provide a city name');
 const g=await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(name)}&count=1`,{headers:{'user-agent':'MR-DKxx/4.5'}});
 if(!g.ok)throw new Error('Location service is unavailable right now.');
 const gj=await g.json();
 const place=gj.results?.[0];
 if(!place)throw new Error(`Could not find a location named "${name}"`);
 const f=await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${place.latitude}&longitude=${place.longitude}&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m&timezone=auto`,{headers:{'user-agent':'MR-DKxx/4.5'}});
 if(!f.ok)throw new Error('Weather service is unavailable right now.');
 const fj=await f.json();
 const c=fj.current||{};
 const codes={0:'☀️ Clear sky',1:'🌤️ Mostly clear',2:'⛅ Partly cloudy',3:'☁️ Overcast',45:'🌫️ Fog',48:'🌫️ Fog',51:'🌦️ Light drizzle',53:'🌦️ Drizzle',55:'🌦️ Heavy drizzle',61:'🌧️ Light rain',63:'🌧️ Rain',65:'🌧️ Heavy rain',71:'🌨️ Light snow',73:'🌨️ Snow',75:'🌨️ Heavy snow',80:'🌦️ Rain showers',81:'🌦️ Rain showers',82:'⛈️ Violent showers',95:'⛈️ Thunderstorm',96:'⛈️ Thunderstorm with hail',99:'⛈️ Thunderstorm with hail'};
 return {
  place:`${place.name}${place.country?', '+place.country:''}`,
  temp:c.temperature_2m,feelsLike:c.apparent_temperature,humidity:c.relative_humidity_2m,
  wind:c.wind_speed_10m,precipitation:c.precipitation,
  condition:codes[c.weather_code]||'🌡️ Weather data',
  timezone:fj.timezone||''
 };
}
// Free, no-API-key top headlines via Google News RSS.
async function newsHeadlines(topic=''){
 const q=String(topic||'').trim();
 const url=q?`https://news.google.com/rss/search?q=${encodeURIComponent(q)}&hl=en-US&gl=US&ceid=US:en`:'https://news.google.com/rss?hl=en-US&gl=US&ceid=US:en';
 const r=await fetch(url,{headers:{'user-agent':'MR-DKxx/4.5'}});
 if(!r.ok)throw new Error('News service is unavailable right now.');
 const xml=await r.text();
 const items=[...xml.matchAll(/<item>([\s\S]*?)<\/item>/g)].slice(0,8).map(m=>{
  const block=m[1];
  const title=(block.match(/<title>([\s\S]*?)<\/title>/)?.[1]||'').replace(/<!\[CDATA\[|\]\]>/g,'').trim();
  const link=(block.match(/<link>([\s\S]*?)<\/link>/)?.[1]||'').trim();
  const source=(block.match(/<source[^>]*>([\s\S]*?)<\/source>/)?.[1]||'').replace(/<!\[CDATA\[|\]\]>/g,'').trim();
  return {title,link,source};
 }).filter(x=>x.title);
 if(!items.length)throw new Error('No headlines found.');
 return items;
}
// Free, no-API-key prayer times via Aladhan API.
async function prayerTimes(city,country){
 const c=String(city||'').trim(),co=String(country||'').trim();
 if(!c)throw new Error('Please provide a city (and optionally a country).');
 const url=`https://api.aladhan.com/v1/timingsByCity?city=${encodeURIComponent(c)}&country=${encodeURIComponent(co||'')}&method=2`;
 const r=await fetch(url,{headers:{'user-agent':'MR-DKxx/4.5'}});
 if(!r.ok)throw new Error('Prayer times service is unavailable right now.');
 const j=await r.json();
 if(j.code!==200||!j.data)throw new Error('Could not find prayer times for that location.');
 const t=j.data.timings;
 return {date:j.data.date?.readable||'',fajr:t.Fajr,dhuhr:t.Dhuhr,asr:t.Asr,maghrib:t.Maghrib,isha:t.Isha,place:`${c}${co?', '+co:''}`};
}
function bmi(weightKg,heightCm){
 const w=Number(weightKg),h=Number(heightCm)/100;
 if(!Number.isFinite(w)||w<=0||!Number.isFinite(h)||h<=0)throw new Error('Use: weight(kg) height(cm) — example: 70 175');
 const value=w/(h*h);
 const category=value<18.5?'Underweight':value<25?'Normal weight':value<30?'Overweight':'Obese';
 return {value:Math.round(value*10)/10,category};
}
function ageCalc(dob){
 const d=new Date(String(dob).trim());
 if(isNaN(d.getTime()))throw new Error('Use a date like: 1998-05-20 or 20/05/1998');
 const now=new Date();
 if(d>now)throw new Error('That date is in the future.');
 let years=now.getFullYear()-d.getFullYear(),months=now.getMonth()-d.getMonth(),days=now.getDate()-d.getDate();
 if(days<0){months--;days+=new Date(now.getFullYear(),now.getMonth(),0).getDate()}
 if(months<0){years--;months+=12}
 const totalDays=Math.floor((now-d)/86400000);
 return {years,months,days,totalDays};
}
// Free, no-API-key IP/domain lookup via ipapi.co.
async function ipLookup(query){
 const q=String(query||'').trim();
 const url=q?`https://ipapi.co/${encodeURIComponent(q)}/json/`:'https://ipapi.co/json/';
 const r=await fetch(url,{headers:{'user-agent':'MR-DKxx/4.5'}});
 if(!r.ok)throw new Error('IP lookup service is unavailable right now.');
 const j=await r.json();
 if(j.error)throw new Error(j.reason||'Could not look up that address.');
 return {ip:j.ip,city:j.city,region:j.region,country:j.country_name,isp:j.org||j.asn||'',timezone:j.timezone,lat:j.latitude,lon:j.longitude};
}
module.exports={qr,calc,isSafeUrl,urlInfo,uuid,password,hash,base64Encode,base64Decode,randomNumber,jsonFormat,timestamp,unitConvert,currencyConvert,weather,newsHeadlines,prayerTimes,bmi,ageCalc,ipLookup};

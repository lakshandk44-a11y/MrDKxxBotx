const fs=require('fs'),path=require('path');
const {GoogleGenAI}=require('@google/genai');
const {spawn}=require('child_process');
const {tmpDir}=require('../utils');
function env(n){return String(process.env[n]||'').trim()}
function timeoutMs(){return Math.max(5000,Number(process.env.AI_TIMEOUT_MS||90000))}
async function fetchWithTimeout(url,options={},ms=timeoutMs()){
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),ms);
 try{return await fetch(url,{...options,signal:controller.signal})}catch(e){if(e?.name==='AbortError')throw new Error(`Request timed out after ${Math.round(ms/1000)}s`);throw e}finally{clearTimeout(timer)}
}
function writeBinary(prefix,ct,data){ct=String(ct||'image/png').toLowerCase();const ext=ct.includes('jpeg')||ct.includes('jpg')?'jpg':ct.includes('webp')?'webp':'png';const out=path.join(tmpDir,`${prefix}-${Date.now()}-${Math.random().toString(16).slice(2)}.${ext}`);fs.writeFileSync(out,data);return out}
const GEMINI_IMAGE_DEFAULTS=['gemini-3.1-flash-image','gemini-3.1-flash-lite-image','gemini-3-pro-image','gemini-2.5-flash-image'];
function imageModels(){const raw=env('GEMINI_IMAGE_MODELS');return [...new Set((raw?raw.split(',').map(x=>x.trim()).filter(Boolean):GEMINI_IMAGE_DEFAULTS))]}
function imageChoices(){return [
 {id:'image_auto',label:'✨ Image Auto',provider:'auto',model:''},
 {id:'image_pollinations_flux',label:'🆓 Flux • Free (no key)',provider:'pollinations_free',model:'flux'},
 {id:'image_pollinations_turbo',label:'🆓 Turbo • Free (no key)',provider:'pollinations_free',model:'turbo'},
 {id:'image_together_flux_free',label:'🆓 FLUX Schnell • Together AI Free',provider:'together',model:env('TOGETHER_IMAGE_MODEL')||'black-forest-labs/FLUX.1-schnell-Free'},
 {id:'image_together_flux',label:'⚡ FLUX Schnell • Together AI',provider:'together',model:'black-forest-labs/FLUX.1-schnell'},
 {id:'image_stability_core',label:'🖼️ Stable Image Core • Stability AI',provider:'stability',model:'core'},
 {id:'image_stability_turbo',label:'🚀 SD 3.5 Large Turbo • Stability AI',provider:'stability',model:'sd3.5-large-turbo'},
 {id:'image_fal_flux',label:'⚡ FLUX Dev • fal.ai',provider:'fal',model:env('FAL_IMAGE_MODEL')||'fal-ai/flux/dev'},
 {id:'image_hf_flux',label:'🤗 FLUX • Hugging Face',provider:'huggingface',model:env('HF_IMAGE_MODEL')||'black-forest-labs/FLUX.1-schnell'},
 ...imageModels().map((model,i)=>({id:`image_gemini_${i}`,label:`🎨 Gemini • ${model}`,provider:'gemini',model}))
]}
function findImageChoice(id){return imageChoices().find(x=>x.id===id)||null}
function imageModelOrder(preferred=''){const all=imageModels();if(!preferred||preferred==='image_auto')return all;const idx=all.indexOf(preferred);return idx<0?all:[...all.slice(idx),...all.slice(0,idx)]}
async function geminiImage(prompt,preferredModel=''){
 const key=env('GEMINI_API_KEY');if(!key)throw new Error('Gemini image key is not configured.');const ai=new GoogleGenAI({apiKey:key});let last=null;
 for(const model of imageModelOrder(preferredModel))try{const isLite=/lite-image$/i.test(model);const config={responseModalities:['IMAGE'],responseFormat:{image:{aspectRatio:env('IMAGE_ASPECT_RATIO')||'1:1',...(isLite?{}:{imageSize:env('IMAGE_SIZE')||'1K'})}}};const response=await ai.models.generateContent({model,contents:prompt,config});for(const part of response.candidates?.[0]?.content?.parts||[]){if(!part.thought&&part.inlineData?.data)return {file:writeBinary('mrdkxx-gemini-image',part.inlineData.mimeType||'image/png',Buffer.from(part.inlineData.data,'base64')),provider:'Gemini',model}}throw new Error('Gemini image model returned no image data')}catch(e){last=e}
 throw last||new Error('All Gemini image models failed.')
}
async function togetherImage(prompt,model){
 const key=env('TOGETHER_API_KEY');if(!key)throw new Error('Together AI key is not configured.');const endpoint=env('TOGETHER_IMAGE_URL')||'https://api.together.ai/v1/images/generations';const body={model:model||env('TOGETHER_IMAGE_MODEL')||'black-forest-labs/FLUX.1-schnell-Free',prompt,n:1,width:Number(process.env.TOGETHER_IMAGE_WIDTH||1024),height:Number(process.env.TOGETHER_IMAGE_HEIGHT||1024),steps:Number(process.env.TOGETHER_IMAGE_STEPS||4)};const r=await fetchWithTimeout(endpoint,{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${key}`},body:JSON.stringify(body)},120000);const raw=await r.text();let j=null;try{j=JSON.parse(raw)}catch{}if(!r.ok)throw new Error(`Together AI HTTP ${r.status}${raw?`: ${raw.slice(0,280)}`:''}`);const item=j?.data?.[0];if(item?.b64_json)return {file:writeBinary('mrdkxx-together-image','image/png',Buffer.from(item.b64_json,'base64')),provider:'Together AI',model:body.model};const url=item?.url||item?.image_url;if(url){const img=await fetchWithTimeout(url,{},120000);if(!img.ok)throw new Error(`Together image download HTTP ${img.status}`);return {file:writeBinary('mrdkxx-together-image',img.headers.get('content-type')||'image/png',Buffer.from(await img.arrayBuffer())),provider:'Together AI',model:body.model}}throw new Error('Together AI returned no image data')
}
async function stabilityImage(prompt,model='core'){
 const key=env('STABILITY_API_KEY');if(!key)throw new Error('Stability AI key is not configured.');const endpoint=model==='core'?'https://api.stability.ai/v2beta/stable-image/generate/core':'https://api.stability.ai/v2beta/stable-image/generate/sd3';const form=new FormData();form.append('prompt',prompt);form.append('output_format',env('IMAGE_OUTPUT_FORMAT')||'png');form.append('aspect_ratio',env('IMAGE_ASPECT_RATIO')||'1:1');if(model!=='core')form.append('model',model);const r=await fetchWithTimeout(endpoint,{method:'POST',headers:{Authorization:`Bearer ${key}`,Accept:'image/*'},body:form},120000);if(!r.ok){const body=await r.text().catch(()=> '');throw new Error(`Stability AI HTTP ${r.status}${body?`: ${body.slice(0,280)}`:''}`)}return {file:writeBinary('mrdkxx-stability-image',r.headers.get('content-type')||'image/png',Buffer.from(await r.arrayBuffer())),provider:'Stability AI',model}
}

async function falImage(prompt,model){
 const key=env('FAL_KEY');if(!key)throw new Error('fal.ai key is not configured.');
 const endpoint=env('FAL_IMAGE_URL')||`https://fal.run/${model||env('FAL_IMAGE_MODEL')||'fal-ai/flux/dev'}`;
 const r=await fetchWithTimeout(endpoint,{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Key ${key}`},body:JSON.stringify({prompt})},120000);
 const raw=await r.text();let j=null;try{j=JSON.parse(raw)}catch{}
 if(!r.ok)throw new Error(`fal.ai HTTP ${r.status}${raw?`: ${raw.slice(0,280)}`:''}`);
 const item=j?.images?.[0]||j?.output?.images?.[0];const url=item?.url||j?.image?.url;if(!url)throw new Error('fal.ai returned no image URL');
 const img=await fetchWithTimeout(url,{},120000);if(!img.ok)throw new Error(`fal.ai image download HTTP ${img.status}`);
 return {file:writeBinary('mrdkxx-fal-image',img.headers.get('content-type')||'image/png',Buffer.from(await img.arrayBuffer())),provider:'fal.ai',model:model||env('FAL_IMAGE_MODEL')||'fal-ai/flux/dev'}
}
async function huggingFaceImage(prompt,model){
 const key=env('HF_TOKEN');if(!key)throw new Error('Hugging Face token is not configured.');
 const endpoint=env('HF_IMAGE_URL')||`https://router.huggingface.co/hf-inference/models/${encodeURIComponent(model||env('HF_IMAGE_MODEL')||'black-forest-labs/FLUX.1-schnell')}`;
 const r=await fetchWithTimeout(endpoint,{method:'POST',headers:{Authorization:`Bearer ${key}`,'Content-Type':'application/json'},body:JSON.stringify({inputs:prompt})},120000);
 if(!r.ok){const body=await r.text().catch(()=> '');throw new Error(`Hugging Face HTTP ${r.status}${body?`: ${body.slice(0,280)}`:''}`)}
 const ct=r.headers.get('content-type')||'';
 if(ct.startsWith('image/'))return {file:writeBinary('mrdkxx-hf-image',ct,Buffer.from(await r.arrayBuffer())),provider:'Hugging Face',model:model||env('HF_IMAGE_MODEL')||'black-forest-labs/FLUX.1-schnell'};
 const j=await r.json();const b=j?.generated_image||j?.data?.[0]?.b64_json;if(!b)throw new Error('Hugging Face returned no image data');return {file:writeBinary('mrdkxx-hf-image','image/png',Buffer.from(b,'base64')),provider:'Hugging Face',model:model||env('HF_IMAGE_MODEL')||'black-forest-labs/FLUX.1-schnell'}
}
async function vision(file,prompt='Describe this image clearly.'){
 const key=env('GEMINI_API_KEY');if(!key)throw new Error('Gemini API key is not configured for image understanding.');
 if(!fs.existsSync(file))throw new Error('Image file not found.');
 const ai=new GoogleGenAI({apiKey:key});const mime=file.toLowerCase().endsWith('.png')?'image/png':file.toLowerCase().endsWith('.webp')?'image/webp':'image/jpeg';const data=fs.readFileSync(file).toString('base64');
 const response=await ai.models.generateContent({model:env('GEMINI_VISION_MODEL')||'gemini-3.6-flash',contents:[{role:'user',parts:[{text:String(prompt||'Describe this image clearly.')},{inlineData:{mimeType:mime,data}}]}],config:{systemInstruction:env('AI_SYSTEM_PROMPT')||'You are MR DKxx. Analyze images accurately and answer in the user language when practical.'}});
 const text=response.text?.trim();if(!text)throw new Error('Vision model returned an empty response.');return text
}

async function pollinationsImage(prompt){if(env('POLLINATIONS_ENABLED').toLowerCase()!=='true')throw new Error('Pollinations image fallback is disabled');const key=env('POLLINATIONS_API_KEY');if(!key)throw new Error('Pollinations API key is not configured.');const endpoint=env('POLLINATIONS_IMAGE_URL')||env('IMAGE_PROVIDER_URL');if(!endpoint)throw new Error('Pollinations image endpoint is not configured.');const final=endpoint.includes('prompt=')?endpoint:`${endpoint}${endpoint.includes('?')?'&':'?'}prompt=${encodeURIComponent(prompt)}`;const r=await fetchWithTimeout(final,{headers:{Authorization:`Bearer ${key}`}},120000);if(!r.ok)throw new Error(`Pollinations image HTTP ${r.status}`);return {file:writeBinary('mrdkxx-pollinations-image',r.headers.get('content-type')||'image/png',Buffer.from(await r.arrayBuffer())),provider:'Pollinations',model:env('POLLINATIONS_IMAGE_MODEL')||'flux'}}
// Genuinely free, no-signup, no-API-key image generation via Pollinations' classic
// GET endpoint (image.pollinations.ai/prompt/...), distinct from their newer
// key-gated gen.pollinations.ai endpoint used by pollinationsImage() above. This is
// what makes "Image Auto" work out of the box even with zero API keys configured.
// Anonymous requests are rate-limited (~1 req/15s), so one short retry is attempted
// on a 429/"too many requests" style failure before giving up.
async function pollinationsFreeImage(prompt,model='flux'){
 const attempt=async()=>{
  const seed=Math.floor(Math.random()*1e9);
  const url=`https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=1024&height=1024&model=${encodeURIComponent(model||'flux')}&seed=${seed}&nologo=true`;
  const r=await fetchWithTimeout(url,{headers:{'user-agent':'MR-DKxx/4.5'}},120000);
  if(!r.ok){const err=new Error(`Pollinations (free) HTTP ${r.status}`);err.status=r.status;throw err}
  const buf=Buffer.from(await r.arrayBuffer());
  if(buf.length<500)throw new Error('Pollinations (free) returned an empty image.');
  return {file:writeBinary('mrdkxx-pollinations-free',r.headers.get('content-type')||'image/jpeg',buf),provider:'Pollinations (Free)',model:model||'flux'};
 };
 try{return await attempt()}
 catch(e){if(e.status===429||e.status===503){await new Promise(r=>setTimeout(r,4000));return attempt()}throw e}
}
async function customImage(prompt){const endpoint=env('IMAGE_PROVIDER_URL');if(!endpoint)throw new Error('Custom image provider is not configured.');const key=env('IMAGE_PROVIDER_API_KEY');const headers=key?{Authorization:`Bearer ${key}`} : {};const final=endpoint.includes('prompt=')?endpoint:`${endpoint}${endpoint.includes('?')?'&':'?'}prompt=${encodeURIComponent(prompt)}`;const r=await fetchWithTimeout(final,{headers},120000);if(!r.ok)throw new Error(`Custom image provider HTTP ${r.status}`);return {file:writeBinary('mrdkxx-custom-image',r.headers.get('content-type')||'image/png',Buffer.from(await r.arrayBuffer())),provider:'Custom',model:'custom'}}
// Only include a keyed provider in the automatic fallback chain if it actually has
// credentials configured. Previously every provider (including the always-unconfigured
// "custom" stub) was tried in order and whichever ran LAST overwrote the error message,
// so a real failure from the free default provider was hidden behind a useless
// "Custom image provider is not configured" message. Filtering here fixes that.
function configuredImageOrder(){
 const raw=env('IMAGE_PROVIDER_ORDER');
 if(raw)return [...new Set(raw.split(',').map(x=>x.trim().toLowerCase()).filter(Boolean))];
 const order=['pollinations_free'];
 if(env('STABILITY_API_KEY'))order.push('stability');
 if(env('GEMINI_API_KEY'))order.push('gemini');
 if(env('TOGETHER_API_KEY'))order.push('together');
 if(env('FAL_KEY'))order.push('fal');
 if(env('HF_TOKEN'))order.push('huggingface');
 if(env('POLLINATIONS_ENABLED').toLowerCase()==='true'&&env('POLLINATIONS_API_KEY'))order.push('pollinations');
 if(env('IMAGE_PROVIDER_URL'))order.push('custom');
 return order;
}
async function image(prompt,preferredModel='image_auto'){
 const cleanPrompt=String(prompt||'').trim();
 if(!cleanPrompt)throw new Error('Please describe what image you want (the text was empty).');
 const choice=findImageChoice(preferredModel);
 const errors=[];
 const verify=(result)=>{if(!result||!fs.existsSync(result.file))throw new Error('Image provider returned no usable image file.');const st=fs.statSync(result.file);if(!st.size)throw new Error('Image provider returned an empty image file.');return result.file};
 if(choice&&choice.provider!=='auto')try{if(choice.provider==='gemini')return verify(await geminiImage(cleanPrompt,choice.model));if(choice.provider==='together')return verify(await togetherImage(cleanPrompt,choice.model));if(choice.provider==='stability')return verify(await stabilityImage(cleanPrompt,choice.model));if(choice.provider==='fal')return verify(await falImage(cleanPrompt,choice.model));if(choice.provider==='huggingface')return verify(await huggingFaceImage(cleanPrompt,choice.model));if(choice.provider==='pollinations_free')return verify(await pollinationsFreeImage(cleanPrompt,choice.model))}catch(e){errors.push(`${choice.provider}: ${e.message}`)}
 // Always build the auto-fallback order with the free, no-key Pollinations provider
 // guaranteed to be present (first if nothing configured it, and appended as a last
 // resort even if a custom IMAGE_PROVIDER_ORDER left it out or a specific paid model
 // was picked and failed above). This is what makes "Image Auto" — and every other
 // choice, via fallback — actually produce an image even with zero/expired API keys.
 const configured=configuredImageOrder();
 const order=configured.includes('pollinations_free')?configured:[...configured,'pollinations_free'];
 for(const provider of order){
  if(choice&&choice.provider===provider&&choice.provider!=='auto')continue; // already tried above, don't repeat the same failure
  try{if(provider==='pollinations_free')return verify(await pollinationsFreeImage(cleanPrompt,'flux'));if(provider==='gemini')return verify(await geminiImage(cleanPrompt,''));if(provider==='together')return verify(await togetherImage(cleanPrompt,''));if(provider==='stability')return verify(await stabilityImage(cleanPrompt,'core'));if(provider==='fal')return verify(await falImage(cleanPrompt,''));if(provider==='huggingface')return verify(await huggingFaceImage(cleanPrompt,''));if(provider==='pollinations')return verify(await pollinationsImage(cleanPrompt));if(provider==='custom')return verify(await customImage(cleanPrompt))}catch(e){errors.push(`${provider}: ${e.message}`)}
 }
 if(!errors.length)throw new Error('Image generation is unavailable. Configure at least one image provider API key.');
 // Surface the FIRST (most relevant/default) failure prominently instead of
 // whichever provider happened to run last, plus a short trail of the rest.
 throw new Error(`${errors[0]}${errors.length>1?` (also tried ${errors.length-1} more: ${errors.slice(1).join(' | ')})`:''}`);
}
function providerStatus(){return [`Pollinations Free Image: ready (no key required)`,`Gemini Image: ${env('GEMINI_API_KEY')?'configured':'not configured'}`,`Together AI Image: ${env('TOGETHER_API_KEY')?'configured':'not configured'} • ${env('TOGETHER_IMAGE_MODEL')||'black-forest-labs/FLUX.1-schnell-Free'}`,`Stability AI Image: ${env('STABILITY_API_KEY')?'configured':'not configured'}`,`fal.ai Image: ${env('FAL_KEY')?'configured':'not configured'} • ${env('FAL_IMAGE_MODEL')||'fal-ai/flux/dev'}`,`Hugging Face Image: ${env('HF_TOKEN')?'configured':'not configured'} • ${env('HF_IMAGE_MODEL')||'black-forest-labs/FLUX.1-schnell'}`,`Pollinations Image (keyed): ${env('POLLINATIONS_ENABLED').toLowerCase()==='true'&&env('POLLINATIONS_API_KEY')?'enabled':'disabled'}`]}
async function windowsSapiTts(text){if(process.platform!=='win32')throw new Error('Windows SAPI is available only on Windows.');const wav=path.join(tmpDir,`mrdkxx-sapi-${Date.now()}.wav`);const safe=String(text||'').replace(/'/g,"''").replace(/[\r\n]+/g,' ');const ps=`Add-Type -AssemblyName System.Speech; $s=New-Object System.Speech.Synthesis.SpeechSynthesizer; $s.SetOutputToWaveFile('${wav.replace(/'/g,"''")}'); $s.Speak('${safe}'); $s.Dispose()`;await new Promise((resolve,reject)=>{const p=spawn('powershell.exe',['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-Command',ps],{windowsHide:true});let err='';p.stderr.on('data',d=>err+=d);p.on('error',reject);p.on('close',c=>c===0?resolve():reject(new Error(err.slice(-1200)||`PowerShell exited with ${c}`)))});const out=path.join(tmpDir,`mrdkxx-sapi-${Date.now()}.mp3`);await new Promise((resolve,reject)=>{const p=spawn(env('FFMPEG_PATH')||'ffmpeg',['-y','-i',wav,'-codec:a','libmp3lame','-q:a','4',out],{windowsHide:true});let err='';p.stderr.on('data',d=>err+=d);p.on('error',reject);p.on('close',c=>c===0?resolve():reject(new Error(err.slice(-1200)||`ffmpeg exited with ${c}`)))});try{fs.unlinkSync(wav)}catch{}return out}
async function tts(text){const url=env('TTS_PROVIDER_URL');if(url){const headers={'Content-Type':'application/json'};const key=env('TTS_PROVIDER_API_KEY');if(key)headers.Authorization=`Bearer ${key}`;const r=await fetchWithTimeout(url,{method:'POST',headers,body:JSON.stringify({text,voice:env('TTS_VOICE')||'default'})},120000);if(!r.ok)throw new Error(`TTS provider HTTP ${r.status}`);const ct=r.headers.get('content-type')||'';if(ct.startsWith('audio/'))return writeBinary('mrdkxx-tts',ct,Buffer.from(await r.arrayBuffer()));const j=await r.json();const b=j.audio_base64||j.b64_json||j.data?.[0]?.b64_json;if(!b)throw new Error('TTS provider returned no audio');const out=path.join(tmpDir,`mrdkxx-tts-${Date.now()}.mp3`);fs.writeFileSync(out,Buffer.from(b,'base64'));return out}
 try{return await windowsSapiTts(text)}catch(sapiError){const key=env('GEMINI_API_KEY');if(!key)throw new Error(`TTS unavailable: ${sapiError.message}`);const ai=new GoogleGenAI({apiKey:key});const voice=env('TTS_VOICE')||'Kore';const model=env('GEMINI_TTS_MODEL')||'gemini-3.1-flash-tts-preview';let last=sapiError;for(let attempt=1;attempt<=2;attempt++)try{const r=await ai.models.generateContent({model,contents:[{parts:[{text:`Speak naturally and clearly.\n\n${text}`}]}],config:{responseModalities:['AUDIO'],speechConfig:{voiceConfig:{prebuiltVoiceConfig:{voiceName:voice}}}}});const b64=r.candidates?.[0]?.content?.parts?.find(p=>p.inlineData?.data)?.inlineData?.data;if(!b64)throw new Error('Gemini TTS returned no audio data');const pcm=path.join(tmpDir,`mrdkxx-tts-${Date.now()}-${attempt}.pcm`),out=path.join(tmpDir,`mrdkxx-tts-${Date.now()}-${attempt}.mp3`);fs.writeFileSync(pcm,Buffer.from(b64,'base64'));await new Promise((resolve,reject)=>{const p=spawn(env('FFMPEG_PATH')||'ffmpeg',['-y','-f','s16le','-ar','24000','-ac','1','-i',pcm,'-codec:a','libmp3lame','-q:a','4',out],{windowsHide:true});let err='';p.stderr.on('data',d=>err+=d);p.on('error',reject);p.on('close',c=>c===0?resolve():reject(new Error(err.slice(-1200)||`ffmpeg exited with ${c}`)))});try{fs.unlinkSync(pcm)}catch{}return out}catch(e){last=e}throw last}}

async function runCommand(bin,args,ms=120000){return new Promise((resolve,reject)=>{const p=spawn(bin,args,{windowsHide:true});let out='',err='';const timer=setTimeout(()=>{try{p.kill()}catch{};reject(new Error('Local process timed out'))},ms);p.stdout.on('data',d=>out+=d);p.stderr.on('data',d=>err+=d);p.on('error',e=>{clearTimeout(timer);reject(e)});p.on('close',c=>{clearTimeout(timer);c===0?resolve(out):reject(new Error((err||out).slice(-1200)||`Process exited with ${c}`))})})}
async function localOcr(file){const bin=env('TESSERACT_PATH')||'tesseract';const lang=env('TESSERACT_LANG')||'eng';const out=await runCommand(bin,[file,'stdout','-l',lang],120000);if(!String(out).trim())throw new Error('Tesseract returned no text');return String(out).trim()}
async function localStt(file){const bin=env('WHISPER_PATH')||'whisper';const outDir=path.join(tmpDir,`whisper-${Date.now()}`);fs.mkdirSync(outDir,{recursive:true});const args=[file,'--model',env('WHISPER_MODEL')||'base','--output_format','txt','--output_dir',outDir];if(env('WHISPER_LANGUAGE'))args.push('--language',env('WHISPER_LANGUAGE'));await runCommand(bin,args,300000);const txt=fs.readdirSync(outDir).find(x=>x.toLowerCase().endsWith('.txt'));if(!txt)throw new Error('Whisper returned no transcript');const text=fs.readFileSync(path.join(outDir,txt),'utf8').trim();fs.rmSync(outDir,{recursive:true,force:true});if(!text)throw new Error('Whisper returned empty transcript');return text}

async function ocr(file){
 const url=env('OCR_PROVIDER_URL');
 if(url){try{const headers={};const key=env('OCR_PROVIDER_API_KEY');if(key)headers.Authorization=`Bearer ${key}`;const form=new FormData();form.append('file',new Blob([fs.readFileSync(file)]),path.basename(file));const r=await fetchWithTimeout(url,{method:'POST',headers,body:form},120000);if(!r.ok)throw new Error(`OCR provider HTTP ${r.status}`);const j=await r.json();return j.text||j.result||j.data?.text||JSON.stringify(j)}catch(e){try{return await localOcr(file)}catch{throw e}}}
 return localOcr(file)
}
async function stt(file){
 const url=env('STT_PROVIDER_URL');
 if(url){try{const headers={};const key=env('STT_PROVIDER_API_KEY');if(key)headers.Authorization=`Bearer ${key}`;const form=new FormData();form.append('file',new Blob([fs.readFileSync(file)]),path.basename(file));const r=await fetchWithTimeout(url,{method:'POST',headers,body:form},120000);if(!r.ok)throw new Error(`STT provider HTTP ${r.status}`);const j=await r.json();return j.text||j.transcript||j.data?.text||JSON.stringify(j)}catch(e){try{return await localStt(file)}catch{throw e}}}
 return localStt(file)
}
module.exports={image,imageModels,imageChoices,providerStatus,tts,ocr,stt,vision,togetherImage,stabilityImage,falImage,huggingFaceImage,pollinationsFreeImage};

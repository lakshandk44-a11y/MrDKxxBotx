const {spawn}=require('child_process');
const fs=require('fs'),path=require('path');
const {downloadDir,tmpDir,isUrl,logger}=require('../utils');
function run(bin,args,timeout=300000){return new Promise((resolve,reject)=>{const p=spawn(bin,args,{windowsHide:true});let out='',err='',settled=false;const finish=(fn,v)=>{if(settled)return;settled=true;clearTimeout(timer);fn(v)};const timer=setTimeout(()=>{try{p.kill()}catch{};finish(reject,new Error('Process timeout'))},timeout);p.stdout.on('data',d=>out+=d);p.stderr.on('data',d=>err+=d);p.on('error',e=>finish(reject,e));p.on('close',c=>c===0?finish(resolve,{out,err}):finish(reject,new Error((err||out).slice(-2200)||`process exited with ${c}`)))})}
function yt(){return process.env.YT_DLP_PATH||'yt-dlp'}
function ffmpeg(){return process.env.FFMPEG_PATH||'ffmpeg'}
// YouTube can reject the default "web" client with "Sign in to confirm you're not a
// bot". Listing several alternative player clients (comma-separated) lets yt-dlp try
// each internally per request — no cookies/login needed. This is free and works for
// most public videos; only some age-restricted/members-only videos still need cookies.
function extractorArgs(){
 const clients=process.env.YT_DLP_PLAYER_CLIENTS||'android,ios,tv_embedded,web_safari,mweb';
 return ['--extractor-args',`youtube:player_client=${clients}`];
}
// Optional: if the operator later gets access to a PC/Kiwi Browser and exports
// cookies.txt, dropping the path into YT_DLP_COOKIES_FILE (or COOKIES_FROM_BROWSER)
// still works alongside the player-client fallback above for the toughest videos.
// If nothing is explicitly set, we also auto-detect a cookies.txt bundled in data/
// so it "just works" once the operator drops a file there.
function cookieArgs(){
 const p=process.env.YT_DLP_COOKIES_FILE||process.env.COOKIES_FILE;
 if(p&&fs.existsSync(p))return ['--cookies',p];
 const browser=process.env.YT_DLP_COOKIES_FROM_BROWSER;
 if(browser)return ['--cookies-from-browser',browser];
 const bundled=path.join(require('../utils').dataDir,'cookies.txt');
 if(fs.existsSync(bundled))return ['--cookies',bundled];
 return [];
}
async function info(url){if(!isUrl(url))throw new Error('Invalid URL');const {out}=await run(yt(),['--no-playlist','--dump-single-json','--no-warnings',...extractorArgs(),...cookieArgs(),url],90000);let j;try{j=JSON.parse(out)}catch{throw new Error('yt-dlp returned invalid media information.')}return {title:j.title||'Media',duration:j.duration||0,uploader:j.uploader||'',thumbnail:j.thumbnail||'',url:j.webpage_url||url,ext:j.ext||'',width:j.width||0,height:j.height||0,filesize:j.filesize||j.filesize_approx||0}}
// yt-dlp search (no API key): "ytsearchN:query" returns the top N results without
// downloading anything, using --flat-playlist so it's fast (metadata only).
async function searchYoutube(query,limit=5){
 const q=String(query||'').trim();if(!q)throw new Error('Please provide a search term.');
 const n=Math.max(1,Math.min(10,Number(limit)||5));
 const {out}=await run(yt(),['--no-warnings','--flat-playlist','--dump-json',...extractorArgs(),...cookieArgs(),`ytsearch${n}:${q}`],60000);
 const items=String(out||'').split('\n').filter(Boolean).map(line=>{try{return JSON.parse(line)}catch{return null}}).filter(Boolean)
  .map(j=>({title:j.title||'Untitled',url:j.url||j.webpage_url||(j.id?`https://www.youtube.com/watch?v=${j.id}`:''),uploader:j.uploader||j.channel||'',duration:j.duration||0}))
  .filter(x=>x.url);
 if(!items.length)throw new Error('No results found for that search.');
 return items.slice(0,n);
}
// Several distinct player-client strategies are tried in sequence (not just one
// combined --extractor-args call) because YouTube's bot-check can reject the whole
// request before yt-dlp gets a chance to internally fall back between clients. After
// the first failure that looks like a bot-check/signature issue, we also try a single
// "yt-dlp -U" self-update — outdated yt-dlp builds are the single most common cause of
// these failures, since YouTube changes frequently and older builds lack the fix.
// Widened the strategy list: "web" and "web,mweb" are added because cookies are
// only honored by browser-style clients (web/mweb) — android/ios/tv_embedded largely
// ignore the cookie jar and rely on client spoofing alone, which YouTube has been
// closing off. Putting a cookie-aware client early gives the bundled cookies.txt an
// actual chance to matter instead of only helping the info()/search() calls.
const CLIENT_STRATEGIES=(process.env.YT_DLP_PLAYER_CLIENTS?[process.env.YT_DLP_PLAYER_CLIENTS]:['web,tv_embedded,android,ios,mweb','tv_embedded','web,mweb','android','ios','web_creator']);
async function selfUpdate(){try{await run(yt(),['-U'],90000)}catch{}}
async function attemptDownload(url,kind,quality,clients){
 const maxMb=Math.max(1,Number(process.env.MAX_DOWNLOAD_MB||100));
 const prefix=path.join(downloadDir,`mrdkxx-${Date.now()}-${Math.random().toString(16).slice(2)}`);const template=`${prefix}.%(ext)s`;
 const args=['--no-playlist','--no-warnings','--max-filesize',`${maxMb}M`,'-o',template,'--restrict-filenames','--retries','2','--fragment-retries','2','--no-part','--extractor-args',`youtube:player_client=${clients}`,...cookieArgs()];
 if(kind==='audio')args.push('-x','--audio-format','mp3','--audio-quality','0');
 else {const q=quality==='small'?'best[height<=480]/best':quality==='medium'?'best[height<=720]/best':'bestvideo*+bestaudio/best';args.push('-f',q,'--merge-output-format','mp4')}
 args.push(url);
 try{
  await run(yt(),args);
  const files=fs.readdirSync(downloadDir).filter(f=>f.startsWith(path.basename(prefix)+'.')&&!f.endsWith('.part')&&!f.endsWith('.ytdl'));
  if(!files.length)throw new Error('No output file was produced.');
  const file=path.join(downloadDir,files[0]);
  const mb=fs.statSync(file).size/1024/1024;
  if(mb>maxMb){cleanupPrefix(path.basename(prefix));throw new Error(`File is larger than ${maxMb} MB`)}
  return file;
 }catch(e){cleanupPrefix(path.basename(prefix));throw e}
}
// Generic "download anything" fallback: yt-dlp only understands ~1800 known sites.
// For everything else (direct file links — PDFs, ZIPs, images, raw MP4s, APKs, etc.,
// or a site yt-dlp has no extractor for), this streams the URL's raw bytes to disk
// with no API key and no site-specific logic needed. This is what makes "any URL ->
// download whatever it is" actually true instead of only covering yt-dlp's sites.
async function genericDownload(url){
 const maxMb=Math.max(1,Number(process.env.MAX_DOWNLOAD_MB||100));
 const maxBytes=maxMb*1024*1024;
 const r=await fetch(url,{redirect:'follow',headers:{'user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) MR-DKxx/4.5'}});
 if(!r.ok||!r.body)throw new Error(`Direct download failed: HTTP ${r.status}`);
 const len=Number(r.headers.get('content-length')||0);
 if(len&&len>maxBytes)throw new Error(`File is larger than ${maxMb} MB`);
 const ct=(r.headers.get('content-type')||'').split(';')[0].trim().toLowerCase();
 const urlExt=(()=>{try{const p=new URL(url).pathname;const e=path.extname(p).replace('.','').toLowerCase();return /^[a-z0-9]{1,5}$/.test(e)?e:''}catch{return ''}})();
 const ctExtMap={'video/mp4':'mp4','video/webm':'webm','video/quicktime':'mov','audio/mpeg':'mp3','audio/mp4':'m4a','audio/ogg':'ogg','audio/wav':'wav','image/jpeg':'jpg','image/png':'png','image/webp':'webp','image/gif':'gif','application/pdf':'pdf','application/zip':'zip','application/x-zip-compressed':'zip','text/plain':'txt','application/json':'json','application/vnd.android.package-archive':'apk','application/octet-stream':''};
 const ext=urlExt||ctExtMap[ct]||'bin';
 const file=path.join(downloadDir,`mrdkxx-direct-${Date.now()}-${Math.random().toString(16).slice(2)}.${ext}`);
 const ws=fs.createWriteStream(file);
 let written=0,exceeded=false;
 try{
  for await(const chunk of r.body){
   written+=chunk.length;
   if(written>maxBytes){exceeded=true;break}
   if(!ws.write(chunk))await new Promise(res=>ws.once('drain',res));
  }
 }finally{await new Promise(res=>ws.end(res))}
 if(exceeded){try{fs.unlinkSync(file)}catch{};throw new Error(`File is larger than ${maxMb} MB`)}
 if(!written){try{fs.unlinkSync(file)}catch{};throw new Error('The link returned no data.')}
 return {file,contentType:ct,ext};
}
async function download(url,kind='video',quality='best'){
 if(!isUrl(url))throw new Error('Invalid URL');
 let lastErr=null,updatedThisCall=false;
 for(let i=0;i<CLIENT_STRATEGIES.length;i++){
  try{return await attemptDownload(url,kind,quality,CLIENT_STRATEGIES[i])}
  catch(e){
   lastErr=e;
   const msg=String(e.message||'');
   const looksLikeBotCheck=/sign in|not a bot|precondition|player response|unable to extract|http error 403/i.test(msg);
   const unsupportedSite=/unsupported url|no extractor|unable to download webpage|is not a valid url/i.test(msg);
   // yt-dlp has no extractor for this link at all (a direct file, a site it doesn't
   // know, etc.) — stop the client-fallback loop immediately and hand off to the
   // generic raw-bytes downloader instead of wasting time retrying every client.
   if(unsupportedSite){
    try{const g=await genericDownload(url);return g.file}catch(e2){lastErr=e2;break}
   }
   // yt-dlp trails YouTube's anti-bot changes closely, so an outdated binary is the
   // single most common cause of this exact error. Try a self-update once per
   // download() call (not just once ever) the first time we see a bot-check-style
   // failure, then retry the SAME strategy again with the freshly updated binary.
   if(looksLikeBotCheck&&!updatedThisCall){
    updatedThisCall=true;
    await selfUpdate();
    try{return await attemptDownload(url,kind,quality,CLIENT_STRATEGIES[i])}catch(e2){lastErr=e2}
   }
   if(!looksLikeBotCheck&&!/format is not available|requested format/i.test(msg))break; // not a client-fallback-recoverable error, stop early
  }
 }
 if(lastErr){
  const msg=String(lastErr.message||'');
  if(/sign in|not a bot/i.test(msg)&&!/\[MR DKxx hint\]/.test(msg)){
   lastErr=new Error(`${msg}\n[MR DKxx hint] yt-dlp was auto-updated and retried but YouTube still blocked it. This almost always means the cookies.txt is stale or was exported on a different network/IP than this server. Re-export fresh cookies.txt while logged in to YouTube in a browser, then upload it again (or run the export from this same VPS's network if possible).`);
  }
 }
 // Last resort for anything still unresolved: try the raw-bytes path once more in
 // case the URL genuinely is a plain file yt-dlp merely reported a different error for.
 try{const g=await genericDownload(url);return g.file}catch{}
 throw lastErr||new Error('Download failed for an unknown reason.');
}
async function probe(file){if(!file||!fs.existsSync(file))throw new Error('Media file not found');const {out}=await run(ffmpeg(),['-hide_banner','-i',file],30000).catch(e=>({out:'',err:e.message}));const text=String(out||'');return {file:path.basename(file),size:fs.statSync(file).size,raw:text}}
async function transcode(input,{type='video',format='mp4',quality='medium'}={}){if(!fs.existsSync(input))throw new Error('Input media file not found');const out=path.join(tmpDir,`mrdkxx-${type}-${Date.now()}.${format}`);let args=['-y','-i',input];if(type==='video'){const vf=quality==='small'?'scale=-2:480':quality==='medium'?'scale=-2:720':'scale=1280:-2';args.push('-vf',vf,'-c:v','libx264','-preset','veryfast','-crf',quality==='small'?'30':quality==='medium'?'27':'24','-c:a','aac','-b:a','128k')}else if(type==='audio'){args.push('-vn','-c:a',format==='wav'?'pcm_s16le':'libmp3lame','-q:a','4')}else throw new Error('Unsupported transcode type');args.push(out);await run(ffmpeg(),args,180000);return out}
async function thumbnail(input){if(!fs.existsSync(input))throw new Error('Input media file not found');const out=path.join(tmpDir,`mrdkxx-thumb-${Date.now()}.jpg`);await run(ffmpeg(),['-y','-ss','00:00:01','-i',input,'-frames:v','1','-vf','scale=720:-2',out],60000);return out}
async function gif(input){if(!fs.existsSync(input))throw new Error('Input video not found');const out=path.join(tmpDir,`mrdkxx-${Date.now()}.gif`);await run(ffmpeg(),['-y','-t','6','-i',input,'-vf','fps=10,scale=480:-1:flags=lanczos',out],120000);return out}
async function audioExtract(input){return transcode(input,{type:'audio',format:'mp3'})}
function cleanup(file){try{if(file&&fs.existsSync(file))fs.unlinkSync(file)}catch(e){logger.warn(e.message,'cleanup failed')}}
function cleanupPrefix(prefix){for(const f of fs.readdirSync(downloadDir)){if(f.startsWith(prefix)){try{fs.unlinkSync(path.join(downloadDir,f))}catch{}}}}
module.exports={run,info,download,genericDownload,searchYoutube,probe,transcode,thumbnail,gif,audioExtract,cleanup,cleanupPrefix};

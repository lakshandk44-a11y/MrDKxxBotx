const fs=require('fs');
const path=require('path');
const assert=require('assert');

const root=path.resolve(__dirname,'..');
const menu=require(path.join(root,'src','services','menu'));

const items=[
  ['ai','AI','AI tools'],['media','Media','Media tools'],['back','Back']
];
const parsed=JSON.parse(menu.listParams('MR DKxx Menu',items));
assert.strictEqual(parsed.title,'MR DKxx Menu');
assert.deepStrictEqual(parsed.sections[0].rows.map(r=>r.id),['ai','media','back']);
assert.ok(parsed.sections[0].rows.every(r=>!Object.prototype.hasOwnProperty.call(r,'rowId')),'Native-flow rows must use id, not rowId');

const quick=JSON.parse(menu.quickParams('English','en'));
assert.deepStrictEqual(quick,{display_text:'English',id:'en'});

const bot=fs.readFileSync(path.join(root,'src','bot.js'),'utf8');
assert.ok(bot.includes("name:'single_select'"),'single_select native-flow button missing');
assert.ok(bot.includes('interactiveResponseMessage'),'native-flow response parser missing');
assert.ok(bot.includes('listResponseMessage'),'legacy list response parser missing');
assert.ok(bot.includes('templateButtonReplyMessage'),'legacy template response parser missing');
assert.ok(bot.includes('ephemeralMessage?.message'),'wrapped-message parser missing');

const requiredFiles=[
 'src/bot.js','src/index.js','src/db.js','src/group.js','src/i18n.js',
 'src/dashboard.js','src/utils.js','src/services/ai.js','src/services/media.js',
 'src/services/menu.js','src/services/providers.js','src/services/queue.js',
 'src/services/sticker.js','src/services/tools.js','package.json'
];
for(const rel of requiredFiles)assert.ok(fs.existsSync(path.join(root,rel)),`Missing ${rel}`);

const pkg=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));
assert.ok(pkg.dependencies['@whiskeysockets/baileys']);
assert.ok(pkg.dependencies['@google/genai']);
const ai=fs.readFileSync(path.join(root,'src','services','ai.js'),'utf8');
assert.ok(ai.includes('gemini-3.6-flash'),'Current Gemini model list missing');
assert.ok(ai.includes('Ollama'),'Local AI failover missing');
assert.ok(ai.includes('Pollinations'),'Pollinations failover missing');
assert.ok(bot.includes("choice==='local'"),'Local AI menu handler missing');
assert.ok(bot.includes('inFlightInputs'),'AI duplicate in-flight guard missing');
assert.ok(bot.includes('recentAiResponses'),'AI duplicate response guard missing');
assert.ok(bot.includes('recentInputs'),'duplicate input guard missing');
assert.ok(bot.includes('aiChains'),'per-chat AI ordering queue missing');
assert.ok(bot.includes("sendPresenceUpdate('composing'"),'typing presence optimization missing');
assert.ok(bot.includes('geminiModels'),'Gemini model menu integration missing');
assert.ok(ai.includes('trying next Gemini model'),'silent Gemini model failover missing');
assert.ok(ai.includes('options.geminiModel'),'selected Gemini model routing missing');
assert.ok(bot.includes("/aistatus"),'AI status command missing');


assert.ok(bot.includes('parseDkPrefix'),'DK prefix parser missing');
assert.ok(bot.includes('botPaused'),'bot pause state missing');
assert.ok(bot.includes("normalized==='stop'"),'stop command missing');
assert.ok(bot.includes("normalized==='resume'"),'resume command missing');
assert.ok(bot.includes("if(botPaused) continue"),'paused mode must ignore normal messages');
assert.ok(bot.includes("if(dkPayload!==null)"),'DK-only AI gate missing');
assert.ok(bot.includes("image_auto"),'Image Auto menu missing');
assert.ok(bot.includes('image_model_${i}'),'Gemini image model menu missing');
const providers=fs.readFileSync(path.join(root,'src','services','providers.js'),'utf8');
assert.ok(providers.includes('gemini-3.1-flash-image'),'Gemini 3.1 Flash Image missing');
assert.ok(providers.includes('gemini-3.1-flash-lite-image'),'Gemini 3.1 Flash Lite Image missing');
assert.ok(providers.includes('gemini-3-pro-image'),'Gemini 3 Pro Image missing');
assert.ok(providers.includes('gemini-2.5-flash-image'),'Gemini 2.5 Flash Image missing');
assert.ok(providers.includes('pollinationsImage'),'Pollinations image fallback missing');
assert.ok(providers.includes('imageModels'),'Image model list helper missing');

console.log('MR DKxx self-test: PASS');
console.log('Native-flow rows use id fields and response parsing covers native, list, template and wrapped messages.');

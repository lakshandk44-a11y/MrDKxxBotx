# MR DKxx WhatsApp Bot V4

A Windows VPS WhatsApp assistant built with Node.js 22, Baileys, SQLite, yt-dlp and FFmpeg.

## Quick start

1. Use Node.js 22 LTS on Windows.
2. Install Python, FFmpeg and yt-dlp.
3. Extract this project.
4. Copy `.env.example` to `.env`.
5. Add `GEMINI_API_KEY` if you want Gemini features.
6. Set `OWNER_JIDS` after using `/id` from the WhatsApp account.
7. Run `npm install`.
8. Run `npm run check`.
9. Run `npm run smoke` to verify installed modules.
10. Run `npm start` and scan the QR once from WhatsApp > Linked devices.

## Main features

- Sinhala/English native-flow menus with a numbered fallback
- MR DKxx logo/branding
- Duplicate-message protection and single-instance lock
- Gemini AI with model failover
- Optional Google Search grounding
- AI summarize/translate/analyze/rewrite/captions/hashtags
- Gemini native image generation with image-model fallback
- Pollinations text/image fallback
- Gemini native TTS fallback or external TTS provider
- Video/audio downloads through yt-dlp
- 480p/720p/best video and MP3 options
- Media info
- Sticker conversion using FFmpeg
- QR generator and safe calculator
- Group rules, admin checks, tag-all and stats
- SQLite history and usage tracking
- Health/status/ping/ID commands
- Queueing, download limits, cleanup and reconnect handling
- Local dashboard
- Optional STT/OCR adapters

## Gemini models

The default text list uses currently documented Gemini 3.x/2.5 models. Gemini 2.0 models are not included because the Gemini 2.0 Flash family was shut down on June 1, 2026. See Google's current model documentation before pinning a model for long-term production use.

## Notes

Provider-dependent features require their relevant API key/URL. The bot does not bypass DRM, private-content authentication, paywalls or platform restrictions. Download only content you are authorized to download and respect copyright/platform terms.

# Downloads

The downloader now uses **two engines**, tried automatically:

1. **Cobalt engine** (new, no install needed) — for YouTube, TikTok, Instagram,
   Facebook, Twitter/X, Reddit, SoundCloud, Vimeo, Pinterest, Tumblr, Twitch
   clips, Streamable, Dailymotion, Bilibili, VK and Snapchat. It queries
   https://cobalt.directory (a live, auto-updated list of independently-run
   free Cobalt instances) and resolves the direct media URL through whichever
   instance currently works, then downloads it. No API key, no yt-dlp/ffmpeg
   required for this path. Because instances are run by many different
   people, this routes around the datacenter-IP bot-checks that a single
   yt-dlp binary on a VPS often hits.
2. **yt-dlp + ffmpeg** (fallback, and the primary engine for the ~1800 other
   sites yt-dlp supports that Cobalt doesn't cover).

If the Cobalt engine fails for a request (an instance is temporarily down,
etc.), the bot automatically falls back to yt-dlp — no user action needed.

Supported choices:

- Video — Best available
- Video — 480p target
- Video — 720p target
- Audio — MP3
- Media info

Configuration:

```env
MAX_DOWNLOAD_MB=100
MAX_CONCURRENT_JOBS=2
YT_DLP_PATH=yt-dlp
FFMPEG_PATH=ffmpeg
```

The bot refuses files larger than the configured limit and cleans temporary output after sending.

Only download content you are legally authorized to download. The bot does not bypass DRM, paywalls, private content or authentication controls.

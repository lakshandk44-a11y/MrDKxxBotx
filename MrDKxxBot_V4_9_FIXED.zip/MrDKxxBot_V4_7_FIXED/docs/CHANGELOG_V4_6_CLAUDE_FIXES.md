# MR DKxx — V4.6 Fix & Feature Pack

## 🐛 Bug fixes

### 1. Downloads producing unplayable `.bin` files
`media.js` had a "last resort" fallback that fetched a URL's raw bytes if every
yt-dlp download attempt failed. For real video sites (YouTube, etc.) that
fallback was fetching the **webpage HTML** (because yt-dlp had already failed
to extract the actual video), and since there's no matching content-type it
was saved as `mrdkxx-direct-....bin` — a broken file that can never play.

**Fix:** `genericDownload()` now checks the response `content-type` and
throws immediately if it's `text/html` (a webpage, not a file). This means
the fallback no longer masks the real failure — the user now gets yt-dlp's
actual error message (e.g. the bot-check/cookie hint) instead of a fake
"successful" download that doesn't work.

### 2. "Send your text now" → image generated with empty prompt
Selecting an item from a numbered menu (e.g. "1" for Image Auto) leaves that
menu's number→choice mapping (`fallbackMenus`) in memory. That mapping was
never cleared when moving into a mode that expects free text (like "now send
what you want to draw"). If the next reply was a bare 1–2 digit number — or
the same digit got sent again — it was silently re-interpreted as the OLD
menu choice instead of the actual answer, which re-triggered the menu and
then generated an image from an empty/stale prompt.

**Fix:** the stale menu mapping is now cleared the moment any choice is
acted on (`bot.js`, main message loop). A fresh menu still repopulates it
immediately, so normal menu navigation is unaffected.

### 3. Free image options (Flux/Turbo via Pollinations) didn't respond at all
The choice router only recognized image options matching a hand-written
regex (`gemini_`, `together_`, `stability_`, `fal_`, `hf_`) — it never
matched `image_pollinations_flux` / `image_pollinations_turbo`, so tapping
those menu items did nothing.

**Fix:** the router now checks against the live `imageChoices()` list, so
every current (and future) image provider option works automatically.

## ✨ New free features (no API key required)

Added under **Tools → 🎉 Fun & Games**:
- 😂 Dad Joke — icanhazdadjoke.com
- 💬 Random Quote — ZenQuotes
- 🎱 Magic 8-Ball — ask a yes/no question
- 🎲 Roll Dice — `<sides> <count>`, e.g. `20 2`
- 🪙 Coin Flip
- 🐶 Random Dog Pic — dog.ceo
- 🐱 Random Cat Pic — TheCatAPI

All use free public endpoints with no signup/API key, matching the rest of
the bot's zero-config philosophy.

## V4.7 — second free-feature batch

Added under **Tools → 🎉 Fun & Games**:
- 🧠 Random Advice — adviceslip.com
- ❓ Trivia Question (with shuffled multiple-choice + answer) — Open Trivia DB
- 🔢 Number Fact — numbersapi.com (send a number, or anything for a random fact)
- 🥋 Chuck Norris Joke — api.chucknorris.io

Added under **Tools → 🔧 Quick Tools**:
- ✂️ Shorten URL — is.gd (free, no key)
- 📝 Word/Char Count — local, no network
- 🔠 Text Case Converter — UPPER / lower / Title Case / Sentence case, local, no network

All free, no signup/API key required.

require('dotenv').config();
const fs=require('fs');
const path=require('path');
const {startBot}=require('./bot');
const {startDashboard}=require('./dashboard');
const {logger}=require('./utils');

const lockPath=path.resolve(process.env.INSTANCE_LOCK_FILE||'data/mrdkxx.pid');
function processExists(pid){try{process.kill(Number(pid),0);return true}catch{return false}}
function acquireLock(){
 fs.mkdirSync(path.dirname(lockPath),{recursive:true});
 try{fs.writeFileSync(lockPath,String(process.pid),{flag:'wx'});return true}catch(e){
  if(e.code!=='EEXIST')throw e;
  let oldPid='';try{oldPid=fs.readFileSync(lockPath,'utf8').trim()}catch{}
  if(oldPid&&processExists(oldPid))throw new Error(`Another MR DKxx instance is already running (PID ${oldPid}). Stop it before starting a second copy.`);
  try{fs.unlinkSync(lockPath)}catch{}
  fs.writeFileSync(lockPath,String(process.pid),{flag:'wx'});return true;
 }
}
function releaseLock(){try{if(fs.readFileSync(lockPath,'utf8').trim()===String(process.pid))fs.unlinkSync(lockPath)}catch{}}

(async()=>{
 acquireLock();
 process.once('exit',releaseLock);
 process.once('SIGINT',()=>{releaseLock();process.exit(0)});
 process.once('SIGTERM',()=>{releaseLock();process.exit(0)});
 // Loud, impossible-to-miss startup check: the #1 cause of "downloads don't
 // work" reports is yt-dlp/ffmpeg simply not being installed or not on PATH on
 // the VPS. Warn clearly in the console every single start (not just during
 // the one-time install script) so it's caught immediately, before any user
 // complains that downloads are broken.
 try{
  const {checkBinaries}=require('./services/media');
  const bins=await checkBinaries(true);
  if(!bins.ytdlp||!bins.ffmpeg){
   const missing=[!bins.ytdlp?'yt-dlp':null,!bins.ffmpeg?'ffmpeg':null].filter(Boolean).join(' & ');
   logger.warn('='.repeat(60));
   logger.warn(`DOWNLOAD FEATURE WILL NOT WORK: ${missing} not found on PATH.`);
   logger.warn(`Set YT_DLP_PATH / FFMPEG_PATH in .env, or install ${missing} and`);
   logger.warn(`add it to PATH, then restart. See docs/SETUP.md.`);
   logger.warn('='.repeat(60));
  }else{
   logger.info('yt-dlp and ffmpeg detected OK — downloads are ready.');
  }
 }catch(e){logger.warn({err:e.message},'Startup binary check failed to run')}
 await startBot();
 startDashboard();
})().catch(e=>{releaseLock();logger.error(e);process.exit(1)});

const baileys=require('@whiskeysockets/baileys');
const {default:makeWASocket,useMultiFileAuthState,DisconnectReason,generateWAMessageFromContent,proto}=baileys;
const qrcode=require('qrcode-terminal');
const P=require('pino');
const fs=require('fs'),path=require('path');
const {logger,safeText}=require('./utils');
const db=require('./db');
const {t,change}=require('./i18n');
const {askAI,askWeb,providerStatus,geminiModels}=require('./services/ai');
const media=require('./services/media');
const {qr,calc,isSafeUrl,timestamp,unitConvert}=require('./services/tools');
const {image,tts,ocr,stt,vision,imageChoices,imageModels,providerStatus:imageProviderStatus}=require('./services/providers');
const sticker=require('./services/sticker');
const {downloadContentFromMessage}=baileys;
const {stats,clearHistory}=db;
const {JobQueue}=require('./services/queue');
const {isGroup,isOwner,isAdmin}=require('./group');

const AUTH_DIR=path.resolve(process.env.AUTH_DIR||'auth/mrdkxx');
const LOGO=path.resolve('assets/mr-dkxx-logo.png');
const sessions=new Map();
const fallbackMenus=new Map();
const seenMessages=new Map();
const recentInputs=new Map();
const inFlightInputs=new Set();
const aiBusyByJid=new Map();
const aiChains=new Map();
const recentAiResponses=new Map();
const logoSent=new Set();
let reconnectTimer=null;
let botPaused=false;
const queue=new JobQueue(Number(process.env.MAX_CONCURRENT_JOBS||2));
const startedAt=Date.now();

const {normalizeText,listParams,quickParams,nativeFlow}=require('./services/menu');
function row(id,title,description=''){return {title:String(title).slice(0,60),description:String(description).slice(0,72),rowId:id}}
function sessionKey(j,m){
 const actor=m?.key?.participant||m?.participant||j;
 return isGroup(j)?`${j}|${actor}`:j;
}
function buildMixedNativeFlowBizNode(){
 const privacy=(Math.floor(Date.now()/1000)-77980457).toString();
 return {tag:'biz',attrs:{actual_actors:'2',host_storage:'2',privacy_mode_ts:privacy},content:[
  {tag:'interactive',attrs:{type:'native_flow',v:'1'},content:[{tag:'native_flow',attrs:{v:'9',name:'mixed'}}]},
  {tag:'quality_control',attrs:{source_type:'third_party'}}
 ]};
}
function legacyListSections(items){
 const sections=[];
 for(let i=0;i<items.length;i+=10){
  sections.push({
   title:'MR DKxx',
   rows:items.slice(i,i+10).map(x=>({
    title:String(x[1]).slice(0,24),
    description:String(x[2]||'').slice(0,72),
    rowId:String(x[0])
   }))
  });
 }
 return sections;
}
async function sendLegacyGroupMenu(sock,jid,body,items,{title='Select',footer='MR DKxx',quick=false,stateKey}={}){
 // Native-flow messages can be rendered as "unsupported message" on older or
 // modified WhatsApp clients. Groups can contain mixed client versions, so
 // use WhatsApp's older list/button message format for group menus. This keeps
 // the same IDs and response parser while avoiding the client-version failure.
 if(quick){
  const buttons=items.slice(0,3).map(x=>({
   buttonId:String(x[0]),
   buttonText:{displayText:String(x[1]).slice(0,20)},
   type:1
  }));
  await sock.sendMessage(jid,{text:normalizeText(body),footer:normalizeText(footer||'MR DKxx'),buttons,headerType:1});
 }else{
  await sock.sendMessage(jid,{
   text:normalizeText(body),
   footer:normalizeText(footer||'MR DKxx'),
   title:String(title).slice(0,24),
   buttonText:String(title).slice(0,20),
   listType:1,
   sections:legacyListSections(items)
  });
 }
 fallbackMenus.delete(stateKey);
 return true;
}
function formatGroupMenu(title,body,footer,items){
 // Plain-text menu, formatted with WhatsApp's own markdown (*bold*, _italic_)
 // so it looks clean and organized while rendering identically for every
 // member of the group, on every WhatsApp client/version. Note: WhatsApp only
 // renders *bold*/_italic_ when there is no whitespace touching the markers,
 // so padding/spacing must always sit outside the marker characters.
 const LINE='┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈';
 const cleanTitle=String(title||'MR DKxx').replace(/\s*menu\s*$/i,'').trim();
 const heading=`*✨ ${cleanTitle}*`;
 const rows=items.map((x,i)=>{
  // No whitespace touching the * markers, or WhatsApp won't render bold.
  const label=String(x[1]||'').trim();
  const desc=x[2]?`\n      _${x[2]}_`:'';
  return `*${i+1}.* ${label}${desc}`;
 });
 const footerLine=footer?`\n${LINE}\n_${normalizeText(footer)}_`:'';
 return [
  heading,
  LINE,
  normalizeText(body),
  LINE,
  '',
  rows.join('\n\n'),
  footerLine,
  '',
  '👉 _Reply with the number of your choice / ඔබට අවශ්‍ය අංකය reply කරන්න._'
 ].filter(x=>x!==null&&x!==undefined).join('\n').replace(/\n{3,}/g,'\n\n');
}
async function sendInteractive(sock,jid,body,items,{title='Select',footer='MR DKxx',quick=false,stateKeyArg=null}={}){
 const stateKey=stateKeyArg||jid;
 // HARD GROUP COMPATIBILITY RULE: NEVER send native-flow OR legacy list/button
 // messages to a group. Both formats can silently render as "You received a
 // message but your version of WhatsApp doesn't support it" on some group
 // members' clients even though sock.sendMessage() does not throw an error
 // (so a try/catch around the legacy send can never detect the failure).
 // Groups therefore always get the plain numbered-text menu, which renders
 // identically on every WhatsApp client and mirror-shows the same content to
 // everyone in the group, including the person who tapped the menu.
 if(isGroup(jid)){
  try{
   fallbackMenus.set(stateKey,items.map((x,i)=>({number:String(i+1),id:String(x[0])})));
   await sock.sendMessage(jid,{text:formatGroupMenu(title,body,footer,items)});
   return true;
  }catch(e){
   logger.error({err:e.message},'Group menu send failed');
   return false;
  }
 }
 try{
  const rawButtons=quick
   ? items.slice(0,3).map(x=>({name:'quick_reply',buttonParamsJson:quickParams(x[1],x[0])}))
   : [{name:'single_select',buttonParamsJson:listParams(title,items)}];
  const interactive=proto.Message.InteractiveMessage.create({
   header:proto.Message.InteractiveMessage.Header.create({title:'MR DKxx',hasMediaAttachment:false}),
   body:proto.Message.InteractiveMessage.Body.create({text:normalizeText(body)}),
   footer:proto.Message.InteractiveMessage.Footer.create({text:normalizeText(footer||'Mr DKxx')}),
   nativeFlowMessage:proto.Message.InteractiveMessage.NativeFlowMessage.create({
    buttons:rawButtons.map(b=>proto.Message.InteractiveMessage.NativeFlowMessage.NativeFlowButton.create(b)),
    messageParamsJson:'{}',
    messageVersion:1
   })
  });
  const msg=generateWAMessageFromContent(jid,{
   messageContextInfo:{deviceListMetadata:{},deviceListMetadataVersion:2},
   interactiveMessage:interactive
  },{userJid:sock.user?.id});
  const botNode={tag:'bot',attrs:{biz_bot:'1'}};
  const bizNode=buildMixedNativeFlowBizNode();
  await sock.relayMessage(jid,msg.message,{messageId:msg.key.id,additionalNodes:[botNode,bizNode]});
  fallbackMenus.delete(stateKey);
  return true;
 }catch(e){
  logger.warn({err:e.message,stack:e.stack},'Interactive menu failed; using single-message numbered fallback');
  try{
   fallbackMenus.set(stateKey,items.map((x,i)=>({number:String(i+1),id:String(x[0])})));
   const lines=items.map((x,i)=>`${i+1}. ${x[1]}${x[2]?` — ${x[2]}`:''}`);
   await sock.sendMessage(jid,{text:`${normalizeText(body)}\n\n${lines.join('\n')}\n\nReply with the number of your choice.`});
   return true;
  }catch(e2){logger.error({err:e2.message},'Menu fallback failed');return false}
 }
}
async function sendLogo(sock,jid){
 try{
  if(!fs.existsSync(LOGO)) return false;
  await sock.sendMessage(jid,{image:fs.readFileSync(LOGO),caption:`✨ MR DKxx\n${t(jid,'welcome')}\n\n${t(jid,'choose')}`});
  return true;
 }catch(e){logger.warn({err:e.message},'Logo send failed');return false}
}
function homeItems(j){return [
 ['ai',t(j,'ai'),'Gemini, local AI, web search, vision and smart text tools'],['media',t(j,'media'),'Video, audio, media info and sticker tools'],['music',t(j,'music'),'MP3/audio downloads'],['image',t(j,'image'),'Generate images and image prompts'],['tools',t(j,'tools'),'QR, calculator, URL, OCR, STT, conversions and health'],['group',t(j,'group'),'Group tools and admin utilities'],['downloads',t(j,'downloads'),'Download from public/authorized URLs'],['settings',t(j,'settings'),'Language and bot settings'],['help',t(j,'help'),'Help and supported features'],['owner',t(j,'ownerMenu'),'Owner/admin tools']
]}
function geminiItems(j){
 const list=geminiModels();
 return [
  ['gemini_auto','✨ Gemini Auto','Tries the configured Gemini models silently in order'],
  ...list.map((x)=>[x.id,`🧠 ${x.name}`,'Chat with this Gemini model; silent failover to the next one']),
  ['back',t(j,'back')]
 ];
}
function subItems(j,type){const M={
 ai:[['gemini',t(j,'gemini')],['chat',t(j,'chat')],['local',t(j,'local')],['aistatus',t(j,'aistatus')],['websearch',t(j,'websearch')],['vision',t(j,'vision')],['summarize',t(j,'summarize')],['translate',t(j,'translate')],['analyze',t(j,'analyze')],['grammar',t(j,'grammar')],['coding',t(j,'coding')],['caption',t(j,'caption')],['hashtags',t(j,'hashtags')],['rewrite',t(j,'rewrite')],['imageai',t(j,'imageai')],['back',t(j,'back')]],
 media:[['video',t(j,'video')],['audio',t(j,'audio')],['info',t(j,'info')],['compress_video',t(j,'compressVideo')],['audio_convert',t(j,'audioConvert')],['thumbnail',t(j,'thumbnail')],['gif',t(j,'gif')],['sticker',t(j,'sticker')],['back',t(j,'back')]],
 music:[['audio',t(j,'audio')],['info',t(j,'info')],['back',t(j,'back')]],
 image:[['imageGen',t(j,'imageGen')],['imageModels',t(j,'imageModels')],['imageStatus',t(j,'imageStatus')],['imageai',t(j,'imageai')],['back',t(j,'back')]],
 tools:[['qr',t(j,'qr')],['calc',t(j,'calc')],['url',t(j,'url')],['tts',t(j,'tts')],['ocr',t(j,'ocr')],['stt',t(j,'stt')],['unit',t(j,'unit')],['timestamp',t(j,'timestamp')],['uuid',t(j,'uuid')],['password',t(j,'password')],['hash',t(j,'hash')],['base64',t(j,'base64')],['json',t(j,'json')],['random',t(j,'random')],['myid',t(j,'myid')],['health',t(j,'health')],['status',t(j,'status')],['back',t(j,'back')]],
 group:[['rules',t(j,'rules')],['setrules','📝 Set Rules'],['admins',t(j,'admins')],['groupStats',t(j,'groupStats')],['warnings',t(j,'warnings')],['tagall',t(j,'tagall')],['moderation',t(j,'moderation')],['back',t(j,'back')]],
 settings:[['language',t(j,'language')],['clear',t(j,'clear')],['status',t(j,'status')],['back',t(j,'back')]],
 owner:[['stats',t(j,'stats')],['backup',t(j,'backup')],['health',t(j,'health')],['back',t(j,'back')]]
};return M[type]||[]}
async function home(sock,j,m){
 if(!logoSent.has(j)){if(await sendLogo(sock,j))logoSent.add(j)}
 return sendInteractive(sock,j,`✨ MR DKxx\n\n${t(j,'choose')}`,homeItems(j),{title:'MR DKxx Menu',footer:'Mr DKxx • Main Menu',stateKeyArg:sessionKey(j,m)});
}
async function submenu(sock,j,type,m){return sendInteractive(sock,j,`✨ MR DKxx\n\n${t(j,type)}`,subItems(j,type),{title:`${type} menu`,footer:'Mr DKxx • Menu',stateKeyArg:sessionKey(j,m)})}
async function geminiMenu(sock,j,m){return sendInteractive(sock,j,`✨ Gemini\n\n${t(j,'geminiChoose')}`,geminiItems(j),{title:'Gemini Models',footer:'MR DKxx • Silent failover',stateKeyArg:sessionKey(j,m)})}
function imageModelNames(){return imageModels()}
function imageItems(j){return [...imageChoices().map(x=>[x.id,x.label,x.provider==='auto'?'Tries configured image providers silently':`Generate with ${x.provider}; safe failover is enabled`]),['back',t(j,'back')]]}
async function imageMenu(sock,j,m){return sendInteractive(sock,j,`🎨 Image AI\n\n${t(j,'imageChoose')}`,imageItems(j),{title:'Image Models',footer:'MR DKxx • Silent failover',stateKeyArg:sessionKey(j,m)})}
async function languageMenu(sock,j,m){return sendInteractive(sock,j,t(j,'chooseLang'),[['si',t(j,'si')],['en',t(j,'en')]],{title:'Language',quick:true,stateKeyArg:sessionKey(j,m)})}
async function sendText(sock,j,text){return sock.sendMessage(j,{text:normalizeText(String(text))})}
async function prompt(sock,j,mode,kind,m){sessions.set(sessionKey(j,m),{mode,kind});if(mode==='vision')return sendText(sock,j,'🖼️ Please send an image now. You can add a question/caption.');if(mode==='ocr')return sendText(sock,j,'🖼️ Please send an image or document now.');if(mode==='stt')return sendText(sock,j,'🎙️ Please send a voice/audio message now.');if(mode==='mediaTool')return sendText(sock,j,'📎 Please send the media file now.');return sendText(sock,j,t(j,'sendPrompt'))}
async function sendDownloadMenu(sock,j,url,m){sessions.set(sessionKey(j,m),{mode:'download',url});return sendInteractive(sock,j,`🔗 ${url}\n\nChoose download type:`,[['video_best','🎬 Video • Best'],['video_small','📱 Video • 480p'],['video_medium','📺 Video • 720p'],['audio_mp3','🎵 Audio • MP3'],['back',t(j,'back')]],{title:'Download',footer:'Mr DKxx • Downloader',stateKeyArg:sessionKey(j,m)})}
function unwrapMessage(message){
 let msg=message||{};
 // WhatsApp may wrap incoming messages in ephemeral/view-once containers.
 for(let i=0;i<6;i++){
  const next=msg.ephemeralMessage?.message||msg.viewOnceMessage?.message||msg.viewOnceMessageV2?.message||msg.documentWithCaptionMessage?.message||msg.editedMessage?.message;
  if(!next||next===msg)break;
  msg=next;
 }
 return msg;
}
function getIncomingText(m){
 const msg=unwrapMessage(m.message);
 return (msg.conversation||msg.extendedTextMessage?.text||msg.imageMessage?.caption||msg.videoMessage?.caption||msg.documentMessage?.caption||msg.interactiveMessage?.body?.text||msg.interactiveResponseMessage?.body?.text||'').trim();
}
function mediaKind(m){const msg=unwrapMessage(m?.message);if(msg?.imageMessage)return 'image';if(msg?.videoMessage)return 'video';if(msg?.audioMessage)return 'audio';if(msg?.documentMessage)return 'document';return null}
async function saveIncomingMedia(m){const kind=mediaKind(m);if(!kind)throw new Error('Please send an image, video, audio or document.');const msg=unwrapMessage(m.message)[`${kind}Message`];const stream=await downloadContentFromMessage(msg,kind);const mime=String(msg.mimetype||'').toLowerCase();const ext=mime.includes('png')?'.png':mime.includes('webp')?'.webp':mime.includes('jpeg')||mime.includes('jpg')?'.jpg':mime.includes('mp4')?'.mp4':mime.includes('pdf')?'.pdf':kind==='audio'?'.ogg':kind==='video'?'.mp4':kind==='image'?'.jpg':'';const input=path.join(require('./utils').tmpDir,`upload-${Date.now()}-${Math.random().toString(16).slice(2)}${ext}`);fs.mkdirSync(path.dirname(input),{recursive:true});const ws=fs.createWriteStream(input);for await(const chunk of stream)ws.write(chunk);await new Promise((resolve,reject)=>{ws.on('finish',resolve);ws.on('error',reject);ws.end()});return {kind,input,mime}}
function getChoice(m){
 const msg=unwrapMessage(m.message);
 const a=msg.buttonsResponseMessage?.selectedButtonId||msg.listResponseMessage?.singleSelectReply?.selectedRowId||msg.templateButtonReplyMessage?.selectedId;
 if(a)return String(a);
 const p=msg.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson;
 if(p){
  try{
   const j=typeof p==='string'?JSON.parse(p):p;
   return j?.id||j?.selected_id||j?.row_id||j?.selectedRowId||j?.selected_id?.id||j?.params?.id||null;
  }catch{}
 }
 return null;
}
function getFallbackChoice(key,text){const n=String(text||'').trim();if(!/^\d{1,2}$/.test(n))return null;return fallbackMenus.get(key)?.find(x=>x.number===n)?.id||null}
function parseDkPrefix(text){
 const raw=String(text||'').normalize('NFKC');
 const m=raw.match(/^\s*d[\s._-]*k(?:\s*[:,-]\s*|\s+|$)/iu);
 if(!m)return null;
 return raw.slice(m[0].length).trim();
}
function actorJid(m,j){return m?.key?.participant||j}
function duration(sec){sec=Number(sec||0);if(!sec)return '-';const h=Math.floor(sec/3600),m=Math.floor(sec%3600/60),s=Math.floor(sec%60);return h?`${h}h ${m}m ${s}s`:`${m}m ${s}s`}
async function requireGroupAdmin(sock,j,m){if(!isGroup(j)){await sendText(sock,j,t(j,'onlyGroup'));return false}const sender=m.key.participant||m.key.remoteJid;if(!await isAdmin(sock,j,sender)){await sendText(sock,j,t(j,'admin'));return false}return true}
async function executeDownload(sock,j,s,choice,m){const kind=choice==='audio_mp3'?'audio':'video';const quality=choice==='video_small'?'small':choice==='video_medium'?'medium':'best';await sendText(sock,j,'⏳ Downloading...');let file=null;try{file=await queue.add(()=>media.download(s.url,kind,quality));const stat=fs.statSync(file);const max=Number(process.env.MAX_DOWNLOAD_MB||100)*1024*1024;if(stat.size>max)throw new Error(t(j,'fileTooLarge'));const caption=`✨ MR DKxx\n${kind==='audio'?'🎵':'🎬'} ${path.basename(file)}`;if(kind==='audio')await sock.sendMessage(j,{audio:fs.readFileSync(file),mimetype:'audio/mpeg',fileName:path.basename(file),caption});else await sock.sendMessage(j,{video:fs.readFileSync(file),mimetype:'video/mp4',fileName:path.basename(file),caption});db.usage(j,`download_${kind}`)}finally{media.cleanup(file);sessions.delete(sessionKey(j,m))}}
async function runAi(sock,j,text,label='ai',provider='auto',geminiModel='',stateJid=j){
 const clean=String(text||'').trim().replace(/\s+/g,' ').toLowerCase();
 if(!clean)return null;
 const key=`${stateJid}|${provider}|${label}|${geminiModel}|${clean}`;
 const now=Date.now();
 const doneAt=recentAiResponses.get(key);
 if(inFlightInputs.has(key))return null;
 if(doneAt && now-doneAt<5000)return null;
 inFlightInputs.add(key);
 const previous=aiChains.get(stateJid)||Promise.resolve();
 const task=previous.catch(()=>{}).then(async()=>{
  aiBusyByJid.set(stateJid,{at:Date.now(),text:clean,key});
  try{
   try{await sock.sendPresenceUpdate('composing',j)}catch{}
   const r=await askAI(text,stateJid,{provider,geminiModel});
   recentAiResponses.set(key,Date.now());
   await sendText(sock,j,`✨ ${r.text}\n\n_${r.provider} • ${r.model}_`);
   db.usage(stateJid,label);
   return r;
  }catch(e){
   recentAiResponses.set(key,Date.now());
   logger.warn({err:e.message,provider,label},'AI request failed after provider failover');
   await sendText(sock,j,'⚠️ AI is temporarily unavailable. Please try again in a moment.').catch(()=>{});
   return null;
  }finally{
   try{await sock.sendPresenceUpdate('paused',j)}catch{}
   const currentBusy=aiBusyByJid.get(stateJid);
   if(currentBusy?.key===key)aiBusyByJid.delete(stateJid);
   inFlightInputs.delete(key);
   if(recentAiResponses.size>2000){
    const cutoff=Date.now()-10*60*1000;
    for(const [k,ts] of recentAiResponses)if(ts<cutoff)recentAiResponses.delete(k);
   }
  }
 });
 aiChains.set(stateJid,task);
 try{return await task}
 finally{if(aiChains.get(stateJid)===task)aiChains.delete(stateJid)}
}
async function handleChoice(sock,j,m,choice){
 const actor=actorJid(m,j);
 const sk=sessionKey(j,m);
 if(choice==='language')return languageMenu(sock,j,m);
 if(choice==='si'||choice==='en'){change(j,choice);fallbackMenus.delete(sk);await sendText(sock,j,t(j,'saved'));return home(sock,j,m)}
 if(choice==='home'||choice==='back'){db.setAiMode(actor,false);sessions.delete(sk);fallbackMenus.delete(sk);return home(sock,j,m)}
 if(['ai','media','music','image','tools','group','settings','owner'].includes(choice))return submenu(sock,j,choice,m);
 if(choice==='help')return sendText(sock,j,t(j,'helpText'));
 if(choice==='clear'){clearHistory(actor);db.setAiMode(actor,false);sessions.delete(sk);return sendText(sock,j,t(j,'cleared'))}
 if(choice==='backup'){if(!isOwner(actor))return sendText(sock,j,t(j,'owner'));const out=db.backup();return sendText(sock,j,`💾 Database backup created:\n${out}`)}
 if(choice==='stats'){if(!isOwner(actor)){await sendText(sock,j,t(j,'owner'));return}const st=stats();return sendText(sock,j,`📊 MR DKxx Stats\n\n👤 Users: ${st.users}\n👥 Groups: ${st.groups}\n⚡ Actions: ${st.actions}`)}
 if(choice==='owner'){if(!isOwner(actor))return sendText(sock,j,t(j,'owner'));return submenu(sock,j,'owner',m);}
 if(choice==='myid')return sendText(sock,j,`🆔 Your WhatsApp ID:\n${actor}`);
 if(choice==='status')return sendText(sock,j,`${t(j,'statusText')}\n⏱️ Uptime: ${Math.floor((Date.now()-startedAt)/1000)}s\n📦 Queue: ${queue.size()}`);
 if(choice==='health')return sendText(sock,j,await healthText());
 if(choice==='gemini')return geminiMenu(sock,j,m);
 if(choice==='gemini_auto'){db.setAiMode(actor,true);sessions.set(sk,{mode:'ai',provider:'gemini',geminiModel:''});return sendText(sock,j,t(j,'aiOnGemini'))}
 const gm=geminiModels().find(x=>x.id===choice);
 if(gm){db.setAiMode(actor,true);sessions.set(sk,{mode:'ai',provider:'gemini',geminiModel:gm.name});return sendText(sock,j,`✨ Gemini • ${gm.name}\nSilent failover is enabled. Send your message now. Send back to exit.`)}
 if(choice==='chat'){db.setAiMode(actor,true);sessions.set(sk,{mode:'ai',provider:'auto'});return sendText(sock,j,t(j,'aiOn'))}
 if(choice==='local'){db.setAiMode(actor,true);sessions.set(sk,{mode:'ai',provider:'local'});return sendText(sock,j,t(j,'aiOnLocal'))}
 if(choice==='aistatus'){const rows=await providerStatus();return sendText(sock,j,`🧠 MR DKxx AI Status\n\n${rows.map(x=>`• ${x}`).join('\n')}\n\n🎨 Image AI\n${imageProviderStatus().map(x=>`• ${x}`).join('\n')}`)}
 if(choice==='websearch')return prompt(sock,j,'websearch','websearch',m);
 if(choice==='vision')return prompt(sock,j,'vision','vision',m);
 if(['summarize','translate','analyze','grammar','coding','caption','hashtags','rewrite','imageai'].includes(choice))return prompt(sock,j,'prompt',choice,m);
 if(choice==='imageGen')return imageMenu(sock,j,m);
 if(choice==='imageModels')return imageMenu(sock,j,m);
 if(choice==='imageStatus')return sendText(sock,j,`🩺 Image AI Status\n\n${imageProviderStatus().map(x=>`• ${x}`).join('\n')}`);
 if(choice==='image_auto'){return prompt(sock,j,'imageGen','image_auto',m)}
 if(/^image_(?:gemini_\d+|together_|stability_|fal_|hf_)/.test(String(choice)))return prompt(sock,j,'imageGen',choice,m)
 if(choice==='video'||choice==='audio')return prompt(sock,j,'url',choice,m);
 if(choice==='downloads')return prompt(sock,j,'url','video',m);
 if(choice==='info')return prompt(sock,j,'info','',m);
 if(choice==='sticker'){sessions.set(sk,{mode:'sticker'});return sendText(sock,j,t(j,'sendSticker'))}
 if(['video_best','video_small','video_medium','audio_mp3'].includes(choice)){const s=sessions.get(sk);if(!s?.url){await sendText(sock,j,t(j,'expired'));return}return executeDownload(sock,j,s,choice,m)}
 if(choice==='qr')return prompt(sock,j,'qr','',m);
 if(choice==='calc')return prompt(sock,j,'calc','',m);
 if(choice==='url')return prompt(sock,j,'urlInfo','',m);
 if(choice==='tts')return prompt(sock,j,'tts','',m);
 if(choice==='ocr')return prompt(sock,j,'ocr','',m);
 if(choice==='stt')return prompt(sock,j,'stt','',m);
 if(choice==='unit')return prompt(sock,j,'unit','',m);
 if(choice==='timestamp')return prompt(sock,j,'timestamp','',m);
 if(choice==='uuid')return sendText(sock,j,`🆔 ${require('./services/tools').uuid()}`);
 if(choice==='password')return prompt(sock,j,'password','',m);
 if(choice==='hash')return prompt(sock,j,'hash','',m);
 if(choice==='base64')return prompt(sock,j,'base64','',m);
 if(choice==='json')return prompt(sock,j,'json','',m);
 if(choice==='random')return prompt(sock,j,'random','',m);
 if(choice==='compress_video')return prompt(sock,j,'mediaTool','compress_video',m);
 if(choice==='audio_convert')return prompt(sock,j,'mediaTool','audio_convert',m);
 if(choice==='thumbnail')return prompt(sock,j,'mediaTool','thumbnail',m);
 if(choice==='gif')return prompt(sock,j,'mediaTool','gif',m);
 if(choice==='setrules'){if(!await requireGroupAdmin(sock,j,m))return;sessions.set(sk,{mode:'setrules'});return sendText(sock,j,'📝 Send the new group rules text. Send back to cancel.')}
 if(['rules','admins','groupStats','warnings','tagall','moderation'].includes(choice)){
  if(!isGroup(j)){await sendText(sock,j,t(j,'onlyGroup'));return}
  const meta=await sock.groupMetadata(j);
  if(choice==='rules')return sendText(sock,j,`📜 ${t(j,'rules')}\n\n${db.groupRules(j)||'No rules configured.'}`);
  if(choice==='admins')return sendText(sock,j,'🛡️ Admins\n\n'+meta.participants.filter(p=>p.admin).map(p=>`• ${p.id}`).join('\n'));
  if(choice==='groupStats')return sendText(sock,j,`📊 ${meta.subject}\n👥 Members: ${meta.participants.length}`);
  if(choice==='warnings'){const sender=m.key.participant||j;return sendText(sock,j,`⚠️ Your warnings in this group: ${db.warnCount(j,sender)}\n\nAdmin warning records are stored locally. Use an admin command to add a warning.`)}
  if(choice==='tagall'){if(!await requireGroupAdmin(sock,j,m))return;const mentions=meta.participants.map(p=>p.id);return sock.sendMessage(j,{text:mentions.map(x=>`@${x.split('@')[0]}`).join(' '),mentions})}
  if(choice==='moderation'){if(!await requireGroupAdmin(sock,j,m))return;return sendText(sock,j,'🛡️ Moderation Panel\n\n• Tag all: available\n• Rules: available\n• Warning storage: available\n• Automatic kicks/bans: disabled by default for safety.')}
 }
}
async function healthText(){
 const checks=[];for(const [name,bin,args] of [['Node','node',['--version']],['yt-dlp',process.env.YT_DLP_PATH||'yt-dlp',['--version']],['FFmpeg',process.env.FFMPEG_PATH||'ffmpeg',['-version']]]){try{const r=await media.run(bin,args,15000);checks.push(`✅ ${name}: ${(r.out||r.err).split(/\r?\n/)[0].slice(0,100)}`)}catch(e){checks.push(`❌ ${name}: ${e.message}`)}}checks.push(process.env.GEMINI_API_KEY?.trim()?`✅ Gemini API key: configured (${(process.env.GEMINI_MODELS||'').split(',').filter(Boolean).length||1} model(s))`:'⚠️ Gemini API key: not configured');checks.push(`🗃️ Database: ${db.stats? 'SQLite module loaded':'unknown'}`);return `🩺 MR DKxx System Check\n\n${checks.join('\n')}`}
async function startBot(){
 fs.mkdirSync(AUTH_DIR,{recursive:true});
 const {state,saveCreds}=await useMultiFileAuthState(AUTH_DIR);
 const sock=makeWASocket({auth:state,logger:P({level:'silent'}),browser:['Mr DKxx','Windows','3.0'],markOnlineOnConnect:false});
 sock.ev.on('creds.update',saveCreds);
 sock.ev.on('connection.update',({connection,lastDisconnect,qr:code})=>{
  if(code){console.log('\n=== MR DKxx QR ===\nScan with WhatsApp > Linked devices\n');qrcode.generate(code,{small:true})}
  if(connection==='open'){if(reconnectTimer){clearTimeout(reconnectTimer);reconnectTimer=null}logger.info('MR DKxx connected')}
  if(connection==='close'){
   const c=lastDisconnect?.error?.output?.statusCode;
   if(c===DisconnectReason.loggedOut){logger.error('WhatsApp session logged out; delete auth/mrdkxx and pair again.');return}
   if(!reconnectTimer){reconnectTimer=setTimeout(()=>{reconnectTimer=null;startBot().catch(e=>logger.error({err:e.message},'Reconnect failed'))},5000)}
  }
 });
 sock.ev.on('messages.upsert',async({messages,type})=>{
  if(type && type!=='notify') return;
  for(const m of messages||[]){
   if(!m||m.key.fromMe||!m.message)continue;
   const now=Date.now();
   const messageId=m.key.id;
   if(messageId){const seenAt=seenMessages.get(messageId);if(seenAt && now-seenAt<10*60*1000)continue;seenMessages.set(messageId,now);if(seenMessages.size>2000){for(const [id,ts] of seenMessages){if(now-ts>10*60*1000)seenMessages.delete(id)}}}
   const j=m.key.remoteJid;if(!j)continue;const text=getIncomingText(m);
   const normalizedIncoming=text.trim().replace(/\s+/g,' ').toLowerCase();
   const fingerprint=`${j}|${actorJid(m,j)}|${normalizedIncoming}`;
   const recentAt=recentInputs.get(fingerprint);
   if(recentAt && now-recentAt<6000)continue;
   recentInputs.set(fingerprint,now);
   if(recentInputs.size>2000){for(const [key,ts] of recentInputs){if(now-ts>10*60*1000)recentInputs.delete(key)}}
   const name=m.pushName||'User';db.ensureUser(j,name);
   const actor=actorJid(m,j);db.ensureUser(actor,name);
   if(isGroup(j))db.groupEnsure(j);
   const sk=sessionKey(j,m);
   const normalized=String(text||'').normalize('NFKC').trim().toLowerCase().replace(/\s+/g,' ');
   const dkPayload=parseDkPrefix(text);
   const choice=getChoice(m)||getFallbackChoice(sk,text);
   try{
    // Owner-only global pause/resume. Paused mode ignores all normal messages.
    if((normalized==='stop'||normalized==='/stop') && isOwner(actor)){
      botPaused=true; db.setAiMode(j,false); sessions.clear(); fallbackMenus.clear();
      await sendText(sock,j,'⏹️ MR DKxx bot paused. Owner can send start/resume to enable it again.');
      continue;
    }
    if((normalized==='start'||normalized==='resume'||normalized==='/start'||normalized==='/resume') && isOwner(actor)){
      botPaused=false; await sendText(sock,j,'▶️ MR DKxx bot resumed.'); continue;
    }
    if(botPaused) continue;
    if(choice){await handleChoice(sock,j,m,choice);continue}
    if(normalized==='menu'||normalized==='/menu'||normalized==='home'||normalized==='/home'||normalized==='/start'||normalized==='dk'){await home(sock,j,m);continue}
    if(normalized==='dk menu'||normalized==='dk home'){await home(sock,j,m);continue}
    if(normalized==='back'){db.setAiMode(actor,false);sessions.delete(sk);fallbackMenus.delete(sk);await home(sock,j,m);continue}
    if(normalized==='/help'||normalized==='help'){await sendText(sock,j,t(j,'helpText'));continue}
    if(normalized==='/status'){await handleChoice(sock,j,m,'status');continue}
    if(normalized==='/ping'||normalized==='ping'){await sendText(sock,j,'🏓 Pong! MR DKxx is online.');continue}
    if(normalized==='/id'||normalized==='id'){await handleChoice(sock,j,m,'myid');continue}
    if(normalized==='/clear'||normalized==='clear'){await handleChoice(sock,j,m,'clear');continue}
    if(normalized==='/features'||normalized==='features'){await sendText(sock,j,t(j,'helpText'));continue}
    if(normalized==='/health'){await handleChoice(sock,j,m,'health');continue}
    if(normalized==='/aistatus'||normalized==='aistatus'){const rows=await providerStatus();await sendText(sock,j,`🧠 MR DKxx AI Status\n\n${rows.map(x=>`• ${x}`).join('\n')}\n\n🎨 Image AI\n${imageProviderStatus().map(x=>`• ${x}`).join('\n')}`);continue}
    // AI chat requires the explicit DK prefix. It is case/spacing tolerant (DK, dk, D K, d-k, etc.).
    if(dkPayload!==null){
      const dkCommand=dkPayload.toLowerCase().replace(/\s+/g,' ').trim();
      if(!dkCommand||dkCommand==='menu'||dkCommand==='home'){await home(sock,j,m);continue}
      const s0=sessions.get(sk);
      const aiProvider=s0?.provider||'auto';
      const aiModel=s0?.geminiModel||'';
      await runAi(sock,j,dkPayload,'ai',aiProvider,aiModel,actor);
      continue;
    }
    const s=sessions.get(sk);
    const incomingMsg=unwrapMessage(m.message);
    if(s?.mode==='sticker' && (incomingMsg.imageMessage||incomingMsg.videoMessage)){
      let input=null,output=null;try{const type=incomingMsg.imageMessage?'image':'video';const stream=await downloadContentFromMessage(incomingMsg[type+'Message'],type);input=path.join(process.env.TMP_DIR||path.join(require('./utils').tmpDir,'uploads'),`in-${Date.now()}`);fs.mkdirSync(path.dirname(input),{recursive:true});const ws=fs.createWriteStream(input);for await(const chunk of stream)ws.write(chunk);await new Promise(r=>ws.end(r));output=type==='image'?await sticker.imageToSticker(input):await sticker.videoToSticker(input);await sock.sendMessage(j,{sticker:fs.readFileSync(output)});db.usage(j,'sticker');}catch(e){await sendText(sock,j,`⚠️ ${safeText(e.message,600)}`)}finally{sticker.cleanup(input);sticker.cleanup(output);sessions.delete(sk)}continue}
    if(s?.mode==='ai'){continue}
    if(s?.mode==='setrules'){if(!isGroup(j)){sessions.delete(sk);await sendText(sock,j,t(j,'onlyGroup'));continue}try{const sender=m.key.participant||j;if(!await isAdmin(sock,j,sender)){await sendText(sock,j,t(j,'admin'));sessions.delete(sk);continue}db.setGroupRules(j,text.slice(0,4000));await sendText(sock,j,'✅ Group rules updated.')}catch(e){await sendText(sock,j,`⚠️ ${safeText(e.message,500)}`)}sessions.delete(sk);continue}
    if(s?.mode==='url'){if(!isSafeUrl(text)){await sendText(sock,j,'⚠️ Please send a valid http/https URL.');continue}await sendDownloadMenu(sock,j,text,m);continue}
    if(s?.mode==='info'){if(!isSafeUrl(text)){await sendText(sock,j,'⚠️ Please send a valid URL.');continue}await sendText(sock,j,'🔎 Reading media info...');try{const x=await media.info(text);await sendText(sock,j,`🔎 ${x.title}\n👤 ${x.uploader||'-'}\n⏱️ ${duration(x.duration)}\n🔗 ${x.url}`)}catch(e){await sendText(sock,j,`⚠️ ${e.message}`)}sessions.delete(sk);continue}
    if(s?.mode==='urlInfo'){if(!isSafeUrl(text)){await sendText(sock,j,'⚠️ Please send a valid URL.');continue}try{const x=await require('./services/tools').urlInfo(text);await sendText(sock,j,`🔗 URL Info\n\n🌐 ${x.finalUrl}\n📌 ${x.title}\n📡 ${x.status} ${x.statusText}\n📦 ${x.contentType||'-'}\n📏 ${x.contentLength||'-'}`)}catch(e){await sendText(sock,j,`⚠️ URL info failed: ${safeText(e.message,500)}`)}sessions.delete(sk);continue}
    if(s?.mode==='qr'){const file=await qr(text);try{await sock.sendMessage(j,{image:fs.readFileSync(file),caption:'🔳 MR DKxx QR'})}finally{try{fs.unlinkSync(file)}catch{}}sessions.delete(sk);continue}
    if(s?.mode==='calc'){try{await sendText(sock,j,`🧮 ${calc(text)}`)}catch{await sendText(sock,j,'⚠️ Invalid calculation.')}sessions.delete(sk);continue}
    if(s?.mode==='password'){try{const n=/^\d+$/.test(text.trim())?Number(text.trim()):16;await sendText(sock,j,`🔐 ${require('./services/tools').password(n)}`)}catch(e){await sendText(sock,j,`⚠️ ${e.message}`)}sessions.delete(sk);continue}
    if(s?.mode==='hash'){try{const a=text.split(/\r?\n/,2),alg=(a[0]||'sha256').trim().toLowerCase(),value=a.length>1?a[1]:text;await sendText(sock,j,`🔒 ${require('./services/tools').hash(value,alg)}\nAlgorithm: ${['md5','sha1','sha256','sha512'].includes(alg)?alg:'sha256'}`)}catch(e){await sendText(sock,j,`⚠️ ${e.message}`)}sessions.delete(sk);continue}
    if(s?.mode==='base64'){try{if(/^decode$/i.test(text.trim())){sessions.set(sk,{mode:'base64Decode'});await sendText(sock,j,'🔤 Send Base64 text to decode.')}else{await sendText(sock,j,`🔤 Base64: ${require('./services/tools').base64Encode(text)}`);sessions.delete(sk)}}catch(e){await sendText(sock,j,`⚠️ ${e.message}`);sessions.delete(sk)}continue}
    if(s?.mode==='base64Decode'){try{await sendText(sock,j,`🔤 Decoded: ${require('./services/tools').base64Decode(text)}`)}catch(e){await sendText(sock,j,`⚠️ ${e.message}`)}sessions.delete(sk);continue}
    if(s?.mode==='json'){try{await sendText(sock,j,`🧾\n${require('./services/tools').jsonFormat(text)}`)}catch(e){await sendText(sock,j,`⚠️ Invalid JSON: ${e.message}`)}sessions.delete(sk);continue}
    if(s?.mode==='random'){try{const a=text.trim().split(/\s+/),min=a.length>1?Number(a[0]):1,max=a.length>1?Number(a[1]):Number(a[0])||100;await sendText(sock,j,`🎲 ${require('./services/tools').randomNumber(min,max)}`)}catch(e){await sendText(sock,j,`⚠️ ${e.message}`)}sessions.delete(sk);continue}
    if(s?.mode==='tts'){try{const p=await require('./services/providers').tts(text);await sock.sendMessage(j,{audio:fs.readFileSync(p),mimetype:'audio/mpeg',fileName:'mrdkxx-tts.mp3'});try{fs.unlinkSync(p)}catch{}}catch(e){await sendText(sock,j,`⚠️ ${e.message}`)}sessions.delete(sk);continue}
    if(s?.mode==='unit'){try{const a=text.trim().split(/\s+/);if(a.length!==3)throw new Error('Use: value fromUnit toUnit (example: 10 km m)');await sendText(sock,j,`📏 ${unitConvert(a[0],a[1],a[2])} ${a[2]}`)}catch(e){await sendText(sock,j,`⚠️ ${e.message}`)}sessions.delete(sk);continue}
    if(s?.mode==='timestamp'){try{const x=timestamp(text.trim());await sendText(sock,j,`🕒 ISO: ${x.iso}\n🔢 Unix: ${x.unix}\n📍 Local: ${x.local}`)}catch(e){await sendText(sock,j,`⚠️ ${e.message}`)}sessions.delete(sk);continue}
    if(s?.mode==='websearch'){try{await sendText(sock,j,'🌐 Searching...');const r=await askWeb(text,j);await sendText(sock,j,`🌐 Web Search\n\n${r.text||r}`)}catch(e){await sendText(sock,j,`⚠️ Web search failed: ${safeText(e.message,700)}`)}sessions.delete(sk);continue}
    if(s?.mode==='vision'){
      if(!incomingMsg.imageMessage){await sendText(sock,j,'🖼️ Please send an image now. You can add a caption/question.');continue}
      let f=null;
      try{const x=await saveIncomingMedia(m);f=x.input;await sendText(sock,j,'👁️ Analyzing image...');await sendText(sock,j,await vision(f,text||'Describe this image accurately and extract any visible text. Answer in the user language.'));}
      catch(e){await sendText(sock,j,`⚠️ Vision failed: ${safeText(e.message,700)}`)}
      finally{if(f)try{fs.unlinkSync(f)}catch{};sessions.delete(sk)}
      continue
    }
    if(s?.mode==='ocr'){
      if(!(incomingMsg.imageMessage||incomingMsg.documentMessage)){await sendText(sock,j,'🖼️ Please send an image or document now.');continue}
      let f=null;
      try{const x=await saveIncomingMedia(m);f=x.input;await sendText(sock,j,'🔎 Reading text...');await sendText(sock,j,await ocr(f));}
      catch(e){await sendText(sock,j,`⚠️ OCR failed: ${safeText(e.message,700)}`)}
      finally{if(f)try{fs.unlinkSync(f)}catch{};sessions.delete(sk)}
      continue
    }
    if(s?.mode==='stt'){
      if(!(incomingMsg.audioMessage||incomingMsg.documentMessage)){await sendText(sock,j,'🎙️ Please send a voice/audio message now.');continue}
      let f=null;
      try{const x=await saveIncomingMedia(m);f=x.input;await sendText(sock,j,'🎙️ Transcribing...');await sendText(sock,j,await stt(f));}
      catch(e){await sendText(sock,j,`⚠️ STT failed: ${safeText(e.message,700)}`)}
      finally{if(f)try{fs.unlinkSync(f)}catch{};sessions.delete(sk)}
      continue
    }
    if(s?.mode==='mediaTool'){
      if(!(incomingMsg.imageMessage||incomingMsg.videoMessage||incomingMsg.audioMessage||incomingMsg.documentMessage)){await sendText(sock,j,'📎 Please send the requested media file now.');continue}
      let input=null,out=null;
      try{
        const x=await saveIncomingMedia(m);input=x.input;await sendText(sock,j,'⚙️ Processing media...');
        if(s.kind==='compress_video')out=await media.transcode(input,{type:'video',format:'mp4',quality:'medium'});
        else if(s.kind==='audio_convert')out=await media.audioExtract(input);
        else if(s.kind==='thumbnail')out=await media.thumbnail(input);
        else if(s.kind==='gif')out=await media.gif(input);
        if(!out)throw new Error('No output was produced.');
        const ext=path.extname(out).toLowerCase();
        if(ext==='.mp3'||ext==='.wav'||ext==='.ogg')await sock.sendMessage(j,{audio:fs.readFileSync(out),mimetype:ext==='.wav'?'audio/wav':'audio/mpeg',fileName:path.basename(out)});
        else if(ext==='.gif')await sock.sendMessage(j,{document:fs.readFileSync(out),mimetype:'image/gif',fileName:path.basename(out)});
        else if(ext==='.jpg'||ext==='.jpeg'||ext==='.png'||ext==='.webp')await sock.sendMessage(j,{image:fs.readFileSync(out),caption:'✨ MR DKxx • Media Tool'});
        else await sock.sendMessage(j,{video:fs.readFileSync(out),mimetype:'video/mp4',fileName:path.basename(out)});
      }catch(e){await sendText(sock,j,`⚠️ Media tool failed: ${safeText(e.message,700)}`)}
      finally{if(input)try{fs.unlinkSync(input)}catch{};if(out)try{fs.unlinkSync(out)}catch{};sessions.delete(sk)}
      continue
    }
    if(s?.mode==='prompt'){const prompts={summarize:`Summarize clearly in the user's language:\n\n${text}`,translate:`Translate naturally between Sinhala and English. Preserve meaning:\n\n${text}`,analyze:`Analyze this text and return useful key points, risks and conclusions:\n\n${text}`,grammar:`Proofread and correct grammar/spelling while preserving the original meaning and tone:\n\n${text}`,coding:`Act as a careful coding assistant. Explain the solution, identify bugs and provide safe corrected code when needed:\n\n${text}`,caption:`Write 3 engaging social media captions for this content. Return Sinhala and English options where useful:\n\n${text}`,hashtags:`Generate 15 relevant hashtags for this content. Avoid spammy/repetitive tags:\n\n${text}`,rewrite:`Rewrite this naturally, clearly and professionally while preserving the meaning:\n\n${text}`,imageai:`Create a detailed safe image-generation prompt from this request. Return only the prompt:\n\n${text}`};await runAi(sock,j,prompts[s.kind],s.kind,'auto','',actor);sessions.delete(sk);continue}
    if(s?.mode==='imageGen'){
      await sendText(sock,j,'🎨 Creating image...');let file=null;try{file=await image(text,s?.kind||'image_auto');if(!file||!fs.existsSync(file)||fs.statSync(file).size===0)throw new Error('Image generation returned no usable file.');const ext=path.extname(file).toLowerCase();const mimetype=ext==='.jpg'||ext==='.jpeg'?'image/jpeg':ext==='.webp'?'image/webp':'image/png';await sock.sendMessage(j,{image:{stream:fs.createReadStream(file)},mimetype,caption:'🎨 MR DKxx • AI Image'});db.usage(j,'image')}catch(e){await sendText(sock,j,`⚠️ Image generation failed: ${safeText(e.message,700)}`)}finally{if(file)try{fs.unlinkSync(file)}catch{}}sessions.delete(sk);continue;
    }
    if(/^https?:\/\//i.test(text)){await sendDownloadMenu(sock,j,text,m);continue}
    // Unmatched ordinary messages are intentionally ignored.
    // AI replies require the explicit DK prefix; menu actions use explicit commands/buttons.
    continue;
   }catch(e){logger.error({err:e.message},'message handler');await sendText(sock,j,`⚠️ ${t(j,'error')}\n${safeText(e.message,800)}`).catch(()=>{})}
  }
 });
 return sock;
}
module.exports={startBot};
